import { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  FlaskConical,
  LayoutDashboard,
  Lock,
  Moon,
  ScrollText,
  Settings,
  Sun,
  Webhook,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type { NavTab, WebhookLogEntry } from './types/ssf';
import { useSsfStore } from './hooks/useSsfStore';
import { DashboardView } from './components/DashboardView';
import { LogsView } from './components/LogsView';
import { EndpointsView } from './components/EndpointsView';
import { TesterView } from './components/TesterView';
import { SettingsView } from './components/SettingsView';
import { LogDetailDrawer } from './components/LogDetailDrawer';
import { PinLockScreen } from './components/PinLockScreen';
import { ToastViewport } from './components/ToastViewport';
import { SplashScreen, SsfEmblemSvg } from './components/SplashScreen';
import { OnboardingWizardSheet } from './components/OnboardingWizardSheet';
import { ConnectionDiagnosticsModal } from './components/ConnectionDiagnosticsModal';
import { NotificationCenterDrawer } from './components/NotificationCenterDrawer';

const NAV_ITEMS: Array<{
  id: NavTab;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'logs', label: 'Logs', icon: ScrollText },
  { id: 'endpoints', label: 'Endpoints', icon: Webhook },
  { id: 'tester', label: 'Tester', icon: FlaskConical },
  { id: 'settings', label: 'Settings', icon: Settings },
];

function hasAutostartFlag(): boolean {
  if (typeof window === 'undefined') return false;
  return new URLSearchParams(window.location.search).get('autostart') === '1';
}

export default function App() {
  const store = useSsfStore();
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [inspectedLogId, setInspectedLogId] = useState<string | null>(null);

  const [showSplash, setShowSplash] = useState<boolean>(() => !hasAutostartFlag());
  const [wizardOpen, setWizardOpen] = useState<boolean>(false);
  const [diagnosticsOpen, setDiagnosticsOpen] = useState<boolean>(false);
  const [notificationsOpen, setNotificationsOpen] = useState<boolean>(false);
  const [autoWizardEvaluated, setAutoWizardEvaluated] = useState<boolean>(false);

  // Auto-open First-Time Onboarding Wizard once splash completes if no endpoint configured yet
  useEffect(() => {
    if (showSplash || autoWizardEvaluated) return;
    setAutoWizardEvaluated(true);
    if (
      !hasAutostartFlag() &&
      store.endpoints.length === 0 &&
      !store.settings.onboardingCompleted &&
      !store.isLocked
    ) {
      setWizardOpen(true);
    }
  }, [
    showSplash,
    autoWizardEvaluated,
    store.endpoints.length,
    store.settings.onboardingCompleted,
    store.isLocked,
  ]);

  const inspectedLog: WebhookLogEntry | null = useMemo(
    () => (inspectedLogId ? store.logs.find((l) => l.id === inspectedLogId) ?? null : null),
    [inspectedLogId, store.logs]
  );

  const attentionQueueCount = useMemo(
    () => store.logs.filter((l) => l.status === 'pending' || l.status === 'failed').length,
    [store.logs]
  );

  const unreadNotifications = useMemo(
    () => store.notifications.filter((n) => !n.read).length,
    [store.notifications]
  );

  const statusPillMeta = {
    connected: {
      label: 'LIVE',
      dotClass: 'bg-emerald-500',
      pulse: true,
      pillClass:
        'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/20 dark:text-emerald-300',
    },
    connecting: {
      label: 'SYNCING',
      dotClass: 'bg-amber-500',
      pulse: true,
      pillClass:
        'border-amber-500/30 bg-amber-500/10 text-amber-700 hover:bg-amber-500/20 dark:text-amber-300',
    },
    degraded: {
      label: 'DEGRADED',
      dotClass: 'bg-rose-500',
      pulse: true,
      pillClass:
        'border-rose-500/35 bg-rose-500/10 text-rose-700 hover:bg-rose-500/20 dark:text-rose-300',
    },
    standby: {
      label: 'OFFLINE',
      dotClass: 'bg-zinc-400 dark:bg-zinc-500',
      pulse: false,
      pillClass:
        'border-zinc-200 bg-zinc-100/90 text-zinc-600 hover:bg-zinc-200/70 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800',
    },
  }[store.connectionState];

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-950 transition-colors duration-150 dark:bg-[#09090B] dark:text-zinc-100">
      {/* Subtle OLED ambient background layer */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 -z-10 hidden dark:block bg-[radial-gradient(ellipse_80%_45%_at_50%_-15%,rgba(124,58,237,0.12),transparent)]"
      />

      {/* Desktop Sidebar Navigation */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-zinc-200/90 bg-white/95 backdrop-blur-xl lg:flex dark:border-zinc-800/80 dark:bg-[#0B0B0F]/95">
        {/* Brand Wordmark */}
        <div className="flex h-16 items-center gap-3 border-b border-zinc-200/80 px-5 dark:border-zinc-800/80">
          <SsfEmblemSvg className="h-9 w-9 shrink-0 shadow-md shadow-violet-600/25" />
          <div className="min-w-0 leading-tight">
            <p className="truncate font-display text-sm font-extrabold tracking-tight text-zinc-950 dark:text-white">
              SOCIAX
            </p>
            <p className="truncate font-mono text-[10px] font-medium text-zinc-500 dark:text-zinc-400">
              SSF • by BunoWave
            </p>
          </div>
        </div>

        {/* Navigation Links */}
        <nav aria-label="Main Navigation" className="flex-1 space-y-1 px-3 py-4">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`flex h-11 w-full items-center justify-between rounded-xl px-3.5 text-sm font-medium whitespace-nowrap ${
                  isActive
                    ? 'bg-gradient-to-r from-violet-600/15 to-indigo-600/10 text-violet-700 ring-1 ring-violet-500/25 dark:from-violet-600/20 dark:to-indigo-600/10 dark:text-violet-300'
                    : 'text-zinc-600 hover:bg-zinc-100 hover:text-zinc-950 dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-zinc-100'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Icon
                    className={`h-4 w-4 shrink-0 ${
                      isActive ? 'text-violet-600 dark:text-violet-400' : 'text-zinc-400'
                    }`}
                    aria-hidden="true"
                  />
                  <span>{item.label}</span>
                </span>
                {item.id === 'logs' && attentionQueueCount > 0 && (
                  <span className="rounded-full bg-amber-500/15 px-2 py-0.5 font-mono text-[11px] font-semibold text-amber-600 tabular-data dark:text-amber-400">
                    {attentionQueueCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Branding & Device Lockup */}
        <div className="border-t border-zinc-200/80 p-3.5 dark:border-zinc-800/80">
          <div className="rounded-xl border border-zinc-200/80 bg-zinc-50/80 px-3 py-2.5 dark:border-zinc-800/80 dark:bg-zinc-900/50">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-medium text-zinc-600 dark:text-zinc-300">A BunoWave Product</span>
              <span className="font-mono text-[10px] text-zinc-400">v1.0.0</span>
            </div>
            <p className="mt-1 truncate font-mono text-[10px] text-zinc-500 dark:text-zinc-400">
              {store.settings.deviceId}
            </p>
          </div>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex min-h-screen flex-col lg:pl-64">
        {/* Flagship Top App Bar */}
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-zinc-200/80 bg-white/85 px-4 backdrop-blur-xl lg:h-16 lg:px-8 dark:border-zinc-800/80 dark:bg-[#09090B]/85">
          {/* Left: Custom SSF Icon + SOCIAX + SSF • by BunoWave (Mobile & Desktop) */}
          <div className="flex min-w-0 items-center gap-2.5">
            <SsfEmblemSvg className="h-8 w-8 shrink-0 lg:hidden" />
            <div className="min-w-0 leading-tight lg:hidden">
              <p className="truncate font-display text-sm font-extrabold tracking-tight text-zinc-950 dark:text-white">
                SOCIAX
              </p>
              <p className="truncate font-mono text-[10px] font-medium text-zinc-500 dark:text-zinc-400">
                SSF • by BunoWave
              </p>
            </div>

            <div className="hidden items-center gap-2 text-sm lg:flex">
              <span className="font-semibold text-zinc-950 dark:text-zinc-100">
                {NAV_ITEMS.find((i) => i.id === activeTab)?.label}
              </span>
              <span aria-hidden="true" className="text-zinc-300 dark:text-zinc-700">
                ·
              </span>
              <span className="font-mono text-xs text-zinc-500 dark:text-zinc-400">
                {store.endpoints.length} endpoint{store.endpoints.length === 1 ? '' : 's'}
              </span>
            </div>
          </div>

          {/* Right: Live Status Pill + Alerts Bell + Theme Toggle (+ Lock if PIN active) */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setDiagnosticsOpen(true)}
              aria-label={`Connection status: ${statusPillMeta.label}. Open diagnostics`}
              className={`inline-flex h-9 items-center gap-1.5 rounded-full border px-3 font-mono text-[11px] font-bold tracking-wider transition-colors whitespace-nowrap shrink-0 ${statusPillMeta.pillClass}`}
            >
              <span className="relative flex h-2 w-2 items-center justify-center" aria-hidden="true">
                {statusPillMeta.pulse && (
                  <span
                    className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-75 ${statusPillMeta.dotClass}`}
                  />
                )}
                <span className={`relative inline-flex h-2 w-2 rounded-full ${statusPillMeta.dotClass}`} />
              </span>
              {statusPillMeta.label}
            </button>

            <button
              type="button"
              onClick={() => setNotificationsOpen(true)}
              aria-label={`Open notifications${unreadNotifications > 0 ? ` (${unreadNotifications} unread)` : ''}`}
              className="relative flex h-10 w-10 items-center justify-center rounded-xl text-zinc-600 transition-colors hover:bg-zinc-100 hover:text-zinc-950 dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-zinc-100"
            >
              <Bell className="h-[18px] w-[18px]" />
              {unreadNotifications > 0 && (
                <span
                  aria-hidden="true"
                  className="absolute right-2 top-2 flex h-2 w-2 rounded-full bg-violet-500 ring-2 ring-white dark:ring-[#09090B]"
                />
              )}
            </button>

            <button
              type="button"
              onClick={store.toggleTheme}
              aria-label={`Switch to ${store.settings.theme === 'dark' ? 'light' : 'dark'} mode`}
              className="flex h-10 w-10 items-center justify-center rounded-xl text-zinc-600 transition-colors hover:bg-zinc-100 hover:text-zinc-950 dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-zinc-100"
            >
              {store.settings.theme === 'dark' ? (
                <Sun className="h-[18px] w-[18px]" />
              ) : (
                <Moon className="h-[18px] w-[18px]" />
              )}
            </button>

            {store.settings.security.pinEnabled && (
              <button
                type="button"
                onClick={store.lockApp}
                aria-label="Lock workspace with PIN"
                className="flex h-10 w-10 items-center justify-center rounded-xl text-zinc-600 transition-colors hover:bg-zinc-100 hover:text-violet-600 dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-violet-400"
              >
                <Lock className="h-[18px] w-[18px]" />
              </button>
            )}
          </div>
        </header>

        {/* Scrollable Workspace Viewport */}
        <main className="mx-auto w-full max-w-7xl flex-1 px-4 pb-28 pt-5 sm:px-6 lg:px-8 lg:pb-12 lg:pt-7">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
          >
            {activeTab === 'dashboard' && (
              <DashboardView
                masterActive={store.settings.masterActive}
                connectionState={store.connectionState}
                connectedSince={store.connectedSince}
                endpoints={store.endpoints}
                activeEndpoint={store.activeEndpoint}
                logs={store.logs}
                readiness={store.readiness}
                heartbeat={store.heartbeat}
                onToggleMaster={store.toggleMasterActive}
                onCheckHeartbeat={store.checkHeartbeat}
                onSelectEndpoint={store.setActiveEndpoint}
                onNavigate={setActiveTab}
                onOpenLog={(log) => setInspectedLogId(log.id)}
                onOpenDiagnostics={() => setDiagnosticsOpen(true)}
                onOpenWizard={() => setWizardOpen(true)}
                onSimulateIncomingSms={store.triggerQuickSimulatedSms}
                onGrantSmsPermissions={store.grantSmsPermissions}
                onBypassBattery={store.bypassBatteryOptimization}
                onToggleBootAutoStart={store.toggleBootAutoStart}
              />
            )}

            {activeTab === 'logs' && (
              <LogsView
                logs={store.logs}
                onOpenLog={(log) => setInspectedLogId(log.id)}
                onProcessQueue={store.processPendingQueue}
                onClearLogs={store.clearLogs}
                onNavigate={setActiveTab}
              />
            )}

            {activeTab === 'endpoints' && (
              <EndpointsView
                endpoints={store.endpoints}
                activeEndpointId={store.activeEndpoint?.id ?? null}
                deviceId={store.settings.deviceId}
                onSaveEndpoint={store.saveEndpoint}
                onDuplicateEndpoint={store.duplicateEndpoint}
                onDeleteEndpoint={store.deleteEndpoint}
                onSetActiveEndpoint={store.setActiveEndpoint}
                onOpenWizard={() => setWizardOpen(true)}
              />
            )}

            {activeTab === 'tester' && (
              <TesterView
                endpoints={store.endpoints}
                activeEndpointId={store.activeEndpoint?.id ?? null}
                deviceId={store.settings.deviceId}
                onSendTest={store.executeTestWebhook}
                onNavigate={setActiveTab}
                onOpenLog={(log) => setInspectedLogId(log.id)}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                settings={store.settings}
                readiness={store.readiness}
                endpointCount={store.endpoints.length}
                logCount={store.logs.length}
                onToggleTheme={store.toggleTheme}
                onUpdateDeviceId={store.updateDeviceId}
                onUpdateWatchdog={store.updateWatchdog}
                onTestWatchdog={store.testWatchdog}
                onSetPinLock={store.setPinLock}
                onLockNow={store.lockApp}
                onGetBackupData={store.getBackupData}
                onImportBackup={store.importBackupText}
                onResetWorkspace={store.resetWorkspace}
                onReplaySplash={() => setShowSplash(true)}
                onOpenDiagnostics={() => setDiagnosticsOpen(true)}
                onOpenWizard={() => setWizardOpen(true)}
              />
            )}
          </motion.div>
        </main>
      </div>

      {/* Floating Frosted-Glass Mobile Bottom Navigation Dock */}
      <nav
        aria-label="Mobile Navigation"
        className="fixed bottom-3 left-3 right-3 z-30 rounded-2xl border border-zinc-200/90 bg-white/85 px-1.5 py-1.5 shadow-xl shadow-zinc-950/10 backdrop-blur-xl lg:hidden dark:border-zinc-800/90 dark:bg-[#0E0E13]/85 dark:shadow-black/60"
      >
        <div className="grid h-[54px] grid-cols-5 items-center gap-0.5">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`relative flex h-full min-h-[44px] flex-col items-center justify-center gap-1 rounded-xl transition-colors ${
                  isActive
                    ? 'bg-violet-600/12 text-violet-600 shadow-xs ring-1 ring-violet-500/25 dark:bg-violet-500/20 dark:text-violet-300'
                    : 'text-zinc-500 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-100'
                }`}
              >
                <Icon className="h-[19px] w-[19px]" aria-hidden="true" />
                <span className="text-[10px] font-semibold leading-none tracking-tight">
                  {item.label}
                </span>
                {item.id === 'logs' && attentionQueueCount > 0 && (
                  <span
                    aria-label={`${attentionQueueCount} pending or failed`}
                    className="absolute right-2 top-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-amber-500 px-1 font-mono text-[9px] font-bold text-zinc-950"
                  >
                    {attentionQueueCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* First-Time Onboarding & Quick Connection Wizard */}
      <AnimatePresence>
        {wizardOpen && (
          <OnboardingWizardSheet
            readiness={store.readiness}
            onClose={() => {
              setWizardOpen(false);
              store.markOnboardingDismissed();
            }}
            onGrantSmsPermissions={store.grantSmsPermissions}
            onBypassBattery={store.bypassBatteryOptimization}
            onEnableForegroundService={store.enableForegroundService}
            onCompleteWizard={store.completeOnboardingWizard}
          />
        )}
      </AnimatePresence>

      {/* 5-Step Connection Diagnostics Modal */}
      <AnimatePresence>
        {diagnosticsOpen && (
          <ConnectionDiagnosticsModal
            activeEndpoint={store.activeEndpoint}
            pendingQueueCount={store.kpis.pendingQueueCount}
            readiness={store.readiness}
            onClose={() => setDiagnosticsOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Slide-Over Notification Center */}
      <NotificationCenterDrawer
        open={notificationsOpen}
        notifications={store.notifications}
        onClose={() => setNotificationsOpen(false)}
        onMarkAllRead={store.markAllNotificationsRead}
        onClearAll={store.clearNotifications}
      />

      {/* Developer Log Inspector Slide-Over */}
      <LogDetailDrawer
        log={inspectedLog}
        onClose={() => setInspectedLogId(null)}
        onRetry={async (id) => {
          await store.retryLogEntry(id, true);
        }}
      />

      {/* Full-screen 4-Digit App PIN Lock */}
      {store.isLocked && (
        <PinLockScreen
          mode="unlock"
          storedHash={store.settings.security.pinHash}
          onUnlock={store.unlockApp}
        />
      )}

      {/* Toast Notifications */}
      <ToastViewport toasts={store.toasts} onDismiss={store.dismissToast} />

      {/* Flagship Startup Splash Screen (~1.8s, replayable in Settings) */}
      <AnimatePresence>
        {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      </AnimatePresence>
    </div>
  );
}
