export type NavTab = 'dashboard' | 'logs' | 'endpoints' | 'tester' | 'settings';

export type SimSlot = 'SIM 1' | 'SIM 2';

export type SimSlotFilter = 'BOTH' | 'SIM_1' | 'SIM_2';

export type EndpointColorTag = 'violet' | 'indigo' | 'emerald' | 'amber' | 'rose' | 'sky';

export type ConnectionEngineState = 'standby' | 'connecting' | 'connected' | 'degraded';

export interface HeaderEntry {
  id: string;
  key: string;
  value: string;
  isSecret: boolean;
}

export interface RetryPolicy {
  maxRetries: number;
  exponentialBackoff: boolean;
  offlineQueue: boolean;
}

export interface EndpointProfile {
  id: string;
  name: string;
  colorTag: EndpointColorTag;
  url: string;
  headers: HeaderEntry[];
  payloadTemplate: string;
  allowedSenders: string[];
  keywordRegex: string;
  simFilter: SimSlotFilter;
  retryPolicy: RetryPolicy;
  createdAt: string;
  updatedAt: string;
}

export type LogStatus = 'success' | 'pending' | 'failed';

export interface SmsEnvelope {
  sender: string;
  message: string;
  simSlot: SimSlot;
  receivedAt: string;
  deviceId: string;
}

export interface WebhookLogEntry {
  id: string;
  endpointId: string;
  endpointName: string;
  endpointUrl: string;
  status: LogStatus;
  sms: SmsEnvelope;
  request: {
    url: string;
    method: 'POST';
    headers: Array<{ key: string; value: string; isSecret: boolean }>;
    body: string;
  };
  response: {
    statusCode: number | null;
    statusText: string;
    latencyMs: number;
    body: string;
    error?: string;
    isCorsHint?: boolean;
  };
  attempts: number;
  maxRetries: number;
  nextRetryAt?: string;
  mode: 'live' | 'simulated';
}

export type WatchdogChannel = 'disabled' | 'telegram' | 'webhook';

export interface WatchdogConfig {
  channel: WatchdogChannel;
  telegramBotToken: string;
  telegramChatId: string;
  alertWebhookUrl: string;
  notifyLowBattery: boolean;
  notifyDeviceOffline: boolean;
  notifyConsecutiveFailures: boolean;
  lastTestedAt?: string;
  lastTestResult?: {
    ok: boolean;
    message: string;
  };
}

export interface AppSecurityConfig {
  pinEnabled: boolean;
  pinHash: string | null;
}

export interface AppSettings {
  theme: 'dark' | 'light';
  deviceId: string;
  masterActive: boolean;
  activeEndpointId: string | null;
  onboardingCompleted: boolean;
  watchdog: WatchdogConfig;
  security: AppSecurityConfig;
}

export interface AndroidReadinessState {
  smsPermissionGranted: boolean;
  batteryOptimizationBypassed: boolean;
  bootAutoStartEnabled: boolean;
  foregroundServiceRunning: boolean;
  batteryLevel: number;
  platform: 'android-capacitor' | 'browser-simulator';
}

export interface ToastMessage {
  id: string;
  tone: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
}

export interface AppNotificationItem {
  id: string;
  tone: 'success' | 'error' | 'info' | 'warning';
  title: string;
  description?: string;
  timestamp: string;
  read: boolean;
}

export interface SsfWorkspaceBackup {
  format: 'ssf-config-v1';
  exportedAt: string;
  encrypted: boolean;
  checksum: string;
  payload: string;
}
