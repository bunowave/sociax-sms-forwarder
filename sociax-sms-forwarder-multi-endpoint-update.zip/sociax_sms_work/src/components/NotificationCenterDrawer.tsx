import { AnimatePresence, motion } from 'motion/react';
import {
  AlertTriangle,
  Bell,
  CheckCheck,
  CheckCircle2,
  Info,
  Trash2,
  X,
  XCircle,
} from 'lucide-react';
import type { AppNotificationItem } from '../types/ssf';
import { formatRelativeTime } from '../utils/webhookEngine';

interface NotificationCenterDrawerProps {
  open: boolean;
  notifications: AppNotificationItem[];
  onClose: () => void;
  onMarkAllRead: () => void;
  onClearAll: () => void;
}

export function NotificationCenterDrawer({
  open,
  notifications,
  onClose,
  onMarkAllRead,
  onClearAll,
}: NotificationCenterDrawerProps) {
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <AnimatePresence>
      {open && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Alerts and Notifications"
          className="fixed inset-0 z-50 flex items-end justify-end sm:items-stretch"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/55 backdrop-blur-[2px]"
          />

          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 flex max-h-[88vh] w-full flex-col overflow-hidden rounded-t-3xl border-t border-zinc-200 bg-white sm:max-h-full sm:max-w-md sm:rounded-none sm:border-l sm:border-t-0 dark:border-zinc-800 dark:bg-[#0D0D12]"
          >
            <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-zinc-800">
              <div className="flex items-center gap-2.5">
                <Bell className="h-4 w-4 text-violet-600 dark:text-violet-400" aria-hidden="true" />
                <div>
                  <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
                    Notification Center
                  </h2>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    {unreadCount > 0 ? `${unreadCount} unread alert${unreadCount === 1 ? '' : 's'}` : 'All caught up'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close notification center"
                className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {notifications.length > 0 && (
              <div className="flex items-center justify-between border-b border-zinc-100 bg-zinc-50/70 px-5 py-2.5 dark:border-zinc-800/80 dark:bg-zinc-900/40">
                <button
                  type="button"
                  onClick={onMarkAllRead}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-violet-600 hover:text-violet-700 dark:text-violet-400 dark:hover:text-violet-300"
                >
                  <CheckCheck className="h-3.5 w-3.5" />
                  Mark all read
                </button>
                <button
                  type="button"
                  onClick={onClearAll}
                  className="inline-flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-rose-600 dark:text-zinc-400 dark:hover:text-rose-400"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Clear
                </button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800/80">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-400 dark:border-zinc-800 dark:bg-zinc-900">
                    <Bell className="h-5 w-5" />
                  </div>
                  <p className="mt-3 text-sm font-semibold text-zinc-900 dark:text-zinc-100">
                    No alerts yet
                  </p>
                  <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
                    Connection changes, delivery retries, and watchdog events will appear here.
                  </p>
                </div>
              ) : (
                notifications.map((item) => {
                  const Icon =
                    item.tone === 'success'
                      ? CheckCircle2
                      : item.tone === 'error'
                        ? XCircle
                        : item.tone === 'warning'
                          ? AlertTriangle
                          : Info;
                  const iconColor =
                    item.tone === 'success'
                      ? 'text-emerald-500'
                      : item.tone === 'error'
                        ? 'text-rose-500'
                        : item.tone === 'warning'
                          ? 'text-amber-500'
                          : 'text-violet-500';

                  return (
                    <div
                      key={item.id}
                      className={`flex items-start gap-3 px-5 py-3.5 ${
                        !item.read ? 'bg-violet-500/[0.04]' : ''
                      }`}
                    >
                      <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${iconColor}`} aria-hidden="true" />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="truncate text-sm font-medium text-zinc-950 dark:text-zinc-100">
                            {item.title}
                          </p>
                          <span className="shrink-0 font-mono text-[10px] text-zinc-400 tabular-data">
                            {formatRelativeTime(item.timestamp)}
                          </span>
                        </div>
                        {item.description && (
                          <p className="mt-0.5 text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
                            {item.description}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}
