import { useMemo } from 'react';
import { Activity } from 'lucide-react';
import type { WebhookLogEntry } from '../types/ssf';
import { buildSparklineSeries } from '../utils/webhookEngine';

interface LatencySparklineCardProps {
  logs: WebhookLogEntry[];
}

export function LatencySparklineCard({ logs }: LatencySparklineCardProps) {
  const summary = useMemo(() => buildSparklineSeries(logs, 16), [logs]);

  const chartGeometry = useMemo(() => {
    const width = 320;
    const height = 72;
    const padX = 8;
    const padY = 10;

    if (summary.points.length === 0) {
      return null;
    }

    const maxVal = Math.max(summary.maxLatencyMs ?? 100, 100);
    const minVal = 0;
    const range = Math.max(1, maxVal - minVal);

    const coords = summary.points.map((pt, idx) => {
      const x =
        summary.points.length === 1
          ? width / 2
          : padX + (idx / (summary.points.length - 1)) * (width - padX * 2);
      const normalized = (pt.latencyMs - minVal) / range;
      const y = height - padY - normalized * (height - padY * 2);
      return { x, y, pt };
    });

    const linePath = coords
      .map((c, idx) => `${idx === 0 ? 'M' : 'L'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`)
      .join(' ');

    const areaPath =
      coords.length === 1
        ? ''
        : `${linePath} L ${coords[coords.length - 1].x.toFixed(1)} ${height} L ${coords[0].x.toFixed(1)} ${height} Z`;

    return { width, height, coords, linePath, areaPath };
  }, [summary]);

  return (
    <section
      aria-label="Throughput and Latency Telemetry"
      className="relative overflow-hidden rounded-2xl border border-zinc-200/90 bg-white/90 p-5 backdrop-blur-xl dark:border-zinc-800/90 dark:bg-[#0E0E13]/90"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-500/40 to-transparent"
      />

      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4 text-violet-600 dark:text-violet-400" aria-hidden="true" />
            <h2 className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
              Throughput & Latency Sparkline
            </h2>
          </div>
          <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
            Recent webhook round-trip response times
          </p>
        </div>

        <div className="flex items-center gap-4 text-right">
          <div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">Avg Latency</p>
            <p className="font-mono text-sm font-semibold text-zinc-950 tabular-data dark:text-zinc-50">
              {summary.avgLatencyMs !== null ? `${summary.avgLatencyMs}ms` : '—'}
            </p>
          </div>
          <div>
            <p className="text-[11px] text-zinc-500 dark:text-zinc-400">1h Volume</p>
            <p className="font-mono text-sm font-semibold text-violet-600 tabular-data dark:text-violet-400">
              {summary.throughputLastHour} req
            </p>
          </div>
        </div>
      </div>

      <div className="mt-4">
        {!chartGeometry ? (
          <div className="flex h-[72px] items-center justify-center rounded-xl border border-dashed border-zinc-200 bg-zinc-50/60 text-xs text-zinc-500 dark:border-zinc-800 dark:bg-zinc-900/30 dark:text-zinc-400">
            Fire a webhook or simulate an incoming SMS to plot live latency telemetry.
          </div>
        ) : (
          <div className="rounded-xl border border-zinc-100 bg-zinc-50/70 px-2 py-1.5 dark:border-zinc-800/70 dark:bg-zinc-950/60">
            <svg
              viewBox={`0 0 ${chartGeometry.width} ${chartGeometry.height}`}
              className="h-[72px] w-full overflow-visible"
              role="img"
              aria-label={`Latency sparkline across ${summary.points.length} recent webhooks, average ${summary.avgLatencyMs}ms`}
            >
              <defs>
                <linearGradient id="ssf-spark-fill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#7C3AED" stopOpacity="0.32" />
                  <stop offset="100%" stopColor="#7C3AED" stopOpacity="0.01" />
                </linearGradient>
              </defs>

              {chartGeometry.areaPath && (
                <path d={chartGeometry.areaPath} fill="url(#ssf-spark-fill)" />
              )}

              {chartGeometry.coords.length > 1 && (
                <path
                  d={chartGeometry.linePath}
                  fill="none"
                  stroke="#8B5CF6"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}

              {chartGeometry.coords.map(({ x, y, pt }) => {
                const dotFill =
                  pt.status === 'success'
                    ? '#10B981'
                    : pt.status === 'pending'
                      ? '#F59E0B'
                      : '#F43F5E';
                return (
                  <circle key={pt.id} cx={x} cy={y} r="3.2" fill={dotFill}>
                    <title>{`${pt.latencyMs}ms · ${pt.status} @ ${pt.timeLabel}`}</title>
                  </circle>
                );
              })}
            </svg>
          </div>
        )}

        {summary.minLatencyMs !== null && summary.maxLatencyMs !== null && (
          <div className="mt-2 flex items-center justify-between font-mono text-[11px] text-zinc-500 tabular-data dark:text-zinc-400">
            <span>Min {summary.minLatencyMs}ms</span>
            <span>Last {summary.points.length} deliveries</span>
            <span>Peak {summary.maxLatencyMs}ms</span>
          </div>
        )}
      </div>
    </section>
  );
}
