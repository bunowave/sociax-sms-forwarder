import { useCallback, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  AlertTriangle,
  CheckCircle2,
  Loader2,
  RefreshCw,
  ShieldAlert,
  Stethoscope,
  X,
  XCircle,
} from 'lucide-react';
import type { AndroidReadinessState, EndpointProfile } from '../types/ssf';
import { pingEndpointHeartbeat } from '../services/webhookDispatcher';
import { validateWebhookUrl } from '../utils/webhookEngine';

interface ConnectionDiagnosticsModalProps {
  activeEndpoint: EndpointProfile | null;
  pendingQueueCount: number;
  readiness: AndroidReadinessState;
  onClose: () => void;
}

type CheckStatus = 'running' | 'pass' | 'warn' | 'fail';

interface DiagnosticRow {
  id: string;
  title: string;
  status: CheckStatus;
  detail: string;
  metric?: string;
}

function buildInitialDiagnosticRows(
  activeEndpoint: EndpointProfile | null,
  pendingQueueCount: number,
  platform: AndroidReadinessState['platform']
): { rows: DiagnosticRow[]; urlValid: boolean } {
  const urlCheck = activeEndpoint
    ? validateWebhookUrl(activeEndpoint.url)
    : { valid: false, error: 'No active endpoint profile configured.' };

  const customHeaders = activeEndpoint?.headers.filter((h) => h.key.trim().length > 0) ?? [];
  const hasSecretHeader = customHeaders.some((h) => h.isSecret && h.value.trim().length > 0);
  const queueEnabled = activeEndpoint?.retryPolicy.offlineQueue ?? false;
  const isNative = platform === 'android-capacitor';

  const rows: DiagnosticRow[] = [
    {
      id: 'https',
      title: '1. Endpoint URL & HTTPS Validation',
      status: urlCheck.valid ? 'pass' : 'fail',
      detail: urlCheck.valid
        ? activeEndpoint!.url
        : urlCheck.error ?? 'Configure an HTTPS webhook endpoint.',
      metric: urlCheck.valid ? 'HTTPS TLS' : 'Missing',
    },
    {
      id: 'headers',
      title: '2. Custom Auth Header Presence',
      status: !activeEndpoint
        ? 'fail'
        : hasSecretHeader
          ? 'pass'
          : customHeaders.length > 0
            ? 'pass'
            : 'warn',
      detail: !activeEndpoint
        ? 'No active profile selected.'
        : customHeaders.length > 0
          ? `${customHeaders.length} custom header${customHeaders.length === 1 ? '' : 's'} configured (${hasSecretHeader ? 'secret masked' : 'plain'}).`
          : 'No authentication header configured. Recommended for production endpoints.',
      metric: `${customHeaders.length} hdr`,
    },
    {
      id: 'ping',
      title: '3. Live Server Reachability & Latency Ping',
      status: activeEndpoint && urlCheck.valid ? 'running' : 'fail',
      detail:
        activeEndpoint && urlCheck.valid
          ? 'Probing target server RTT...'
          : 'Skipped — no valid HTTPS endpoint URL.',
    },
    {
      id: 'queue',
      title: '4. Offline Queue Worker Status',
      status: !activeEndpoint ? 'warn' : queueEnabled ? 'pass' : 'warn',
      detail: !activeEndpoint
        ? 'Worker idle until an endpoint is created.'
        : queueEnabled
          ? `Retry worker armed (${activeEndpoint.retryPolicy.maxRetries} max retries, ${pendingQueueCount} pending).`
          : 'Offline retry queue is disabled on this endpoint profile.',
      metric: `${pendingQueueCount} queued`,
    },
    {
      id: 'bridge',
      title: '5. Native SMS Bridge Status',
      status: isNative ? 'pass' : 'warn',
      detail: isNative
        ? 'Capacitor Android Native Plugin active with hardware SIM access.'
        : 'Running in Browser Simulator Mode. Package with Capacitor Android APK for live cellular SMS capture.',
      metric: isNative ? 'Android APK' : 'Web Simulator',
    },
  ];

  return { rows, urlValid: urlCheck.valid };
}

export function ConnectionDiagnosticsModal({
  activeEndpoint,
  pendingQueueCount,
  readiness,
  onClose,
}: ConnectionDiagnosticsModalProps) {
  const [rows, setRows] = useState<DiagnosticRow[]>(
    () => buildInitialDiagnosticRows(activeEndpoint, pendingQueueCount, readiness.platform).rows
  );
  const [running, setRunning] = useState<boolean>(
    () => Boolean(activeEndpoint && validateWebhookUrl(activeEndpoint.url).valid)
  );

  const runDiagnostics = useCallback(async () => {
    const { rows: initialRows, urlValid } = buildInitialDiagnosticRows(
      activeEndpoint,
      pendingQueueCount,
      readiness.platform
    );
    setRows(initialRows);

    if (activeEndpoint && urlValid) {
      setRunning(true);
      const ping = await pingEndpointHeartbeat(activeEndpoint.url);
      setRows((prev) =>
        prev.map((row) =>
          row.id === 'ping'
            ? {
                ...row,
                status: ping.reachable ? 'pass' : 'warn',
                detail: ping.reachable
                  ? `Server responded to probe handshake (${ping.note}).`
                  : `Probe did not complete (${ping.note}). Check firewall/TLS or test on native Android.`,
                metric: `${ping.latencyMs}ms`,
              }
            : row
        )
      );
    }

    setRunning(false);
  }, [activeEndpoint, pendingQueueCount, readiness.platform]);

  useEffect(() => {
    void runDiagnostics();
  }, [runDiagnostics]);

  const passCount = rows.filter((r) => r.status === 'pass').length;
  const failCount = rows.filter((r) => r.status === 'fail').length;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Connection Diagnostics"
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 backdrop-blur-sm sm:items-center sm:p-4"
    >
      <motion.div
        initial={{ y: 36, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 36, opacity: 0 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-lg overflow-hidden rounded-t-3xl border border-zinc-200 bg-white shadow-2xl sm:rounded-2xl dark:border-zinc-800 dark:bg-[#0D0D12]"
      >
        <div className="flex justify-center pt-2.5 sm:hidden" aria-hidden="true">
          <div className="h-1 w-10 rounded-full bg-zinc-300 dark:bg-zinc-700" />
        </div>

        <div className="flex items-center justify-between border-b border-zinc-200/80 px-5 py-4 dark:border-zinc-800/80">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-600/15 text-violet-600 dark:text-violet-400">
              <Stethoscope className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
                Connection Diagnostics
              </h2>
              <p className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400">
                {running
                  ? 'Running live checks...'
                  : `${passCount}/5 checks optimal${failCount > 0 ? ` · ${failCount} action needed` : ''}`}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close diagnostics modal"
            className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="max-h-[70vh] divide-y divide-zinc-100 overflow-y-auto px-5 py-2 dark:divide-zinc-800/80">
          {rows.map((row) => {
            const Icon =
              row.status === 'running'
                ? Loader2
                : row.status === 'pass'
                  ? CheckCircle2
                  : row.status === 'warn'
                    ? AlertTriangle
                    : XCircle;

            const iconStyle =
              row.status === 'running'
                ? 'animate-spin text-violet-500'
                : row.status === 'pass'
                  ? 'text-emerald-500'
                  : row.status === 'warn'
                    ? 'text-amber-500'
                    : 'text-rose-500';

            return (
              <div key={row.id} className="flex items-start justify-between gap-3 py-3.5">
                <div className="flex min-w-0 items-start gap-3">
                  <Icon className={`mt-0.5 h-4 w-4 shrink-0 ${iconStyle}`} aria-hidden="true" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-zinc-950 dark:text-zinc-100">
                      {row.title}
                    </p>
                    <p className="mt-0.5 break-words text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
                      {row.detail}
                    </p>
                  </div>
                </div>
                {row.metric && (
                  <span className="shrink-0 rounded-lg border border-zinc-200 bg-zinc-50 px-2 py-0.5 font-mono text-[11px] font-medium text-zinc-700 tabular-data dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300">
                    {row.metric}
                  </span>
                )}
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-zinc-200/80 bg-zinc-50/70 px-5 py-3.5 dark:border-zinc-800/80 dark:bg-zinc-950/70">
          <span className="inline-flex items-center gap-1.5 text-xs text-zinc-500 dark:text-zinc-400">
            <ShieldAlert className="h-3.5 w-3.5 text-violet-500" aria-hidden="true" />
            BunoWave Relay Engine v1.0.0
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => void runDiagnostics()}
              disabled={running}
              className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3 text-xs font-semibold text-zinc-800 hover:bg-zinc-100 disabled:opacity-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${running ? 'animate-spin' : ''}`} />
              Re-run Checks
            </button>
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-9 items-center rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white hover:bg-violet-700 whitespace-nowrap shrink-0"
            >
              Done
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
