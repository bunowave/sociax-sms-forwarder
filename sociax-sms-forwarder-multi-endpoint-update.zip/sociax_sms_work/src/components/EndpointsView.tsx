import { useMemo, useRef, useState } from 'react';
import {
  Check,
  Copy,
  Edit3,
  Eye,
  EyeOff,
  Plus,
  QrCode,
  Radio,
  Sparkles,
  Trash2,
  Webhook,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import type {
  EndpointColorTag,
  EndpointProfile,
  HeaderEntry,
  SimSlotFilter,
} from '../types/ssf';
import {
  DEFAULT_PAYLOAD_TEMPLATE,
  TEMPLATE_VARIABLES,
  generateId,
  renderPayloadTemplate,
  validateRegexPattern,
  validateWebhookUrl,
} from '../utils/webhookEngine';
import { QrConfigModal } from './QrConfigModal';

interface EndpointsViewProps {
  endpoints: EndpointProfile[];
  activeEndpointId: string | null;
  deviceId: string;
  onSaveEndpoint: (
    data: Omit<EndpointProfile, 'id' | 'createdAt' | 'updatedAt'>,
    editId?: string
  ) => void;
  onDuplicateEndpoint: (id: string) => void;
  onDeleteEndpoint: (id: string) => void;
  onSetActiveEndpoint: (id: string) => void;
  onOpenWizard?: () => void;
}

const COLOR_OPTIONS: Array<{ id: EndpointColorTag; label: string; dotClass: string }> = [
  { id: 'violet', label: 'Violet', dotClass: 'bg-violet-600' },
  { id: 'indigo', label: 'Indigo', dotClass: 'bg-indigo-500' },
  { id: 'emerald', label: 'Emerald', dotClass: 'bg-emerald-500' },
  { id: 'sky', label: 'Sky', dotClass: 'bg-sky-500' },
  { id: 'amber', label: 'Amber', dotClass: 'bg-amber-500' },
  { id: 'rose', label: 'Rose', dotClass: 'bg-rose-500' },
];

function getColorDot(tag: EndpointColorTag): string {
  return COLOR_OPTIONS.find((c) => c.id === tag)?.dotClass ?? 'bg-violet-600';
}

interface EditorDraft {
  name: string;
  colorTag: EndpointColorTag;
  url: string;
  headers: HeaderEntry[];
  payloadTemplate: string;
  allowedSenders: string[];
  keywordRegex: string;
  simFilter: SimSlotFilter;
  maxRetries: number;
  exponentialBackoff: boolean;
  offlineQueue: boolean;
}

function createBlankDraft(): EditorDraft {
  return {
    name: '',
    colorTag: 'violet',
    url: '',
    headers: [{ id: generateId('hdr'), key: '', value: '', isSecret: true }],
    payloadTemplate: DEFAULT_PAYLOAD_TEMPLATE,
    allowedSenders: ['ALL'],
    keywordRegex: '',
    simFilter: 'BOTH',
    maxRetries: 5,
    exponentialBackoff: true,
    offlineQueue: true,
  };
}

function profileToDraft(profile: EndpointProfile): EditorDraft {
  return {
    name: profile.name,
    colorTag: profile.colorTag,
    url: profile.url,
    headers:
      profile.headers.length > 0
        ? profile.headers.map((h) => ({ ...h }))
        : [{ id: generateId('hdr'), key: '', value: '', isSecret: true }],
    payloadTemplate: profile.payloadTemplate,
    allowedSenders: profile.allowedSenders.length > 0 ? [...profile.allowedSenders] : ['ALL'],
    keywordRegex: profile.keywordRegex,
    simFilter: profile.simFilter,
    maxRetries: profile.retryPolicy.maxRetries,
    exponentialBackoff: profile.retryPolicy.exponentialBackoff,
    offlineQueue: profile.retryPolicy.offlineQueue,
  };
}

export function EndpointsView({
  endpoints,
  activeEndpointId,
  deviceId,
  onSaveEndpoint,
  onDuplicateEndpoint,
  onDeleteEndpoint,
  onSetActiveEndpoint,
  onOpenWizard,
}: EndpointsViewProps) {
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<EditorDraft>(createBlankDraft);
  const [senderInput, setSenderInput] = useState('');
  const [revealedHeaderIds, setRevealedHeaderIds] = useState<Record<string, boolean>>({});
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [qrModalState, setQrModalState] = useState<{
    open: boolean;
    mode: 'export' | 'import';
    profile?: EndpointProfile | null;
  }>({ open: false, mode: 'import', profile: null });

  const templateRef = useRef<HTMLTextAreaElement | null>(null);

  const openCreateEditor = () => {
    setEditingId(null);
    setDraft(createBlankDraft());
    setSenderInput('');
    setFormErrors({});
    setEditorOpen(true);
  };

  const openEditEditor = (profile: EndpointProfile) => {
    setEditingId(profile.id);
    setDraft(profileToDraft(profile));
    setSenderInput('');
    setFormErrors({});
    setEditorOpen(true);
  };

  const livePreview = useMemo(() => {
    return renderPayloadTemplate(draft.payloadTemplate, {
      sender: 'SENDER-ID',
      message: 'Sample incoming SMS text for live JSON preview.',
      sim_slot: 'SIM 1',
      timestamp: '2026-11-25T14:30:00.000Z',
      device_id: deviceId,
    });
  }, [draft.payloadTemplate, deviceId]);

  const regexValidation = useMemo(
    () => validateRegexPattern(draft.keywordRegex),
    [draft.keywordRegex]
  );

  const insertVariableChip = (token: string) => {
    const el = templateRef.current;
    if (!el) {
      setDraft((prev) => ({ ...prev, payloadTemplate: `${prev.payloadTemplate}${token}` }));
      return;
    }
    const start = el.selectionStart ?? draft.payloadTemplate.length;
    const end = el.selectionEnd ?? draft.payloadTemplate.length;
    const next =
      draft.payloadTemplate.slice(0, start) + token + draft.payloadTemplate.slice(end);
    setDraft((prev) => ({ ...prev, payloadTemplate: next }));
    window.requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(start + token.length, start + token.length);
    });
  };

  const addHeaderRow = () => {
    setDraft((prev) => ({
      ...prev,
      headers: [...prev.headers, { id: generateId('hdr'), key: '', value: '', isSecret: false }],
    }));
  };

  const updateHeaderRow = (id: string, patch: Partial<HeaderEntry>) => {
    setDraft((prev) => ({
      ...prev,
      headers: prev.headers.map((h) => (h.id === id ? { ...h, ...patch } : h)),
    }));
  };

  const removeHeaderRow = (id: string) => {
    setDraft((prev) => ({
      ...prev,
      headers: prev.headers.filter((h) => h.id !== id),
    }));
  };

  const addSenderTag = (raw: string) => {
    const tokens = raw
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    if (tokens.length === 0) return;

    setDraft((prev) => {
      if (tokens.some((t) => t.toUpperCase() === 'ALL')) {
        return { ...prev, allowedSenders: ['ALL'] };
      }
      const existing = prev.allowedSenders.filter((s) => s.toUpperCase() !== 'ALL');
      const merged = Array.from(new Set([...existing, ...tokens]));
      return { ...prev, allowedSenders: merged };
    });
    setSenderInput('');
  };

  const removeSenderTag = (tag: string) => {
    setDraft((prev) => {
      const next = prev.allowedSenders.filter((s) => s !== tag);
      return { ...prev, allowedSenders: next.length > 0 ? next : ['ALL'] };
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const errors: Record<string, string> = {};

    if (!draft.name.trim()) {
      errors.name = 'Profile name is required.';
    }

    const urlCheck = validateWebhookUrl(draft.url);
    if (!urlCheck.valid) {
      errors.url = urlCheck.error ?? 'Enter a valid HTTPS webhook URL.';
    }

    if (!livePreview.validJson) {
      errors.payloadTemplate = `Payload template must render valid JSON (${livePreview.error}).`;
    }

    if (!regexValidation.valid) {
      errors.keywordRegex = regexValidation.error ?? 'Invalid regex pattern.';
    }

    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }

    // Include any unsubmitted sender text automatically
    let finalSenders = [...draft.allowedSenders];
    if (senderInput.trim()) {
      const extras = senderInput
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      if (extras.some((t) => t.toUpperCase() === 'ALL')) {
        finalSenders = ['ALL'];
      } else {
        finalSenders = Array.from(
          new Set([...finalSenders.filter((s) => s.toUpperCase() !== 'ALL'), ...extras])
        );
      }
    }

    const cleanedHeaders = draft.headers
      .filter((h) => h.key.trim().length > 0)
      .map((h) => ({ ...h, key: h.key.trim() }));

    onSaveEndpoint(
      {
        name: draft.name.trim(),
        colorTag: draft.colorTag,
        url: draft.url.trim(),
        headers: cleanedHeaders,
        payloadTemplate: draft.payloadTemplate,
        allowedSenders: finalSenders.length > 0 ? finalSenders : ['ALL'],
        keywordRegex: draft.keywordRegex.trim(),
        simFilter: draft.simFilter,
        retryPolicy: {
          maxRetries: Math.max(0, Math.min(20, draft.maxRetries)),
          exponentialBackoff: draft.exponentialBackoff,
          offlineQueue: draft.offlineQueue,
        },
      },
      editingId ?? undefined
    );

    setEditorOpen(false);
    setEditingId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header Row */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
            Webhook Endpoints
          </h1>
          <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
            Configure multi-endpoint routing, dynamic headers, JSON payload templates, and SMS filters.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenWizard && (
            <button
              type="button"
              onClick={onOpenWizard}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-violet-500/30 bg-violet-600/10 px-3.5 text-xs font-semibold text-violet-700 transition-colors hover:bg-violet-600/20 dark:text-violet-300 whitespace-nowrap shrink-0"
            >
              <Sparkles className="h-3.5 w-3.5" />
              + Setup Wizard
            </button>
          )}
          <button
            type="button"
            onClick={() => setQrModalState({ open: true, mode: 'import', profile: null })}
            className="inline-flex h-10 items-center gap-2 rounded-xl border border-zinc-200 bg-white px-3.5 text-xs font-semibold text-zinc-800 transition-colors hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
          >
            <QrCode className="h-4 w-4 text-violet-600 dark:text-violet-400" />
            QR Import
          </button>
          <button
            type="button"
            onClick={openCreateEditor}
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white shadow-md shadow-violet-600/20 transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" />
            New Endpoint
          </button>
        </div>
      </div>

      {/* Endpoint Editor Slide-Up Bottom Sheet */}
      {editorOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={editingId ? 'Edit Endpoint Profile' : 'Create Endpoint Profile'}
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 backdrop-blur-sm sm:items-center sm:p-4"
        >
          <motion.form
            initial={{ y: 36, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            onSubmit={handleSave}
            noValidate
            className="flex max-h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-t-3xl border border-zinc-200 bg-white shadow-2xl sm:rounded-2xl dark:border-zinc-800 dark:bg-[#0D0D12]"
          >
            <div
              aria-hidden="true"
              className="h-[2px] w-full bg-gradient-to-r from-transparent via-violet-500/75 to-transparent"
            />
            <div className="flex justify-center pt-2.5 sm:hidden" aria-hidden="true">
              <div className="h-1 w-10 rounded-full bg-zinc-300 dark:bg-zinc-700" />
            </div>
            <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 sm:px-6 dark:border-zinc-800">
              <div>
                <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
                  {editingId ? 'Edit Endpoint Profile' : 'Create Endpoint Profile'}
                </h2>
                <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                  All fields are stored locally and exportable via QR or .ssf.json backup.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditorOpen(false)}
                aria-label="Close endpoint editor"
                className="flex h-10 w-10 items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6">
              <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            {/* Left Column: Identity, URL, Headers, Rules */}
            <div className="space-y-6 lg:col-span-7">
              {/* Name & Color Tag */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-12">
                <div className="sm:col-span-8">
                  <label
                    htmlFor="ep-name"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Profile Name
                  </label>
                  <input
                    id="ep-name"
                    type="text"
                    value={draft.name}
                    onChange={(e) => {
                      setDraft((prev) => ({ ...prev, name: e.target.value }));
                      setFormErrors((prev) => ({ ...prev, name: '' }));
                    }}
                    placeholder="e.g. Production Webhook, Billing Server"
                    className="mt-1.5 h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 text-sm text-zinc-900 outline-none transition-colors focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                  />
                  {formErrors.name && (
                    <p role="alert" className="mt-1 text-xs font-medium text-rose-600 dark:text-rose-400">
                      {formErrors.name}
                    </p>
                  )}
                </div>

                <div className="sm:col-span-4">
                  <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                    Color Tag
                  </span>
                  <div className="mt-2.5 flex items-center gap-2">
                    {COLOR_OPTIONS.map((color) => (
                      <button
                        key={color.id}
                        type="button"
                        onClick={() => setDraft((prev) => ({ ...prev, colorTag: color.id }))}
                        aria-label={`Select ${color.label} tag`}
                        aria-pressed={draft.colorTag === color.id}
                        className={`flex h-7 w-7 items-center justify-center rounded-full transition-transform ${color.dotClass} ${
                          draft.colorTag === color.id
                            ? 'scale-110 ring-2 ring-violet-500 ring-offset-2 ring-offset-white dark:ring-offset-[#0D0D10]'
                            : 'opacity-70 hover:opacity-100'
                        }`}
                      >
                        {draft.colorTag === color.id && <Check className="h-3.5 w-3.5 text-white" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* HTTPS Webhook URL */}
              <div>
                <label
                  htmlFor="ep-url"
                  className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                >
                  Webhook URL (HTTPS required)
                </label>
                <input
                  id="ep-url"
                  type="url"
                  value={draft.url}
                  onChange={(e) => {
                    setDraft((prev) => ({ ...prev, url: e.target.value }));
                    setFormErrors((prev) => ({ ...prev, url: '' }));
                  }}
                  placeholder="https://api.yourdomain.com/webhooks/sms"
                  className="mt-1.5 h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 font-mono text-xs text-zinc-900 outline-none transition-colors focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {formErrors.url && (
                  <p role="alert" className="mt-1 text-xs font-medium text-rose-600 dark:text-rose-400">
                    {formErrors.url}
                  </p>
                )}
              </div>

              {/* Dynamic Custom Headers */}
              <div>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                      Custom HTTP Headers
                    </span>
                    <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      Add unlimited key/value headers (e.g., Authorization, custom tokens).
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={addHeaderRow}
                    className="inline-flex h-9 items-center gap-1 rounded-lg border border-zinc-200 px-3 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-50 dark:border-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-900 whitespace-nowrap shrink-0"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add Header
                  </button>
                </div>

                <div className="mt-2.5 space-y-2">
                  {draft.headers.map((header, idx) => {
                    const isRevealed = Boolean(revealedHeaderIds[header.id]);
                    return (
                      <div
                        key={header.id}
                        className="grid grid-cols-1 gap-2 sm:grid-cols-12 sm:items-center"
                      >
                        <input
                          type="text"
                          aria-label={`Header ${idx + 1} Key`}
                          value={header.key}
                          onChange={(e) => updateHeaderRow(header.id, { key: e.target.value })}
                          placeholder="Header Name"
                          className="h-10 rounded-lg border border-zinc-200 bg-zinc-50 px-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 sm:col-span-4 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                        />
                        <div className="relative sm:col-span-6">
                          <input
                            type={header.isSecret && !isRevealed ? 'password' : 'text'}
                            aria-label={`Header ${idx + 1} Value`}
                            value={header.value}
                            onChange={(e) => updateHeaderRow(header.id, { value: e.target.value })}
                            placeholder="Header Value"
                            className="h-10 w-full rounded-lg border border-zinc-200 bg-zinc-50 pl-3 pr-9 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              setRevealedHeaderIds((prev) => ({
                                ...prev,
                                [header.id]: !prev[header.id],
                              }))
                            }
                            aria-label={isRevealed ? 'Hide header value' : 'Show header value'}
                            className="absolute right-1.5 top-1 flex h-8 w-8 items-center justify-center rounded-md text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                          >
                            {isRevealed ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                          </button>
                        </div>
                        <div className="flex items-center justify-end gap-1 sm:col-span-2">
                          <button
                            type="button"
                            onClick={() =>
                              updateHeaderRow(header.id, { isSecret: !header.isSecret })
                            }
                            title="Mask value in logs"
                            aria-pressed={header.isSecret}
                            className={`h-9 rounded-lg px-2 text-[11px] font-medium transition-colors ${
                              header.isSecret
                                ? 'bg-violet-600/10 text-violet-600 dark:text-violet-400'
                                : 'text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                            }`}
                          >
                            {header.isSecret ? 'Secret' : 'Plain'}
                          </button>
                          <button
                            type="button"
                            onClick={() => removeHeaderRow(header.id)}
                            aria-label={`Remove header ${idx + 1}`}
                            className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-400 transition-colors hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10 dark:hover:text-rose-400"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Smart Filtering Rules */}
              <div className="space-y-4 border-t border-zinc-200 pt-5 dark:border-zinc-800">
                <h3 className="text-sm font-semibold text-zinc-950 dark:text-zinc-100">
                  Smart Filtering Rules
                </h3>

                {/* Allowed Sender IDs */}
                <div>
                  <label
                    htmlFor="ep-senders"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Allowed Sender IDs (comma-separated or ALL)
                  </label>
                  <div className="mt-1.5 flex gap-2">
                    <input
                      id="ep-senders"
                      type="text"
                      value={senderInput}
                      onChange={(e) => setSenderInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          addSenderTag(senderInput);
                        }
                      }}
                      placeholder="Type sender IDs separated by commas, or ALL"
                      className="h-10 flex-1 rounded-xl border border-zinc-200 bg-zinc-50 px-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                    />
                    <button
                      type="button"
                      onClick={() => addSenderTag(senderInput)}
                      className="inline-flex h-10 items-center rounded-xl border border-zinc-200 bg-white px-3.5 text-xs font-medium text-zinc-800 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                    >
                      Add
                    </button>
                  </div>

                  {/* Interactive removable sender tokens */}
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    {draft.allowedSenders.map((sender) => (
                      <button
                        key={sender}
                        type="button"
                        onClick={() => removeSenderTag(sender)}
                        aria-label={`Remove sender filter ${sender}`}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-zinc-50 px-2.5 py-1 font-mono text-xs text-zinc-800 transition-colors hover:border-rose-400 hover:text-rose-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:border-rose-500/60 dark:hover:text-rose-400"
                      >
                        <span>{sender}</span>
                        <X className="h-3 w-3 opacity-60" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Keyword / Regex Filter */}
                <div>
                  <label
                    htmlFor="ep-regex"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Required Keyword or Regex Filter (optional)
                  </label>
                  <input
                    id="ep-regex"
                    type="text"
                    value={draft.keywordRegex}
                    onChange={(e) => {
                      setDraft((prev) => ({ ...prev, keywordRegex: e.target.value }));
                      setFormErrors((prev) => ({ ...prev, keywordRegex: '' }));
                    }}
                    placeholder="e.g. TrxID|received|credited (prevents leaking personal OTPs)"
                    className="mt-1.5 h-10 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                  />
                  {(!regexValidation.valid || formErrors.keywordRegex) && (
                    <p role="alert" className="mt-1 text-xs font-medium text-rose-600 dark:text-rose-400">
                      {formErrors.keywordRegex || regexValidation.error}
                    </p>
                  )}
                </div>

                {/* SIM Slot Filter */}
                <div>
                  <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                    SIM Slot Filter
                  </span>
                  <div className="mt-1.5 inline-flex rounded-xl bg-zinc-100 p-1 dark:bg-zinc-900">
                    {(
                      [
                        { id: 'BOTH', label: 'Both SIMs' },
                        { id: 'SIM_1', label: 'SIM 1 Only' },
                        { id: 'SIM_2', label: 'SIM 2 Only' },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setDraft((prev) => ({ ...prev, simFilter: opt.id }))}
                        className={`h-9 rounded-lg px-3.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                          draft.simFilter === opt.id
                            ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                            : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Retry Policy */}
              <div className="space-y-4 border-t border-zinc-200 pt-5 dark:border-zinc-800">
                <h3 className="text-sm font-semibold text-zinc-950 dark:text-zinc-100">
                  Retry & Offline Queue Policy
                </h3>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label
                      htmlFor="ep-max-retries"
                      className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      Max Retries
                    </label>
                    <input
                      id="ep-max-retries"
                      type="number"
                      min={0}
                      max={20}
                      value={draft.maxRetries}
                      onChange={(e) =>
                        setDraft((prev) => ({
                          ...prev,
                          maxRetries: Math.max(0, Math.min(20, Number(e.target.value) || 0)),
                        }))
                      }
                      className="mt-1.5 h-10 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                    />
                  </div>

                  <label className="flex cursor-pointer items-center justify-between rounded-xl border border-zinc-200 bg-zinc-50/70 px-3.5 py-2.5 dark:border-zinc-800 dark:bg-zinc-900/50">
                    <span className="text-xs font-medium text-zinc-800 dark:text-zinc-200">
                      Exponential Backoff
                    </span>
                    <input
                      type="checkbox"
                      checked={draft.exponentialBackoff}
                      onChange={(e) =>
                        setDraft((prev) => ({ ...prev, exponentialBackoff: e.target.checked }))
                      }
                      className="h-4 w-4 accent-violet-600"
                    />
                  </label>

                  <label className="flex cursor-pointer items-center justify-between rounded-xl border border-zinc-200 bg-zinc-50/70 px-3.5 py-2.5 dark:border-zinc-800 dark:bg-zinc-900/50">
                    <span className="text-xs font-medium text-zinc-800 dark:text-zinc-200">
                      Offline Queue
                    </span>
                    <input
                      type="checkbox"
                      checked={draft.offlineQueue}
                      onChange={(e) =>
                        setDraft((prev) => ({ ...prev, offlineQueue: e.target.checked }))
                      }
                      className="h-4 w-4 accent-violet-600"
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Right Column: Dynamic JSON Payload Template Editor + Live JSON Preview */}
            <div className="space-y-4 lg:col-span-5">
              <div>
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="ep-payload-template"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Dynamic JSON Payload Template
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setDraft((prev) => ({ ...prev, payloadTemplate: DEFAULT_PAYLOAD_TEMPLATE }))
                    }
                    className="text-xs font-medium text-violet-600 hover:text-violet-700 dark:text-violet-400 dark:hover:text-violet-300"
                  >
                    Reset Template
                  </button>
                </div>

                {/* Clickable Variable Insertion Buttons */}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {TEMPLATE_VARIABLES.map((v) => (
                    <button
                      key={v.token}
                      type="button"
                      onClick={() => insertVariableChip(v.token)}
                      title={v.description}
                      className="rounded-lg border border-zinc-200 bg-zinc-50 px-2.5 py-1 font-mono text-[11px] font-medium text-violet-700 transition-colors hover:border-violet-400 hover:bg-violet-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-violet-300 dark:hover:border-violet-500/60 dark:hover:bg-violet-500/10"
                    >
                      {v.token}
                    </button>
                  ))}
                </div>

                <textarea
                  ref={templateRef}
                  id="ep-payload-template"
                  rows={9}
                  value={draft.payloadTemplate}
                  onChange={(e) => {
                    setDraft((prev) => ({ ...prev, payloadTemplate: e.target.value }));
                    setFormErrors((prev) => ({ ...prev, payloadTemplate: '' }));
                  }}
                  spellCheck={false}
                  className="mt-2.5 w-full rounded-xl border border-zinc-200 bg-zinc-950 p-3.5 font-mono text-xs leading-relaxed text-zinc-100 outline-none focus:border-violet-500 dark:border-zinc-800"
                />
                {formErrors.payloadTemplate && (
                  <p role="alert" className="mt-1 text-xs font-medium text-rose-600 dark:text-rose-400">
                    {formErrors.payloadTemplate}
                  </p>
                )}
              </div>

              {/* Live JSON Preview */}
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
                    Live JSON Preview
                  </span>
                  <span
                    className={`font-mono text-[11px] font-medium ${
                      livePreview.validJson
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {livePreview.validJson ? 'Valid JSON' : 'Syntax Error'}
                  </span>
                </div>
                <pre className="mt-1.5 max-h-60 overflow-auto rounded-xl border border-zinc-200 bg-zinc-50 p-3.5 font-mono text-xs leading-relaxed text-zinc-800 dark:border-zinc-800 dark:bg-zinc-900/70 dark:text-zinc-200">
                  {livePreview.validJson
                    ? livePreview.rendered
                    : livePreview.error ?? 'Invalid JSON syntax'}
                </pre>
              </div>
            </div>
            </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 border-t border-zinc-200 bg-zinc-50/80 px-5 py-4 sm:px-6 dark:border-zinc-800 dark:bg-zinc-950/80">
              <button
                type="button"
                onClick={() => setEditorOpen(false)}
                className="inline-flex h-11 items-center rounded-xl border border-zinc-200 px-4 text-xs font-semibold text-zinc-700 transition-colors hover:bg-zinc-50 dark:border-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-900 whitespace-nowrap shrink-0"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-violet-600 px-5 text-xs font-semibold text-white shadow-md shadow-violet-600/20 transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
              >
                {editingId ? 'Save Changes' : 'Save Endpoint'}
              </button>
            </div>
          </motion.form>
        </div>
      )}

      {/* Profile List / Empty State */}
      {endpoints.length === 0 && !editorOpen ? (
        <div className="flex flex-col items-center justify-center rounded-2xl border border-zinc-200 bg-white px-6 py-16 text-center dark:border-zinc-800 dark:bg-[#0D0D10]">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-400 dark:border-zinc-800 dark:bg-zinc-900">
            <Webhook className="h-5 w-5" />
          </div>
          <h2 className="mt-4 text-base font-semibold text-zinc-950 dark:text-zinc-50">
            No webhook endpoints configured
          </h2>
          <p className="mt-1.5 max-w-md text-sm text-zinc-500 dark:text-zinc-400">
            SOCIAX SMS Forwarder ships with zero hardcoded URLs or API keys. Create your first
            custom HTTPS endpoint profile or import a QR configuration to begin.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
            <button
              type="button"
              onClick={openCreateEditor}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" />
              Create Endpoint Profile
            </button>
            <button
              type="button"
              onClick={() => setQrModalState({ open: true, mode: 'import', profile: null })}
              className="inline-flex h-11 items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 text-xs font-semibold text-zinc-800 transition-colors hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
            >
              <QrCode className="h-4 w-4" />
              Import via QR / JSON
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {endpoints.map((ep) => {
            const isActive = ep.id === activeEndpointId;
            return (
              <article
                key={ep.id}
                className={`flex flex-col justify-between rounded-2xl border bg-white p-5 transition-colors dark:bg-[#0D0D10] ${
                  isActive
                    ? 'border-violet-500/60 dark:border-violet-500/50'
                    : 'border-zinc-200 dark:border-zinc-800'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2.5">
                        <span
                          aria-hidden="true"
                          className={`h-2.5 w-2.5 shrink-0 rounded-full ${getColorDot(ep.colorTag)}`}
                        />
                        <h3 className="truncate text-base font-semibold text-zinc-950 dark:text-zinc-50">
                          {ep.name}
                        </h3>
                      </div>
                      <p className="mt-1 truncate font-mono text-xs text-zinc-500 dark:text-zinc-400">
                        {ep.url}
                      </p>
                    </div>

                    {isActive ? (
                      <span className="inline-flex items-center gap-1 font-mono text-xs font-semibold text-violet-600 dark:text-violet-400 whitespace-nowrap shrink-0">
                        <Radio className="h-3.5 w-3.5" />
                        Active
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onSetActiveEndpoint(ep.id)}
                        className="inline-flex h-9 items-center rounded-lg border border-zinc-200 px-3 text-xs font-medium text-zinc-700 transition-colors hover:border-violet-500 hover:text-violet-600 dark:border-zinc-800 dark:text-zinc-300 dark:hover:border-violet-500 dark:hover:text-violet-400 whitespace-nowrap shrink-0"
                      >
                        Set Active
                      </button>
                    )}
                  </div>

                  {/* Clean unboxed metadata summary */}
                  <div className="mt-4 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-zinc-500 dark:text-zinc-400">
                    <span>
                      {ep.headers.length} header{ep.headers.length === 1 ? '' : 's'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">
                      Senders: {ep.allowedSenders.slice(0, 3).join(', ')}
                      {ep.allowedSenders.length > 3 ? ` +${ep.allowedSenders.length - 3}` : ''}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {ep.simFilter === 'BOTH'
                        ? 'SIM 1 & 2'
                        : ep.simFilter === 'SIM_1'
                          ? 'SIM 1 Only'
                          : 'SIM 2 Only'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-data">
                      {ep.retryPolicy.maxRetries} retries
                    </span>
                  </div>

                  {ep.keywordRegex && (
                    <p className="mt-2 truncate font-mono text-[11px] text-zinc-500 dark:text-zinc-400">
                      Regex: /{ep.keywordRegex}/i
                    </p>
                  )}
                </div>

                {/* Actions bar */}
                <div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-zinc-100 pt-4 dark:border-zinc-800/80">
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => openEditEditor(ep)}
                      aria-label={`Edit ${ep.name}`}
                      className="inline-flex h-9 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                      Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => onDuplicateEndpoint(ep.id)}
                      aria-label={`Duplicate ${ep.name}`}
                      className="inline-flex h-9 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                    >
                      <Copy className="h-3.5 w-3.5" />
                      Duplicate
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setQrModalState({ open: true, mode: 'export', profile: ep })
                      }
                      aria-label={`QR Code for ${ep.name}`}
                      className="inline-flex h-9 items-center gap-1.5 rounded-lg px-2.5 text-xs font-medium text-violet-600 transition-colors hover:bg-violet-50 dark:text-violet-400 dark:hover:bg-violet-500/10 whitespace-nowrap shrink-0"
                    >
                      <QrCode className="h-3.5 w-3.5" />
                      QR Config
                    </button>
                  </div>

                  {confirmDeleteId === ep.id ? (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          onDeleteEndpoint(ep.id);
                          setConfirmDeleteId(null);
                        }}
                        className="inline-flex h-9 items-center rounded-lg bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700 whitespace-nowrap shrink-0"
                      >
                        Confirm
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(null)}
                        className="inline-flex h-9 items-center rounded-lg px-2.5 text-xs font-medium text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteId(ep.id)}
                      aria-label={`Delete ${ep.name}`}
                      className="flex h-9 w-9 items-center justify-center rounded-lg text-zinc-400 transition-colors hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-500/10 dark:hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}

      {qrModalState.open && (
        <QrConfigModal
          mode={qrModalState.mode}
          profile={qrModalState.profile}
          onClose={() => setQrModalState({ open: false, mode: 'import', profile: null })}
          onImportProfile={(profileData) => onSaveEndpoint(profileData)}
        />
      )}
    </div>
  );
}
