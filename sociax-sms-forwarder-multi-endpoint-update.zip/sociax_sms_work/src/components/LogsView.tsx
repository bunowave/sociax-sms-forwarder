import { useMemo, useState } from 'react';
import {
  ChevronRight,
  FlaskConical,
  RefreshCw,
  ScrollText,
  Search,
  Trash2,
} from 'lucide-react';
import type { LogStatus, NavTab, WebhookLogEntry } from '../types/ssf';
import {
  filterWebhookLogs,
  formatRelativeTime,
  formatTimestampTime,
} from '../utils/webhookEngine';

interface LogsViewProps {
  logs: WebhookLogEntry[];
  onOpenLog: (log: WebhookLogEntry) => void;
  onProcessQueue: () => Promise<void>;
  onClearLogs: () => void;
  onNavigate: (tab: NavTab) => void;
}

export function LogsView({
  logs,
  onOpenLog,
  onProcessQueue,
  onClearLogs,
  onNavigate,
}: LogsViewProps) {
  const [statusFilter, setStatusFilter] = useState<'all' | LogStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [processingQueue, setProcessingQueue] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const counts = useMemo(() => {
    let success = 0;
    let pending = 0;
    let failed = 0;
    for (const l of logs) {
      if (l.status === 'success') success += 1;
      else if (l.status === 'pending') pending += 1;
      else failed += 1;
    }
    return { all: logs.length, success, pending, failed };
  }, [logs]);

  const filteredLogs = useMemo(
    () => filterWebhookLogs(logs, statusFilter, searchQuery),
    [logs, statusFilter, searchQuery]
  );

  const handleProcessQueue = async () => {
    setProcessingQueue(true);
    try {
      await onProcessQueue();
    } finally {
      setProcessingQueue(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header & Controls */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
            HTTP Log Inspector
          </h1>
          <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
            Inspect outgoing payloads, server responses, latencies, and the offline retry queue.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {counts.pending > 0 && (
            <button
              type="button"
              onClick={handleProcessQueue}
              disabled={processingQueue}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-violet-600 px-3.5 text-xs font-semibold text-white transition-colors hover:bg-violet-700 disabled:opacity-60 whitespace-nowrap shrink-0"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${processingQueue ? 'animate-spin' : ''}`} />
              {processingQueue ? 'Processing...' : `Retry Queue (${counts.pending})`}
            </button>
          )}

          {logs.length > 0 && !confirmClear && (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3.5 text-xs font-medium text-zinc-700 transition-colors hover:border-rose-400 hover:text-rose-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:border-rose-500/60 dark:hover:text-rose-400 whitespace-nowrap shrink-0"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Clear Logs
            </button>
          )}

          {confirmClear && (
            <div className="inline-flex items-center gap-1.5 rounded-xl border border-rose-500/30 bg-rose-500/5 px-3 py-1.5">
              <span className="text-xs font-medium text-rose-700 dark:text-rose-300">
                Clear all {logs.length} logs?
              </span>
              <button
                type="button"
                onClick={() => {
                  onClearLogs();
                  setConfirmClear(false);
                }}
                className="rounded-lg bg-rose-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-rose-700 whitespace-nowrap shrink-0"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="rounded-lg px-2 py-1 text-xs font-medium text-zinc-600 hover:bg-zinc-100 dark:text-zinc-300 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div
          role="tablist"
          aria-label="Filter logs by status"
          className="inline-flex w-full overflow-x-auto rounded-xl bg-zinc-100 p-1 sm:w-auto dark:bg-zinc-900"
        >
          {(
            [
              { id: 'all', label: 'All', count: counts.all },
              { id: 'success', label: 'Success', count: counts.success },
              { id: 'pending', label: 'Pending Queue', count: counts.pending },
              { id: 'failed', label: 'Failed', count: counts.failed },
            ] as const
          ).map((tab) => {
            const active = statusFilter === tab.id;
            return (
              <button
                key={tab.id}
                role="tab"
                type="button"
                aria-selected={active}
                onClick={() => setStatusFilter(tab.id)}
                className={`inline-flex h-9 flex-1 items-center justify-center gap-1.5 rounded-lg px-3 text-xs font-medium transition-colors sm:flex-initial whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                    : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                }`}
              >
                <span>{tab.label}</span>
                <span className="font-mono text-[11px] opacity-70 tabular-data">{tab.count}</span>
              </button>
            );
          })}
        </div>

        {/* Search Input */}
        <div className="relative w-full lg:max-w-xs">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-400"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            aria-label="Search webhook logs"
            placeholder="Search sender, message, HTTP status..."
            className="h-11 w-full rounded-xl border border-zinc-200 bg-white pl-9 pr-3.5 text-sm text-zinc-900 outline-none transition-colors focus:border-violet-500 dark:border-zinc-800 dark:bg-[#0D0D10] dark:text-zinc-100"
          />
        </div>
      </div>

      {/* Log List Container */}
      <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white dark:border-zinc-800 dark:bg-[#0D0D10]">
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center px-6 py-16 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-400 dark:border-zinc-800 dark:bg-zinc-900">
              <ScrollText className="h-5 w-5" />
            </div>
            <h2 className="mt-4 text-sm font-semibold text-zinc-950 dark:text-zinc-100">
              {logs.length === 0 ? 'No HTTP delivery logs yet' : 'No logs match your current filter'}
            </h2>
            <p className="mt-1 max-w-sm text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
              {logs.length === 0
                ? 'Run a webhook test in the Simulator or enable background forwarding to inspect full HTTP request and response traces.'
                : 'Try switching status tabs or clearing your search query.'}
            </p>
            {logs.length === 0 && (
              <button
                type="button"
                onClick={() => onNavigate('tester')}
                className="mt-5 inline-flex h-10 items-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
              >
                <FlaskConical className="h-3.5 w-3.5" />
                Open Simulator
              </button>
            )}
          </div>
        ) : (
          <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
            {/* Desktop Table Column Header */}
            <div className="hidden grid-cols-12 gap-4 border-b border-zinc-200 bg-zinc-50/70 px-5 py-2.5 text-xs font-medium text-zinc-500 md:grid dark:border-zinc-800 dark:bg-zinc-900/40 dark:text-zinc-400">
              <div className="col-span-2">Status</div>
              <div className="col-span-2">Sender / SIM</div>
              <div className="col-span-4">Message Preview</div>
              <div className="col-span-2">Endpoint</div>
              <div className="col-span-2 text-right">Latency / Time</div>
            </div>

            {filteredLogs.map((entry) => {
              const statusCodeLabel =
                entry.status === 'success'
                  ? `${entry.response.statusCode ?? 200} OK`
                  : entry.status === 'pending'
                    ? entry.response.statusCode
                      ? `${entry.response.statusCode} Queued`
                      : 'Queued'
                    : entry.response.statusCode
                      ? `${entry.response.statusCode} Err`
                      : 'Failed';

              const statusTone =
                entry.status === 'success'
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : entry.status === 'pending'
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-rose-600 dark:text-rose-400';

              return (
                <button
                  key={entry.id}
                  type="button"
                  onClick={() => onOpenLog(entry)}
                  className="block w-full px-5 py-3.5 text-left transition-colors hover:bg-zinc-50 dark:hover:bg-zinc-900/60"
                >
                  {/* Desktop Row */}
                  <div className="hidden grid-cols-12 items-center gap-4 md:grid">
                    <div className="col-span-2">
                      <span className={`font-mono text-xs font-semibold tabular-data ${statusTone}`}>
                        {statusCodeLabel}
                      </span>
                      {entry.attempts > 1 && (
                        <span className="ml-1.5 font-mono text-[11px] text-zinc-400">
                          ×{entry.attempts}
                        </span>
                      )}
                    </div>
                    <div className="col-span-2 min-w-0">
                      <p className="truncate font-mono text-xs font-semibold text-zinc-950 dark:text-zinc-100">
                        {entry.sms.sender}
                      </p>
                      <p className="mt-0.5 font-mono text-[11px] text-zinc-500 dark:text-zinc-400">
                        {entry.sms.simSlot}
                      </p>
                    </div>
                    <div className="col-span-4 min-w-0">
                      <p className="truncate text-sm text-zinc-700 dark:text-zinc-300">
                        {entry.sms.message}
                      </p>
                    </div>
                    <div className="col-span-2 min-w-0">
                      <p className="truncate text-xs font-medium text-zinc-800 dark:text-zinc-200">
                        {entry.endpointName}
                      </p>
                      <p className="mt-0.5 truncate font-mono text-[11px] text-zinc-400">
                        {entry.mode === 'live' ? 'Live' : 'Dry-Run'}
                      </p>
                    </div>
                    <div className="col-span-2 flex items-center justify-end gap-2 text-right">
                      <div>
                        <p className="font-mono text-xs text-zinc-900 tabular-data dark:text-zinc-200">
                          {entry.response.latencyMs}ms
                        </p>
                        <p className="mt-0.5 font-mono text-[11px] text-zinc-400 tabular-data">
                          {formatTimestampTime(entry.sms.receivedAt)}
                        </p>
                      </div>
                      <ChevronRight className="h-4 w-4 shrink-0 text-zinc-400" aria-hidden="true" />
                    </div>
                  </div>

                  {/* Mobile Row */}
                  <div className="flex items-start justify-between gap-3 md:hidden">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-mono font-semibold text-zinc-950 dark:text-zinc-100">
                          {entry.sms.sender}
                        </span>
                        <span aria-hidden="true" className="text-zinc-400">·</span>
                        <span className="font-mono text-zinc-500 dark:text-zinc-400">
                          {entry.sms.simSlot}
                        </span>
                      </div>
                      <p className="mt-1 line-clamp-2 text-sm text-zinc-700 dark:text-zinc-300">
                        {entry.sms.message}
                      </p>
                      <p className="mt-1 text-[11px] text-zinc-500 dark:text-zinc-400">
                        {entry.endpointName} · {formatRelativeTime(entry.sms.receivedAt)}
                      </p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className={`font-mono text-xs font-semibold tabular-data ${statusTone}`}>
                        {statusCodeLabel}
                      </p>
                      <p className="mt-0.5 font-mono text-[11px] text-zinc-400 tabular-data">
                        {entry.response.latencyMs}ms
                      </p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
