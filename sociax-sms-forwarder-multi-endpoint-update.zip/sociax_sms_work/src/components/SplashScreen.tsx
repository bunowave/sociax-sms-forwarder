import { useEffect, useId, useState } from 'react';
import { motion } from 'motion/react';

interface SplashScreenProps {
  onComplete: () => void;
}

const INIT_STEPS = [
  { atMs: 0, progress: 22, label: 'Initializing Engine...' },
  { atMs: 550, progress: 64, label: 'Loading Profiles...' },
  { atMs: 1180, progress: 100, label: 'Ready' },
] as const;

export function SsfEmblemSvg({ className = 'h-12 w-12' }: { className?: string }) {
  const gradId = useId();
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={gradId} x1="6" y1="6" x2="58" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#8B5CF6" />
          <stop offset="52%" stopColor="#7C3AED" />
          <stop offset="100%" stopColor="#4F46E5" />
        </linearGradient>
      </defs>
      <rect x="4" y="4" width="56" height="56" rx="16" fill={`url(#${gradId})`} />
      <rect
        x="4.75"
        y="4.75"
        width="54.5"
        height="54.5"
        rx="15.25"
        stroke="white"
        strokeOpacity="0.24"
        strokeWidth="1.5"
      />
      {/* Geometric SSF signal bolt / chevron monogram */}
      <path
        d="M21 24.5C21 21.4624 23.4624 19 26.5 19H43L37.5 26H27.5C26.6716 26 26 26.6716 26 27.5C26 28.3284 26.6716 29 27.5 29H37.5C40.5376 29 43 31.4624 43 34.5V39.5C43 42.5376 40.5376 45 37.5 45H21L26.5 38H36.5C37.3284 38 38 37.3284 38 36.5C38 35.6716 37.3284 35 36.5 35H26.5C23.4624 35 21 32.5376 21 29.5V24.5Z"
        fill="white"
      />
    </svg>
  );
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const timers: number[] = [];
    timers.push(window.setTimeout(() => setStepIndex(1), INIT_STEPS[1].atMs));
    timers.push(window.setTimeout(() => setStepIndex(2), INIT_STEPS[2].atMs));
    timers.push(window.setTimeout(() => onComplete(), 1820));
    return () => {
      timers.forEach((id) => window.clearTimeout(id));
    };
  }, [onComplete]);

  const currentStep = INIT_STEPS[stepIndex];

  return (
    <motion.div
      data-testid="splash-screen"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.02 }}
      transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
      className="fixed inset-0 z-[70] flex flex-col items-center justify-between overflow-hidden bg-[#09090B] px-6 py-10 text-zinc-100"
    >
      {/* Subtle top ambient violet glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-600/20 blur-[110px]"
      />

      <div aria-hidden="true" className="h-6" />

      {/* Center Emblem + Title + Loading Bar */}
      <div className="relative z-10 flex w-full max-w-xs flex-col items-center text-center">
        <div className="relative flex items-center justify-center">
          {/* Concentric pulse rings */}
          <motion.div
            aria-hidden="true"
            initial={{ opacity: 0.55, scale: 0.9 }}
            animate={{ opacity: [0.45, 0.12, 0.45], scale: [1, 1.38, 1] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute h-28 w-28 rounded-3xl border border-violet-500/35"
          />
          <motion.div
            aria-hidden="true"
            initial={{ opacity: 0.35, scale: 0.95 }}
            animate={{ opacity: [0.28, 0.05, 0.28], scale: [1.15, 1.65, 1.15] }}
            transition={{ duration: 2.2, delay: 0.3, repeat: Infinity, ease: 'easeInOut' }}
            className="absolute h-32 w-32 rounded-[2rem] border border-indigo-400/20"
          />

          <motion.div
            initial={{ scale: 0.86, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="relative flex h-20 w-20 items-center justify-center rounded-2xl shadow-2xl shadow-violet-600/40"
          >
            <SsfEmblemSvg className="h-20 w-20" />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.12, ease: [0.16, 1, 0.3, 1] }}
          className="mt-8"
        >
          <p className="font-mono text-[11px] font-semibold tracking-[0.26em] text-violet-400">
            SSF
          </p>
          <h1 className="mt-1.5 font-display text-xl font-bold tracking-tight text-white">
            SOCIAX SMS FORWARDER
          </h1>
        </motion.div>

        {/* Crisp Progress Bar & Step Label */}
        <div className="mt-8 w-full">
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-zinc-800/90">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-violet-600 via-violet-500 to-indigo-400"
              initial={{ width: '8%' }}
              animate={{ width: `${currentStep.progress}%` }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            />
          </div>
          <div className="mt-2.5 flex items-center justify-between text-xs">
            <span className="font-medium text-zinc-400">{currentStep.label}</span>
            <span className="font-mono text-[11px] text-zinc-500 tabular-data">
              {currentStep.progress}%
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Branding Lockup */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="relative z-10 flex items-center gap-2.5 text-xs text-zinc-400"
      >
        <span className="font-medium tracking-wide text-zinc-300">A BunoWave Product</span>
        <span className="rounded-full border border-zinc-800 bg-zinc-900/90 px-2 py-0.5 font-mono text-[10px] font-medium text-zinc-400">
          v1.0.0
        </span>
      </motion.div>
    </motion.div>
  );
}
