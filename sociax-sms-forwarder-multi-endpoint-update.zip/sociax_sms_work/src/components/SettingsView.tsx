import { useState } from 'react';
import {
  BellRing,
  Download,
  Eye,
  EyeOff,
  Lock,
  Moon,
  Play,
  Send,
  Shield,
  Sparkles,
  Stethoscope,
  Sun,
  Trash2,
  Upload,
} from 'lucide-react';
import type { AndroidReadinessState, AppSettings, WatchdogChannel } from '../types/ssf';
import {
  serializeBackupConfig,
  type BackupPayloadData,
} from '../utils/webhookEngine';
import { PinLockScreen } from './PinLockScreen';
import { SsfEmblemSvg } from './SplashScreen';

interface SettingsViewProps {
  settings: AppSettings;
  readiness: AndroidReadinessState;
  endpointCount: number;
  logCount: number;
  onToggleTheme: () => void;
  onUpdateDeviceId: (deviceId: string) => void;
  onUpdateWatchdog: (patch: Partial<AppSettings['watchdog']>) => void;
  onTestWatchdog: () => Promise<{ ok: boolean; message: string }>;
  onSetPinLock: (pinHash: string | null) => void;
  onLockNow: () => void;
  onGetBackupData: () => BackupPayloadData;
  onImportBackup: (
    rawText: string,
    passphrase?: string
  ) => { ok: boolean; error?: string; needsPassphrase?: boolean };
  onResetWorkspace: () => void;
  onReplaySplash: () => void;
  onOpenDiagnostics: () => void;
  onOpenWizard: () => void;
}

export function SettingsView({
  settings,
  readiness,
  endpointCount,
  logCount,
  onToggleTheme,
  onUpdateDeviceId,
  onUpdateWatchdog,
  onTestWatchdog,
  onSetPinLock,
  onLockNow,
  onGetBackupData,
  onImportBackup,
  onResetWorkspace,
  onReplaySplash,
  onOpenDiagnostics,
  onOpenWizard,
}: SettingsViewProps) {
  const [deviceDraft, setDeviceDraft] = useState(settings.deviceId);
  const [showBotToken, setShowBotToken] = useState(false);
  const [testingWatchdog, setTestingWatchdog] = useState(false);
  const [showPinSetup, setShowPinSetup] = useState(false);

  const [exportPassphrase, setExportPassphrase] = useState('');
  const [importPassphrase, setImportPassphrase] = useState('');
  const [pendingImportRaw, setPendingImportRaw] = useState<string | null>(null);
  const [importFeedback, setImportFeedback] = useState<{ ok: boolean; text: string } | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleTestWatchdog = async () => {
    setTestingWatchdog(true);
    try {
      await onTestWatchdog();
    } finally {
      setTestingWatchdog(false);
    }
  };

  const handleExportBackup = () => {
    const backup = serializeBackupConfig(onGetBackupData(), exportPassphrase);
    const json = JSON.stringify(backup, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `sociax-ssf-backup-${dateStamp}.ssf.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileChange = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') return;
      const raw = reader.result;
      const result = onImportBackup(raw, importPassphrase);
      if (result.ok) {
        setPendingImportRaw(null);
        setImportFeedback({ ok: true, text: 'Configuration backup restored successfully.' });
      } else if (result.needsPassphrase) {
        setPendingImportRaw(raw);
        setImportFeedback({
          ok: false,
          text: result.error ?? 'Passphrase required to decrypt this .ssf.json file.',
        });
      } else {
        setPendingImportRaw(raw);
        setImportFeedback({ ok: false, text: result.error ?? 'Failed to parse backup file.' });
      }
    };
    reader.readAsText(file);
  };

  const handleDecryptPending = () => {
    if (!pendingImportRaw) return;
    const result = onImportBackup(pendingImportRaw, importPassphrase);
    if (result.ok) {
      setPendingImportRaw(null);
      setImportPassphrase('');
      setImportFeedback({ ok: true, text: 'Encrypted backup decrypted and restored.' });
    } else {
      setImportFeedback({ ok: false, text: result.error ?? 'Decryption failed.' });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
          Settings & Watchdog
        </h1>
        <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
          Manage appearance, device identity, proactive watchdog alerts, PIN lock, and encrypted backups.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: Watchdog Alerts + Backup & Restore */}
        <div className="space-y-6 lg:col-span-7">
          {/* Watchdog Alerts */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6 dark:border-zinc-800 dark:bg-[#0D0D10]">
            <div className="flex items-start justify-between gap-4 border-b border-zinc-200 pb-4 dark:border-zinc-800">
              <div className="flex items-start gap-3">
                <BellRing className="mt-0.5 h-5 w-5 text-violet-600 dark:text-violet-400" aria-hidden="true" />
                <div>
                  <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
                    Watchdog Alerts
                  </h2>
                  <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                    Receive instant alerts on low battery, device downtime, or repeated webhook failures.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-5 space-y-5">
              {/* Alert Channel */}
              <div>
                <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                  Alert Channel
                </span>
                <div className="mt-2 inline-flex rounded-xl bg-zinc-100 p-1 dark:bg-zinc-900">
                  {(
                    [
                      { id: 'disabled', label: 'Disabled' },
                      { id: 'telegram', label: 'Telegram Bot' },
                      { id: 'webhook', label: 'Alert Webhook' },
                    ] as Array<{ id: WatchdogChannel; label: string }>
                  ).map((ch) => (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => onUpdateWatchdog({ channel: ch.id })}
                      className={`h-9 rounded-lg px-3.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                        settings.watchdog.channel === ch.id
                          ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                          : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                      }`}
                    >
                      {ch.label}
                    </button>
                  ))}
                </div>
              </div>

              {settings.watchdog.channel === 'telegram' && (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="wd-tg-token"
                      className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      Telegram Bot Token
                    </label>
                    <div className="relative mt-1.5">
                      <input
                        id="wd-tg-token"
                        type={showBotToken ? 'text' : 'password'}
                        value={settings.watchdog.telegramBotToken}
                        onChange={(e) => onUpdateWatchdog({ telegramBotToken: e.target.value })}
                        placeholder="123456789:AAH..."
                        className="h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 pl-3.5 pr-10 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                      />
                      <button
                        type="button"
                        onClick={() => setShowBotToken((s) => !s)}
                        aria-label={showBotToken ? 'Hide Bot Token' : 'Show Bot Token'}
                        className="absolute right-1.5 top-1.5 flex h-8 w-8 items-center justify-center rounded-md text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                      >
                        {showBotToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="wd-tg-chat"
                      className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      Telegram Chat ID
                    </label>
                    <input
                      id="wd-tg-chat"
                      type="text"
                      value={settings.watchdog.telegramChatId}
                      onChange={(e) => onUpdateWatchdog({ telegramChatId: e.target.value })}
                      placeholder="-1001234567890"
                      className="mt-1.5 h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                    />
                  </div>
                </div>
              )}

              {settings.watchdog.channel === 'webhook' && (
                <div>
                  <label
                    htmlFor="wd-webhook-url"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                  >
                    Alert Webhook URL (HTTPS)
                  </label>
                  <input
                    id="wd-webhook-url"
                    type="url"
                    value={settings.watchdog.alertWebhookUrl}
                    onChange={(e) => onUpdateWatchdog({ alertWebhookUrl: e.target.value })}
                    placeholder="https://alerts.yourdomain.com/ssf-watchdog"
                    className="mt-1.5 h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                  />
                </div>
              )}

              {/* Trigger Rules */}
              <div className="space-y-2.5">
                <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                  Alert Triggers
                </span>
                <div className="divide-y divide-zinc-100 rounded-xl border border-zinc-200 dark:divide-zinc-800 dark:border-zinc-800">
                  <label className="flex cursor-pointer items-center justify-between px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                        Low Battery (&lt; 15%)
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        Alert before Android Doze or shutdown interrupts relay.
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.watchdog.notifyLowBattery}
                      onChange={(e) => onUpdateWatchdog({ notifyLowBattery: e.target.checked })}
                      className="h-4 w-4 accent-violet-600"
                    />
                  </label>

                  <label className="flex cursor-pointer items-center justify-between px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                        Device Offline
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        Notify when cellular/Wi-Fi connectivity drops unexpectedly.
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.watchdog.notifyDeviceOffline}
                      onChange={(e) => onUpdateWatchdog({ notifyDeviceOffline: e.target.checked })}
                      className="h-4 w-4 accent-violet-600"
                    />
                  </label>

                  <label className="flex cursor-pointer items-center justify-between px-4 py-3">
                    <div>
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                        3 Consecutive Webhook Failures
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        Escalate immediately when upstream endpoint rejects 3 events in a row.
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.watchdog.notifyConsecutiveFailures}
                      onChange={(e) =>
                        onUpdateWatchdog({ notifyConsecutiveFailures: e.target.checked })
                      }
                      className="h-4 w-4 accent-violet-600"
                    />
                  </label>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <div className="text-xs text-zinc-500 dark:text-zinc-400">
                  {settings.watchdog.lastTestResult ? (
                    <span
                      className={
                        settings.watchdog.lastTestResult.ok
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-amber-600 dark:text-amber-400'
                      }
                    >
                      {settings.watchdog.lastTestResult.message}
                    </span>
                  ) : (
                    <span>Verify delivery before relying on watchdog rules.</span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={handleTestWatchdog}
                  disabled={testingWatchdog || settings.watchdog.channel === 'disabled'}
                  className="inline-flex h-10 items-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <Send className="h-3.5 w-3.5" />
                  {testingWatchdog ? 'Sending...' : 'Test Alert'}
                </button>
              </div>
            </div>
          </section>

          {/* Backup & Restore (.ssf.json) */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6 dark:border-zinc-800 dark:bg-[#0D0D10]">
            <div className="border-b border-zinc-200 pb-4 dark:border-zinc-800">
              <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
                Backup & Restore (.ssf.json)
              </h2>
              <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                Export all {endpointCount} endpoint profile{endpointCount === 1 ? '' : 's'} and
                watchdog preferences into an encrypted-style checksummed archive.
              </p>
            </div>

            <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2">
              {/* Export */}
              <div className="space-y-3 rounded-xl border border-zinc-200 bg-zinc-50/70 p-4 dark:border-zinc-800 dark:bg-zinc-900/40">
                <h3 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                  Export Configuration
                </h3>
                <div>
                  <label
                    htmlFor="backup-export-pass"
                    className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400"
                  >
                    Optional Encryption Passphrase
                  </label>
                  <input
                    id="backup-export-pass"
                    type="password"
                    value={exportPassphrase}
                    onChange={(e) => setExportPassphrase(e.target.value)}
                    placeholder="Leave blank for standard envelope"
                    className="mt-1 h-10 w-full rounded-lg border border-zinc-200 bg-white px-3 text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleExportBackup}
                  className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-zinc-900 px-4 text-xs font-semibold text-white transition-colors hover:bg-zinc-800 dark:bg-zinc-100 dark:text-zinc-950 dark:hover:bg-white"
                >
                  <Download className="h-3.5 w-3.5" />
                  Export .ssf.json
                </button>
              </div>

              {/* Import */}
              <div className="space-y-3 rounded-xl border border-zinc-200 bg-zinc-50/70 p-4 dark:border-zinc-800 dark:bg-zinc-900/40">
                <h3 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">
                  Import Configuration
                </h3>
                <div>
                  <label
                    htmlFor="backup-import-pass"
                    className="block text-[11px] font-medium text-zinc-600 dark:text-zinc-400"
                  >
                    Decryption Passphrase (if protected)
                  </label>
                  <input
                    id="backup-import-pass"
                    type="password"
                    value={importPassphrase}
                    onChange={(e) => setImportPassphrase(e.target.value)}
                    placeholder="Enter passphrase if encrypted"
                    className="mt-1 h-10 w-full rounded-lg border border-zinc-200 bg-white px-3 text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                  />
                </div>

                {pendingImportRaw ? (
                  <button
                    type="button"
                    onClick={handleDecryptPending}
                    className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-violet-600 px-4 text-xs font-semibold text-white hover:bg-violet-700"
                  >
                    Decrypt & Restore
                  </button>
                ) : (
                  <label className="flex h-10 w-full cursor-pointer items-center justify-center gap-2 rounded-lg border border-zinc-300 bg-white px-4 text-xs font-semibold text-zinc-800 transition-colors hover:border-violet-500 hover:text-violet-600 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-200 dark:hover:border-violet-500 dark:hover:text-violet-400">
                    <Upload className="h-3.5 w-3.5" />
                    Select .ssf.json File
                    <input
                      type="file"
                      accept=".json,.ssf.json,application/json"
                      className="sr-only"
                      onChange={(e) => handleFileChange(e.target.files?.[0])}
                    />
                  </label>
                )}
              </div>
            </div>

            {importFeedback && (
              <p
                role="status"
                className={`mt-3 text-xs font-medium ${
                  importFeedback.ok
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {importFeedback.text}
              </p>
            )}
          </section>
        </div>

        {/* Right Column: Security PIN Lock, Appearance, Device Identity & Native Bridge */}
        <div className="space-y-6 lg:col-span-5">
          {/* App Security — 4-Digit PIN Lock */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6 dark:border-zinc-800 dark:bg-[#0D0D10]">
            <div className="flex items-start gap-3">
              <Shield className="mt-0.5 h-5 w-5 text-violet-600 dark:text-violet-400" aria-hidden="true" />
              <div className="flex-1">
                <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
                  App PIN Lock
                </h2>
                <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                  Lock settings, webhook secrets, and backup tools behind a 4-digit keypad.
                </p>

                <div className="mt-4 flex items-center justify-between rounded-xl border border-zinc-200 bg-zinc-50/70 px-4 py-3 dark:border-zinc-800 dark:bg-zinc-900/50">
                  <div>
                    <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                      4-Digit PIN Protection
                    </p>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">
                      {settings.security.pinEnabled ? 'Active on launch & manual lock' : 'Disabled'}
                    </p>
                  </div>

                  {settings.security.pinEnabled ? (
                    <button
                      type="button"
                      onClick={() => onSetPinLock(null)}
                      className="inline-flex h-9 items-center rounded-lg border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-700 hover:border-rose-400 hover:text-rose-600 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:text-rose-400 whitespace-nowrap shrink-0"
                    >
                      Disable
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowPinSetup(true)}
                      className="inline-flex h-9 items-center rounded-lg bg-violet-600 px-3.5 text-xs font-semibold text-white hover:bg-violet-700 whitespace-nowrap shrink-0"
                    >
                      Set PIN
                    </button>
                  )}
                </div>

                {settings.security.pinEnabled && (
                  <div className="mt-3 flex items-center gap-2">
                    <button
                      type="button"
                      onClick={onLockNow}
                      className="inline-flex h-10 flex-1 items-center justify-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
                    >
                      <Lock className="h-3.5 w-3.5" />
                      Lock App Now
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowPinSetup(true)}
                      className="inline-flex h-10 items-center justify-center rounded-xl border border-zinc-200 px-3.5 text-xs font-medium text-zinc-700 hover:bg-zinc-50 dark:border-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-900 whitespace-nowrap shrink-0"
                    >
                      Change PIN
                    </button>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* Appearance & Device Identity */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6 dark:border-zinc-800 dark:bg-[#0D0D10]">
            <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
              Appearance & Device Identity
            </h2>

            <div className="mt-4 space-y-4">
              {/* Theme Switch */}
              <div className="flex items-center justify-between rounded-xl border border-zinc-200 bg-zinc-50/70 px-4 py-3 dark:border-zinc-800 dark:bg-zinc-900/50">
                <div className="flex items-center gap-3">
                  {settings.theme === 'dark' ? (
                    <Moon className="h-4 w-4 text-violet-400" aria-hidden="true" />
                  ) : (
                    <Sun className="h-4 w-4 text-amber-500" aria-hidden="true" />
                  )}
                  <div>
                    <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                      Interface Theme
                    </p>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">
                      {settings.theme === 'dark' ? 'OLED Dark (#09090B)' : 'Crisp Light Mode'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onToggleTheme}
                  className="inline-flex h-9 items-center rounded-lg border border-zinc-200 bg-white px-3 text-xs font-semibold text-zinc-900 transition-colors hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                >
                  Switch to {settings.theme === 'dark' ? 'Light' : 'Dark'}
                </button>
              </div>

              {/* Device ID */}
              <div>
                <label
                  htmlFor="settings-device-id"
                  className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                >
                  Device Identifier ({`{{device_id}}`})
                </label>
                <div className="mt-1.5 flex gap-2">
                  <input
                    id="settings-device-id"
                    type="text"
                    value={deviceDraft}
                    onChange={(e) => setDeviceDraft(e.target.value)}
                    className="h-10 flex-1 rounded-xl border border-zinc-200 bg-zinc-50 px-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                  />
                  <button
                    type="button"
                    onClick={() => onUpdateDeviceId(deviceDraft)}
                    className="inline-flex h-10 items-center rounded-xl border border-zinc-200 bg-white px-3.5 text-xs font-semibold text-zinc-800 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                  >
                    Save
                  </button>
                </div>
              </div>

              {/* About & Device Info — A BunoWave Product */}
              <div className="rounded-xl border border-zinc-200/90 bg-zinc-50/80 p-4 dark:border-zinc-800 dark:bg-zinc-900/50">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <SsfEmblemSvg className="h-10 w-10 shrink-0" />
                    <div>
                      <p className="text-sm font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
                        SOCIAX SMS FORWARDER
                      </p>
                      <p className="text-xs font-medium text-violet-600 dark:text-violet-400">
                        A BunoWave Product · v1.0.0
                      </p>
                    </div>
                  </div>
                  <span
                    className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-semibold ${
                      readiness.platform === 'android-capacitor'
                        ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                        : 'border-violet-500/30 bg-violet-500/10 text-violet-700 dark:text-violet-300'
                    }`}
                  >
                    {readiness.platform === 'android-capacitor'
                      ? 'Native Capacitor'
                      : 'Web Preview'}
                  </span>
                </div>

                <div className="mt-3.5 grid grid-cols-2 gap-2 border-t border-zinc-200/80 pt-3 text-xs dark:border-zinc-800">
                  <div>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400">Device ID</p>
                    <p className="mt-0.5 truncate font-mono font-semibold text-zinc-900 dark:text-zinc-100">
                      {settings.deviceId}
                    </p>
                  </div>
                  <div>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400">Bridge Engine</p>
                    <p className="mt-0.5 font-mono font-semibold text-zinc-900 dark:text-zinc-100">
                      {readiness.platform === 'android-capacitor' ? 'Android Broadcast' : 'Simulator Fallback'}
                    </p>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={onOpenDiagnostics}
                    className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-violet-600 px-3 text-xs font-semibold text-white hover:bg-violet-700 whitespace-nowrap shrink-0"
                  >
                    <Stethoscope className="h-3.5 w-3.5" />
                    System Health Check
                  </button>
                  <button
                    type="button"
                    onClick={onOpenWizard}
                    className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-800 hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-violet-500" />
                    Setup Wizard
                  </button>
                  <button
                    type="button"
                    onClick={onReplaySplash}
                    className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-zinc-200 bg-white px-3 text-xs font-medium text-zinc-800 hover:bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                  >
                    <Play className="h-3.5 w-3.5 text-violet-500" />
                    Replay Splash
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* Danger Zone: Reset Workspace */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 dark:border-zinc-800 dark:bg-[#0D0D10]">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
                  Reset Local Workspace
                </h2>
                <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                  Deletes {endpointCount} profiles, {logCount} logs, and PIN settings.
                </p>
              </div>
              {!confirmReset ? (
                <button
                  type="button"
                  onClick={() => setConfirmReset(true)}
                  className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-zinc-200 px-3 text-xs font-medium text-rose-600 hover:border-rose-400 hover:bg-rose-50 dark:border-zinc-800 dark:text-rose-400 dark:hover:bg-rose-500/10 whitespace-nowrap shrink-0"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Reset
                </button>
              ) : (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onResetWorkspace();
                      setConfirmReset(false);
                    }}
                    className="inline-flex h-9 items-center rounded-lg bg-rose-600 px-3 text-xs font-semibold text-white hover:bg-rose-700 whitespace-nowrap shrink-0"
                  >
                    Confirm Reset
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmReset(false)}
                    className="inline-flex h-9 items-center rounded-lg px-2.5 text-xs text-zinc-500 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>

      {showPinSetup && (
        <PinLockScreen
          mode="setup"
          storedHash={settings.security.pinHash}
          onPinConfigured={(newHash) => {
            onSetPinLock(newHash);
            setShowPinSetup(false);
          }}
          onCancel={() => setShowPinSetup(false)}
        />
      )}
    </div>
  );
}
