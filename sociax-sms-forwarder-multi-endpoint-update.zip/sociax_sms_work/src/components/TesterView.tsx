import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Plus,
  Send,
  ShieldAlert,
  ShieldCheck,
  Webhook,
} from 'lucide-react';
import type { EndpointProfile, NavTab, SimSlot, WebhookLogEntry } from '../types/ssf';
import type { SimulationOutcome } from '../services/webhookDispatcher';
import { evaluateFilterRules, renderPayloadTemplate } from '../utils/webhookEngine';

interface TesterViewProps {
  endpoints: EndpointProfile[];
  activeEndpointId: string | null;
  deviceId: string;
  onSendTest: (params: {
    profile: EndpointProfile;
    sender: string;
    message: string;
    simSlot: SimSlot;
    mode: 'live' | 'simulated';
    simulationOutcome?: SimulationOutcome;
  }) => Promise<WebhookLogEntry>;
  onNavigate: (tab: NavTab) => void;
  onOpenLog: (log: WebhookLogEntry) => void;
}

// Generic, fully editable neutral example templates (zero hardcoded payment brands or URLs)
const SAMPLE_PRESETS = [
  {
    id: 'receipt',
    label: 'Transaction Receipt',
    sender: 'ALERT-TXN',
    simSlot: 'SIM 1' as SimSlot,
    message: 'Payment received: 1,250.00 from 01700000000. Ref TrxID 9KX482MP. Balance: 14,820.00.',
  },
  {
    id: 'order',
    label: 'Order Dispatch',
    sender: 'DISPATCH-01',
    simSlot: 'SIM 2' as SimSlot,
    message: 'Order #ORD-8824 confirmed and dispatched. Tracking code: TRK-409182.',
  },
  {
    id: 'otp',
    label: 'Personal Code (Filter Test)',
    sender: 'AUTH-MSG',
    simSlot: 'SIM 1' as SimSlot,
    message: 'Your one-time verification code is 492817. Do not share this code.',
  },
];

export function TesterView({
  endpoints,
  activeEndpointId,
  deviceId,
  onSendTest,
  onNavigate,
  onOpenLog,
}: TesterViewProps) {
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>(
    activeEndpointId ?? endpoints[0]?.id ?? ''
  );
  const [sender, setSender] = useState(SAMPLE_PRESETS[0].sender);
  const [message, setMessage] = useState(SAMPLE_PRESETS[0].message);
  const [simSlot, setSimSlot] = useState<SimSlot>('SIM 1');
  const [mode, setMode] = useState<'live' | 'simulated'>('live');
  const [simOutcome, setSimOutcome] = useState<SimulationOutcome>('200_ok');
  const [sending, setSending] = useState(false);
  const [lastResult, setLastResult] = useState<WebhookLogEntry | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);

  useEffect(() => {
    if (!selectedEndpointId && endpoints.length > 0) {
      setSelectedEndpointId(activeEndpointId ?? endpoints[0].id);
    } else if (selectedEndpointId && !endpoints.some((e) => e.id === selectedEndpointId)) {
      setSelectedEndpointId(endpoints[0]?.id ?? '');
    }
  }, [endpoints, activeEndpointId, selectedEndpointId]);

  const selectedProfile = endpoints.find((ep) => ep.id === selectedEndpointId) ?? null;

  const filterCheck = useMemo(() => {
    if (!selectedProfile) return null;
    return evaluateFilterRules(selectedProfile, { sender, message, simSlot });
  }, [selectedProfile, sender, message, simSlot]);

  const mappedPayload = useMemo(() => {
    if (!selectedProfile) return null;
    return renderPayloadTemplate(selectedProfile.payloadTemplate, {
      sender,
      message,
      sim_slot: simSlot,
      timestamp: new Date().toISOString(),
      device_id: deviceId,
    });
  }, [selectedProfile, sender, message, simSlot, deviceId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProfile) return;
    if (!sender.trim() || !message.trim()) {
      setValidationError('Enter both a sample Sender ID and SMS Message.');
      return;
    }
    setValidationError(null);
    setSending(true);
    try {
      const entry = await onSendTest({
        profile: selectedProfile,
        sender: sender.trim(),
        message: message.trim(),
        simSlot,
        mode,
        simulationOutcome: mode === 'simulated' ? simOutcome : undefined,
      });
      setLastResult(entry);
    } finally {
      setSending(false);
    }
  };

  if (endpoints.length === 0) {
    return (
      <div className="space-y-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
            Live Webhook Simulator
          </h1>
          <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
            Dispatch real HTTP POST webhooks or dry-run offline retry scenarios.
          </p>
        </div>

        <div className="flex flex-col items-center justify-center rounded-2xl border border-zinc-200 bg-white px-6 py-16 text-center dark:border-zinc-800 dark:bg-[#0D0D10]">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-400 dark:border-zinc-800 dark:bg-zinc-900">
            <Webhook className="h-5 w-5" />
          </div>
          <h2 className="mt-4 text-base font-semibold text-zinc-950 dark:text-zinc-50">
            Create an endpoint profile first
          </h2>
          <p className="mt-1.5 max-w-md text-sm text-zinc-500 dark:text-zinc-400">
            Configure a webhook URL, custom headers, and JSON payload template in the Endpoints tab
            before running live or simulated deliveries.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('endpoints')}
            className="mt-6 inline-flex h-11 items-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" />
            Go to Endpoints
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
          Live Webhook Simulator
        </h1>
        <p className="mt-1 text-sm text-zinc-500 dark:text-zinc-400">
          Test payload mapping, smart filters, and real HTTPS delivery to your configured server.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Test Builder Form */}
        <form
          onSubmit={handleSubmit}
          noValidate
          className="space-y-5 rounded-2xl border border-zinc-200 bg-white p-5 sm:p-6 lg:col-span-7 dark:border-zinc-800 dark:bg-[#0D0D10]"
        >
          {/* Endpoint Picker */}
          <div>
            <label
              htmlFor="tester-endpoint"
              className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
            >
              Target Endpoint Profile
            </label>
            <select
              id="tester-endpoint"
              value={selectedEndpointId}
              onChange={(e) => setSelectedEndpointId(e.target.value)}
              className="mt-1.5 h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 text-sm font-medium text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
            >
              {endpoints.map((ep) => (
                <option key={ep.id} value={ep.id}>
                  {ep.name} — {ep.url}
                </option>
              ))}
            </select>
          </div>

          {/* Quick-Fill Editable Presets */}
          <div>
            <span className="block text-xs font-medium text-zinc-500 dark:text-zinc-400">
              Quick-Fill Sample Templates (Editable)
            </span>
            <div className="mt-2 flex flex-wrap gap-2">
              {SAMPLE_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setSender(preset.sender);
                    setMessage(preset.message);
                    setSimSlot(preset.simSlot);
                    setValidationError(null);
                  }}
                  className="inline-flex h-9 items-center rounded-lg border border-zinc-200 bg-zinc-50 px-3 text-xs font-medium text-zinc-700 transition-colors hover:border-violet-500 hover:text-violet-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:border-violet-500 dark:hover:text-violet-400 whitespace-nowrap shrink-0"
                >
                  {preset.label}
                </button>
              ))}
            </div>
          </div>

          {/* Sender + SIM Slot */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-12">
            <div className="sm:col-span-7">
              <label
                htmlFor="tester-sender"
                className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
              >
                Sample Sender ID
              </label>
              <input
                id="tester-sender"
                type="text"
                value={sender}
                onChange={(e) => {
                  setSender(e.target.value);
                  setValidationError(null);
                }}
                placeholder="e.g. ALERT-TXN or +15550100"
                className="mt-1.5 h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
              />
            </div>

            <div className="sm:col-span-5">
              <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                SIM Slot
              </span>
              <div className="mt-1.5 grid grid-cols-2 rounded-xl bg-zinc-100 p-1 dark:bg-zinc-900">
                {(['SIM 1', 'SIM 2'] as const).map((slot) => (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => setSimSlot(slot)}
                    className={`h-9 rounded-lg font-mono text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                      simSlot === slot
                        ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                        : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                    }`}
                  >
                    {slot}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Sample SMS Message */}
          <div>
            <label
              htmlFor="tester-message"
              className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
            >
              Sample SMS Message Body
            </label>
            <textarea
              id="tester-message"
              rows={4}
              value={message}
              onChange={(e) => {
                setMessage(e.target.value);
                setValidationError(null);
              }}
              placeholder="Enter sample SMS text..."
              className="mt-1.5 w-full rounded-xl border border-zinc-200 bg-zinc-50 p-3.5 text-sm text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
            />
          </div>

          {/* Smart Filter Live Evaluation */}
          {filterCheck && (
            <div
              className={`flex items-start gap-2.5 rounded-xl border px-3.5 py-3 text-xs ${
                filterCheck.matched
                  ? 'border-emerald-500/25 bg-emerald-500/5 text-emerald-700 dark:text-emerald-300'
                  : 'border-amber-500/30 bg-amber-500/5 text-amber-800 dark:text-amber-300'
              }`}
            >
              {filterCheck.matched ? (
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              ) : (
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              )}
              <div>
                <p className="font-semibold">
                  {filterCheck.matched
                    ? 'Matches profile Smart Filtering Rules'
                    : 'Would be skipped in live background mode'}
                </p>
                {filterCheck.reason && <p className="mt-0.5 opacity-90">{filterCheck.reason}</p>}
              </div>
            </div>
          )}

          {/* Execution Mode */}
          <div className="space-y-3 border-t border-zinc-200 pt-4 dark:border-zinc-800">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <span className="text-xs font-medium text-zinc-700 dark:text-zinc-300">
                Dispatch Mode
              </span>
              <div className="inline-flex rounded-xl bg-zinc-100 p-1 dark:bg-zinc-900">
                <button
                  type="button"
                  onClick={() => setMode('live')}
                  className={`h-9 rounded-lg px-3.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    mode === 'live'
                      ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                      : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                  }`}
                >
                  Live HTTP POST
                </button>
                <button
                  type="button"
                  onClick={() => setMode('simulated')}
                  className={`h-9 rounded-lg px-3.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    mode === 'simulated'
                      ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                      : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                  }`}
                >
                  Simulated Dry-Run
                </button>
              </div>
            </div>

            {mode === 'simulated' && (
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-zinc-500 dark:text-zinc-400">Simulated Response:</span>
                {(
                  [
                    { id: '200_ok', label: '200 OK' },
                    { id: '401_unauthorized', label: '401 Unauthorized' },
                    { id: '500_server_error', label: '500 Server Error' },
                    { id: 'offline_queue', label: 'Offline (Queue)' },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setSimOutcome(opt.id)}
                    className={`h-8 rounded-lg border px-2.5 font-mono text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                      simOutcome === opt.id
                        ? 'border-violet-500 bg-violet-600/10 text-violet-700 dark:text-violet-300'
                        : 'border-zinc-200 text-zinc-600 hover:bg-zinc-50 dark:border-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-900'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            )}

            {mode === 'live' && (
              <p className="text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
                Browser preview performs a real <span className="font-mono">fetch()</span> POST. If
                your server does not emit CORS headers, browser security may block reading the
                response — Capacitor Android APK uses native HTTP without browser CORS limits.
              </p>
            )}
          </div>

          {validationError && (
            <p role="alert" className="text-xs font-medium text-rose-600 dark:text-rose-400">
              {validationError}
            </p>
          )}

          <button
            type="submit"
            disabled={sending}
            className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-violet-600 px-5 text-sm font-semibold text-white transition-colors hover:bg-violet-700 disabled:opacity-60 active:scale-[0.99]"
          >
            <Send className="h-4 w-4" />
            {sending ? 'Sending Webhook...' : 'Send Test Webhook'}
          </button>
        </form>

        {/* Right: Mapped Payload Preview + Live Response Output */}
        <div className="space-y-5 lg:col-span-5">
          {/* Mapped JSON Payload */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 dark:border-zinc-800 dark:bg-[#0D0D10]">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                Mapped JSON Request Body
              </h2>
              <span className="font-mono text-[11px] text-zinc-500 dark:text-zinc-400">
                POST · {selectedProfile?.headers.length ?? 0} custom header
                {(selectedProfile?.headers.length ?? 0) === 1 ? '' : 's'}
              </span>
            </div>
            <pre className="mt-3 max-h-56 overflow-auto rounded-xl border border-zinc-200 bg-zinc-950 p-3.5 font-mono text-xs leading-relaxed text-zinc-100 dark:border-zinc-800">
              {mappedPayload?.rendered ?? '{}'}
            </pre>
          </section>

          {/* Response Inspector Card */}
          <section className="rounded-2xl border border-zinc-200 bg-white p-5 dark:border-zinc-800 dark:bg-[#0D0D10]">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                Response Output
              </h2>
              {lastResult && (
                <button
                  type="button"
                  onClick={() => onOpenLog(lastResult)}
                  className="inline-flex items-center gap-1 text-xs font-medium text-violet-600 hover:text-violet-700 dark:text-violet-400 dark:hover:text-violet-300"
                >
                  Open in Inspector
                  <ExternalLink className="h-3 w-3" />
                </button>
              )}
            </div>

            {!lastResult ? (
              <p className="mt-4 rounded-xl border border-dashed border-zinc-200 px-4 py-8 text-center text-xs text-zinc-500 dark:border-zinc-800 dark:text-zinc-400">
                Send a test webhook to inspect the real HTTP status code, latency, and response body
                here.
              </p>
            ) : (
              <div className="mt-3.5 space-y-3" data-testid="tester-response-panel">
                <div className="flex items-center justify-between border-b border-zinc-100 pb-3 dark:border-zinc-800">
                  <span
                    className={`inline-flex items-center gap-1.5 font-mono text-xs font-semibold tabular-data ${
                      lastResult.status === 'success'
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : lastResult.status === 'pending'
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {lastResult.status === 'success' ? (
                      <CheckCircle2 className="h-4 w-4" />
                    ) : (
                      <AlertTriangle className="h-4 w-4" />
                    )}
                    {lastResult.response.statusCode
                      ? `HTTP ${lastResult.response.statusCode} ${lastResult.response.statusText}`
                      : lastResult.response.statusText}
                  </span>
                  <span className="font-mono text-xs text-zinc-500 tabular-data dark:text-zinc-400">
                    {lastResult.response.latencyMs}ms
                  </span>
                </div>

                {lastResult.response.isCorsHint && (
                  <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3 text-xs leading-relaxed text-amber-800 dark:text-amber-300">
                    <strong>Browser CORS Notice:</strong> Your target server blocked the cross-origin
                    browser request or is unreachable from this web origin. Switch to{' '}
                    <strong>Simulated Dry-Run</strong> to verify queue/logging locally, or build the
                    Capacitor Android APK for unrestricted native HTTP.
                  </div>
                )}

                <pre className="max-h-56 overflow-auto rounded-xl border border-zinc-200 bg-zinc-50 p-3.5 font-mono text-xs leading-relaxed text-zinc-800 dark:border-zinc-800 dark:bg-zinc-900/70 dark:text-zinc-200">
                  {lastResult.response.body ||
                    lastResult.response.error ||
                    '(Empty response body)'}
                </pre>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
