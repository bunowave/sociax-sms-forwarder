import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertTriangle,
  Check,
  Copy,
  Eye,
  EyeOff,
  RefreshCw,
  X,
} from 'lucide-react';
import type { WebhookLogEntry } from '../types/ssf';
import { maskSecretValue } from '../utils/webhookEngine';

interface LogDetailDrawerProps {
  log: WebhookLogEntry | null;
  onClose: () => void;
  onRetry: (logId: string) => Promise<void>;
}

export function LogDetailDrawer({ log, onClose, onRetry }: LogDetailDrawerProps) {
  const [revealedHeaders, setRevealedHeaders] = useState<Record<string, boolean>>({});
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [retrying, setRetrying] = useState(false);

  const toggleReveal = (headerKey: string) => {
    setRevealedHeaders((prev) => ({ ...prev, [headerKey]: !prev[headerKey] }));
  };

  const handleCopy = async (label: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(label);
      window.setTimeout(() => setCopiedKey(null), 1600);
    } catch {
      // fallback ignored
    }
  };

  const handleRetryClick = async () => {
    if (!log) return;
    setRetrying(true);
    try {
      await onRetry(log.id);
    } finally {
      setRetrying(false);
    }
  };

  return (
    <AnimatePresence>
      {log && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="HTTP Log Inspector"
          className="fixed inset-0 z-50 flex items-end justify-end sm:items-stretch"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-[2px]"
          />

          {/* Slide-over drawer (bottom sheet on mobile, right drawer on desktop) */}
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-2xl border-t border-zinc-200 bg-white sm:max-h-full sm:max-w-xl sm:rounded-none sm:border-l sm:border-t-0 dark:border-zinc-800 dark:bg-[#0C0C0F]"
          >
            {/* Header */}
            <div className="flex items-center justify-between gap-4 border-b border-zinc-200 px-5 py-4 dark:border-zinc-800">
              <div className="min-w-0">
                <h2 className="truncate text-base font-semibold text-zinc-950 dark:text-zinc-50">
                  HTTP Delivery Inspector
                </h2>
                <div className="mt-0.5 flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400">
                  <span className="truncate">{log.endpointName}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-data">
                    {log.mode === 'live' ? 'Live POST' : 'Simulated Dry-Run'}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close log inspector"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Pinned Status Summary Strip */}
            <div className="grid grid-cols-3 gap-3 border-b border-zinc-200 bg-zinc-50/70 px-5 py-3 dark:border-zinc-800 dark:bg-zinc-900/40">
              <div>
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400">HTTP Status</p>
                <p
                  className={`mt-0.5 font-mono text-xs font-semibold tabular-data ${
                    log.status === 'success'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : log.status === 'pending'
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {log.response.statusCode
                    ? `${log.response.statusCode} ${log.response.statusText}`
                    : log.response.statusText}
                </p>
              </div>
              <div>
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400">Latency</p>
                <p className="mt-0.5 font-mono text-xs font-semibold text-zinc-950 tabular-data dark:text-zinc-100">
                  {log.response.latencyMs}ms
                </p>
              </div>
              <div>
                <p className="text-[11px] text-zinc-500 dark:text-zinc-400">Attempts</p>
                <p className="mt-0.5 font-mono text-xs font-semibold text-zinc-950 tabular-data dark:text-zinc-100">
                  {log.attempts} / {Math.max(1, log.maxRetries)}
                </p>
              </div>
            </div>

            {/* Body */}
            <div className="flex-1 space-y-6 overflow-y-auto px-5 py-5">

              {/* Raw SMS Envelope */}
              <section>
                <h3 className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
                  Raw SMS Message
                </h3>
                <div className="mt-2.5 rounded-xl border border-zinc-200 bg-zinc-50/70 p-4 dark:border-zinc-800 dark:bg-zinc-900/50">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-500 dark:text-zinc-400">
                    <span className="font-mono font-semibold text-zinc-900 dark:text-zinc-100">
                      {log.sms.sender}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{log.sms.simSlot}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-data">
                      {new Date(log.sms.receivedAt).toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-2.5 whitespace-pre-wrap break-words text-sm leading-relaxed text-zinc-900 dark:text-zinc-100">
                    {log.sms.message}
                  </p>
                </div>
              </section>

              {/* Request Details */}
              <section>
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
                    Outgoing Request
                  </h3>
                  <button
                    type="button"
                    onClick={() => handleCopy('url', log.request.url)}
                    className="inline-flex items-center gap-1 text-xs font-medium text-violet-600 hover:text-violet-700 dark:text-violet-400 dark:hover:text-violet-300"
                  >
                    {copiedKey === 'url' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                    {copiedKey === 'url' ? 'Copied URL' : 'Copy URL'}
                  </button>
                </div>
                <div className="mt-2 rounded-lg border border-zinc-200 bg-zinc-50 px-3 py-2 font-mono text-xs text-zinc-800 break-all dark:border-zinc-800 dark:bg-zinc-900/70 dark:text-zinc-200">
                  <span className="mr-2 font-semibold text-violet-600 dark:text-violet-400">
                    {log.request.method}
                  </span>
                  {log.request.url}
                </div>

                {/* Headers Table */}
                <div className="mt-4">
                  <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                    Request Headers ({log.request.headers.length})
                  </p>
                  <div className="mt-2 divide-y divide-zinc-200 rounded-xl border border-zinc-200 bg-white dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900/40">
                    {log.request.headers.map((hdr, index) => {
                      const rowId = `${hdr.key}-${index}`;
                      const isRevealed = Boolean(revealedHeaders[rowId]);
                      const displayValue =
                        hdr.isSecret && !isRevealed ? maskSecretValue(hdr.value) : hdr.value;
                      return (
                        <div
                          key={rowId}
                          className="flex items-center justify-between gap-3 px-3.5 py-2.5 text-xs"
                        >
                          <div className="min-w-0 flex-1">
                            <span className="font-mono font-medium text-zinc-900 dark:text-zinc-200">
                              {hdr.key}
                            </span>
                            <p className="mt-0.5 truncate font-mono text-zinc-500 dark:text-zinc-400">
                              {displayValue}
                            </p>
                          </div>
                          {hdr.isSecret && (
                            <button
                              type="button"
                              onClick={() => toggleReveal(rowId)}
                              aria-label={isRevealed ? `Hide ${hdr.key}` : `Reveal ${hdr.key}`}
                              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
                            >
                              {isRevealed ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* JSON Body Sent */}
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                      JSON Payload Sent
                    </p>
                    <button
                      type="button"
                      onClick={() => handleCopy('body', log.request.body)}
                      className="inline-flex items-center gap-1 text-xs font-medium text-violet-600 hover:text-violet-700 dark:text-violet-400 dark:hover:text-violet-300"
                    >
                      {copiedKey === 'body' ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                      {copiedKey === 'body' ? 'Copied JSON' : 'Copy JSON'}
                    </button>
                  </div>
                  <pre className="mt-2 max-h-56 overflow-auto whitespace-pre-wrap break-words rounded-xl border border-zinc-200 bg-zinc-950 p-3.5 font-mono text-xs leading-relaxed text-zinc-100 dark:border-zinc-800">
                    {log.request.body}
                  </pre>
                </div>
              </section>

              {/* Response Details */}
              <section>
                <h3 className="text-xs font-semibold text-zinc-500 dark:text-zinc-400">
                  Server Response
                </h3>

                {log.response.error && (
                  <div className="mt-2.5 flex items-start gap-2.5 rounded-xl border border-rose-500/30 bg-rose-500/5 p-3.5 text-xs text-rose-700 dark:text-rose-300">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                    <div className="space-y-1">
                      <p className="font-medium">{log.response.error}</p>
                      {log.response.isCorsHint && (
                        <p className="text-rose-600/90 dark:text-rose-300/80">
                          Browser preview enforces CORS headers on cross-origin POST requests. When
                          bundled via Capacitor Android APK, native HTTP bypasses browser CORS.
                        </p>
                      )}
                    </div>
                  </div>
                )}

                <pre className="mt-2.5 max-h-52 overflow-auto whitespace-pre-wrap break-words rounded-xl border border-zinc-200 bg-zinc-50 p-3.5 font-mono text-xs leading-relaxed text-zinc-800 dark:border-zinc-800 dark:bg-zinc-900/70 dark:text-zinc-200">
                  {log.response.body || '(Empty response body)'}
                </pre>
              </section>
            </div>

            {/* Footer actions */}
            <div className="flex items-center justify-between gap-3 border-t border-zinc-200 bg-zinc-50/70 px-5 py-3.5 dark:border-zinc-800 dark:bg-zinc-950/70">
              <span className="font-mono text-xs text-zinc-500 dark:text-zinc-400">
                ID: {log.id}
              </span>
              <div className="flex items-center gap-2">
                {(log.status === 'failed' || log.status === 'pending') && (
                  <button
                    type="button"
                    onClick={handleRetryClick}
                    disabled={retrying}
                    className="inline-flex h-10 items-center gap-2 rounded-lg bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 disabled:opacity-60 whitespace-nowrap shrink-0"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${retrying ? 'animate-spin' : ''}`} />
                    {retrying ? 'Retrying...' : 'Retry Now'}
                  </button>
                )}
                <button
                  type="button"
                  onClick={onClose}
                  className="inline-flex h-10 items-center rounded-lg border border-zinc-200 bg-white px-4 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-100 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                >
                  Close
                </button>
              </div>
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}
