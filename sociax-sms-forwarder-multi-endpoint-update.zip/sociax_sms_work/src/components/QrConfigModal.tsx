import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Check, Copy, Download, QrCode, Upload, X } from 'lucide-react';
import type { EndpointProfile } from '../types/ssf';
import { encodeEndpointQrPayload, parseQrConfigPayload } from '../utils/webhookEngine';

interface QrConfigModalProps {
  mode: 'export' | 'import';
  profile?: EndpointProfile | null;
  onClose: () => void;
  onImportProfile: (profileData: Omit<EndpointProfile, 'id' | 'createdAt' | 'updatedAt'>) => void;
}

export function QrConfigModal({
  mode,
  profile,
  onClose,
  onImportProfile,
}: QrConfigModalProps) {
  const [activeTab, setActiveTab] = useState<'export' | 'import'>(mode);
  const [qrSvg, setQrSvg] = useState<string>('');
  const [qrError, setQrError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const [importText, setImportText] = useState('');
  const [importError, setImportError] = useState<string | null>(null);

  const encodedPayload = profile ? encodeEndpointQrPayload(profile) : '';

  useEffect(() => {
    if (activeTab !== 'export' || !encodedPayload) {
      setQrSvg('');
      return;
    }
    let cancelled = false;
    QRCode.toString(encodedPayload, {
      type: 'svg',
      margin: 2,
      width: 240,
      color: { dark: '#09090B', light: '#FFFFFF' },
    })
      .then((svg) => {
        if (!cancelled) {
          setQrSvg(svg);
          setQrError(null);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setQrError('Payload exceeds QR capacity. Copy the JSON config string below instead.');
        }
      });

    return () => {
      cancelled = true;
    };
  }, [activeTab, encodedPayload]);

  const handleCopyPayload = async () => {
    if (!encodedPayload) return;
    try {
      await navigator.clipboard.writeText(encodedPayload);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      // ignore
    }
  };

  const handleDownloadJson = () => {
    if (!profile || !encodedPayload) return;
    const blob = new Blob([encodedPayload], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${profile.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.ssf-profile.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setImportText(reader.result);
        setImportError(null);
      }
    };
    reader.readAsText(file);
  };

  const handleApplyImport = () => {
    const parsed = parseQrConfigPayload(importText);
    if (!parsed.ok) {
      setImportError(parsed.error);
      return;
    }
    onImportProfile(parsed.profile);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="QR Code Configuration"
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 backdrop-blur-sm sm:items-center sm:p-4"
    >
      <div className="w-full max-w-lg overflow-hidden rounded-t-3xl border border-zinc-200 bg-white shadow-2xl sm:rounded-2xl dark:border-zinc-800 dark:bg-[#0D0D12]">
        <div
          aria-hidden="true"
          className="h-[2px] w-full bg-gradient-to-r from-transparent via-violet-500/70 to-transparent"
        />
        <div className="flex justify-center pt-2.5 sm:hidden" aria-hidden="true">
          <div className="h-1 w-10 rounded-full bg-zinc-300 dark:bg-zinc-700" />
        </div>
        <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <QrCode className="h-4 w-4 text-violet-600 dark:text-violet-400" aria-hidden="true" />
            <h2 className="text-base font-semibold text-zinc-950 dark:text-zinc-50">
              QR Config Transfer
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close QR Config modal"
            className="flex h-10 w-10 items-center justify-center rounded-lg text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Mode switcher */}
        {profile && (
          <div className="border-b border-zinc-200 px-5 py-3 dark:border-zinc-800">
            <div className="inline-flex rounded-lg bg-zinc-100 p-1 dark:bg-zinc-900">
              <button
                type="button"
                onClick={() => setActiveTab('export')}
                className={`rounded-md px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'export'
                    ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                    : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                }`}
              >
                QR Export ({profile.name})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('import')}
                className={`rounded-md px-3.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === 'import'
                    ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                    : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                }`}
              >
                Import QR / JSON
              </button>
            </div>
          </div>
        )}

        <div className="p-5">
          {activeTab === 'export' && profile ? (
            <div className="space-y-4">
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                Scan this QR code on another SOCIAX SMS Forwarder device to provision{' '}
                <span className="font-medium text-zinc-950 dark:text-zinc-100">{profile.name}</span>{' '}
                including headers, template, filters, and retry rules.
              </p>

              <div className="flex flex-col items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 p-6 dark:border-zinc-800 dark:bg-zinc-900/60">
                {qrSvg ? (
                  <div
                    className="overflow-hidden rounded-xl border border-zinc-200 bg-white p-3 shadow-xs"
                    data-testid="qr-code-svg"
                    dangerouslySetInnerHTML={{ __html: qrSvg }}
                  />
                ) : (
                  <p className="text-center text-xs text-amber-600 dark:text-amber-400">
                    {qrError ?? 'Generating QR code...'}
                  </p>
                )}
                <p className="mt-3 max-w-xs truncate font-mono text-xs text-zinc-500 dark:text-zinc-400">
                  {profile.url}
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={handleCopyPayload}
                  className="inline-flex h-10 items-center gap-2 rounded-lg border border-zinc-200 bg-white px-3.5 text-xs font-medium text-zinc-800 transition-colors hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? 'Copied Config JSON' : 'Copy Config JSON'}
                </button>
                <button
                  type="button"
                  onClick={handleDownloadJson}
                  className="inline-flex h-10 items-center gap-2 rounded-lg bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
                >
                  <Download className="h-3.5 w-3.5" />
                  Download JSON
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-zinc-600 dark:text-zinc-400">
                Paste a scanned SSF QR JSON string or load a <span className="font-mono text-xs">.json</span>{' '}
                profile file to provision an endpoint in seconds.
              </p>

              <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-zinc-300 bg-zinc-50 px-4 py-3 text-xs font-medium text-zinc-700 transition-colors hover:border-violet-500 hover:text-violet-600 dark:border-zinc-700 dark:bg-zinc-900/50 dark:text-zinc-300 dark:hover:border-violet-500 dark:hover:text-violet-400">
                <Upload className="h-4 w-4" />
                <span>Upload Profile JSON File</span>
                <input
                  type="file"
                  accept=".json,application/json"
                  className="sr-only"
                  onChange={(e) => handleFileUpload(e.target.files?.[0])}
                />
              </label>

              <div>
                <label
                  htmlFor="qr-import-json"
                  className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                >
                  Scanned QR / JSON Payload
                </label>
                <textarea
                  id="qr-import-json"
                  rows={6}
                  value={importText}
                  onChange={(e) => {
                    setImportText(e.target.value);
                    setImportError(null);
                  }}
                  placeholder='{"v":1,"t":"ssf-endpoint","n":"Production Hook","u":"https://api.yourdomain.com/sms",...}'
                  className="mt-1.5 w-full rounded-xl border border-zinc-200 bg-zinc-50 p-3 font-mono text-xs text-zinc-900 outline-none transition-colors focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                />
                {importError && (
                  <p role="alert" className="mt-1.5 text-xs font-medium text-rose-600 dark:text-rose-400">
                    {importError}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="inline-flex h-10 items-center rounded-lg border border-zinc-200 px-4 text-xs font-medium text-zinc-700 transition-colors hover:bg-zinc-100 dark:border-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-900 whitespace-nowrap shrink-0"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleApplyImport}
                  className="inline-flex h-10 items-center gap-2 rounded-lg bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
                >
                  Import Profile
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
