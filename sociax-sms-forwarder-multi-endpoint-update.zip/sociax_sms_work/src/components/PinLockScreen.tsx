import { useCallback, useEffect, useState } from 'react';
import { Delete, Lock, ShieldCheck, X } from 'lucide-react';
import { motion } from 'motion/react';
import { hashPin, verifyPin } from '../utils/webhookEngine';

interface PinLockScreenProps {
  mode: 'unlock' | 'setup';
  storedHash: string | null;
  onUnlock?: () => void;
  onPinConfigured?: (newHash: string) => void;
  onCancel?: () => void;
}

const KEYPAD_DIGITS = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

export function PinLockScreen({
  mode,
  storedHash,
  onUnlock,
  onPinConfigured,
  onCancel,
}: PinLockScreenProps) {
  const [digits, setDigits] = useState<string>('');
  const [firstPin, setFirstPin] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [shakeCount, setShakeCount] = useState(0);

  const triggerError = useCallback((msg: string) => {
    setError(msg);
    setShakeCount((c) => c + 1);
    setDigits('');
  }, []);

  const handleDigit = useCallback(
    (d: string) => {
      setError(null);
      setDigits((prev) => {
        if (prev.length >= 4) return prev;
        const next = prev + d;

        if (next.length === 4) {
          window.setTimeout(() => {
            if (mode === 'unlock') {
              if (verifyPin(next, storedHash)) {
                onUnlock?.();
              } else {
                triggerError('Incorrect 4-digit PIN. Try again.');
              }
            } else {
              if (firstPin === null) {
                setFirstPin(next);
                setDigits('');
              } else if (firstPin === next) {
                onPinConfigured?.(hashPin(next));
              } else {
                setFirstPin(null);
                triggerError('PIN entries did not match. Start again.');
              }
            }
          }, 120);
        }
        return next;
      });
    },
    [mode, storedHash, firstPin, onUnlock, onPinConfigured, triggerError]
  );

  const handleBackspace = useCallback(() => {
    setError(null);
    setDigits((prev) => prev.slice(0, -1));
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (e.key === 'Escape' && mode === 'setup' && onCancel) {
        onCancel();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleDigit, handleBackspace, mode, onCancel]);

  const title =
    mode === 'unlock'
      ? 'Unlock SOCIAX SMS Forwarder'
      : firstPin === null
        ? 'Create 4-Digit Security PIN'
        : 'Confirm 4-Digit PIN';

  const subtitle =
    mode === 'unlock'
      ? 'Enter your 4-digit PIN to access endpoints, API headers, and settings.'
      : firstPin === null
        ? 'Protects webhook secrets, export backups, and forwarding controls.'
        : 'Re-enter the same 4-digit PIN to confirm.';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={title}
      className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-50/95 p-4 backdrop-blur-md dark:bg-[#09090B]/95"
    >
      <motion.div
        key={shakeCount}
        animate={shakeCount > 0 ? { x: [0, -8, 8, -5, 5, 0] } : { x: 0 }}
        transition={{ duration: 0.28 }}
        className="relative w-full max-w-sm rounded-2xl border border-zinc-200 bg-white p-6 shadow-2xl shadow-zinc-950/10 dark:border-zinc-800 dark:bg-zinc-950 dark:shadow-black/60"
      >
        {mode === 'setup' && onCancel && (
          <button
            type="button"
            onClick={onCancel}
            aria-label="Cancel PIN setup"
            className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-lg text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-zinc-100"
          >
            <X className="h-4 w-4" />
          </button>
        )}

        <div className="flex flex-col items-center text-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl border border-violet-500/20 bg-violet-600/10 text-violet-600 dark:text-violet-400">
            {mode === 'unlock' ? <Lock className="h-5 w-5" /> : <ShieldCheck className="h-5 w-5" />}
          </div>
          <h2 className="text-lg font-semibold tracking-tight text-zinc-950 dark:text-zinc-50">
            {title}
          </h2>
          <p className="mt-1.5 text-sm text-zinc-500 dark:text-zinc-400">{subtitle}</p>

          {/* 4-dot PIN indicator */}
          <div className="mt-6 flex items-center gap-3.5" aria-label={`${digits.length} of 4 digits entered`}>
            {[0, 1, 2, 3].map((idx) => {
              const filled = idx < digits.length;
              return (
                <div
                  key={idx}
                  className={`h-3.5 w-3.5 rounded-full border transition-all duration-150 ${
                    filled
                      ? 'scale-110 border-violet-600 bg-violet-600 dark:border-violet-500 dark:bg-violet-500'
                      : 'border-zinc-300 bg-transparent dark:border-zinc-700'
                  }`}
                />
              );
            })}
          </div>

          <div className="mt-3 min-h-[20px]">
            {error && (
              <p role="alert" className="text-xs font-medium text-rose-600 dark:text-rose-400">
                {error}
              </p>
            )}
          </div>
        </div>

        {/* Numeric keypad */}
        <div className="mt-5 grid grid-cols-3 gap-2.5">
          {KEYPAD_DIGITS.map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigit(digit)}
              aria-label={`Digit ${digit}`}
              className="flex h-14 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 font-mono text-lg font-semibold text-zinc-900 transition-colors hover:bg-zinc-100 active:scale-[0.97] dark:border-zinc-800 dark:bg-zinc-900/70 dark:text-zinc-100 dark:hover:bg-zinc-800"
            >
              {digit}
            </button>
          ))}
          <div aria-hidden="true" />
          <button
            type="button"
            onClick={() => handleDigit('0')}
            aria-label="Digit 0"
            className="flex h-14 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 font-mono text-lg font-semibold text-zinc-900 transition-colors hover:bg-zinc-100 active:scale-[0.97] dark:border-zinc-800 dark:bg-zinc-900/70 dark:text-zinc-100 dark:hover:bg-zinc-800"
          >
            0
          </button>
          <button
            type="button"
            onClick={handleBackspace}
            aria-label="Backspace"
            className="flex h-14 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-600 transition-colors hover:bg-zinc-100 hover:text-zinc-900 active:scale-[0.97] dark:border-zinc-800 dark:bg-zinc-900/70 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
          >
            <Delete className="h-5 w-5" />
          </button>
        </div>
      </motion.div>
    </div>
  );
}
