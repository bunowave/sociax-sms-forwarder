import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Activity,
  ArrowUpRight,
  BatteryCharging,
  ChevronRight,
  Cpu,
  FlaskConical,
  Globe,
  MessageSquarePlus,
  Plus,
  Power,
  Radio,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Stethoscope,
  Webhook,
} from 'lucide-react';
import type {
  AndroidReadinessState,
  ConnectionEngineState,
  EndpointProfile,
  NavTab,
  WebhookLogEntry,
} from '../types/ssf';
import type { HeartbeatState } from '../hooks/useSsfStore';
import {
  computeDashboardKpis,
  extractEndpointDomain,
  formatRelativeTime,
  formatTimestampTime,
  formatUptime,
} from '../utils/webhookEngine';
import { LatencySparklineCard } from './LatencySparklineCard';

interface DashboardViewProps {
  masterActive: boolean;
  connectionState: ConnectionEngineState;
  connectedSince: number | null;
  endpoints: EndpointProfile[];
  activeEndpoint: EndpointProfile | null;
  logs: WebhookLogEntry[];
  readiness: AndroidReadinessState;
  heartbeat: HeartbeatState;
  onToggleMaster: () => void;
  onCheckHeartbeat: () => void;
  onSelectEndpoint: (id: string) => void;
  onNavigate: (tab: NavTab) => void;
  onOpenLog: (log: WebhookLogEntry) => void;
  onOpenDiagnostics: () => void;
  onOpenWizard: () => void;
  onSimulateIncomingSms: () => Promise<WebhookLogEntry | null>;
  onGrantSmsPermissions: () => void;
  onBypassBattery: () => void;
  onToggleBootAutoStart: () => void;
}

export function DashboardView({
  masterActive,
  connectionState,
  connectedSince,
  endpoints,
  activeEndpoint,
  logs,
  readiness,
  heartbeat,
  onToggleMaster,
  onCheckHeartbeat,
  onSelectEndpoint,
  onNavigate,
  onOpenLog,
  onOpenDiagnostics,
  onOpenWizard,
  onSimulateIncomingSms,
  onGrantSmsPermissions,
  onBypassBattery,
  onToggleBootAutoStart,
}: DashboardViewProps) {
  const kpis = computeDashboardKpis(logs);
  const recentLogs = logs.slice(0, 8);
  const [uptimeSeconds, setUptimeSeconds] = useState(0);
  const [simulatingSms, setSimulatingSms] = useState(false);

  // Live 1s uptime counter when connected
  useEffect(() => {
    if (!connectedSince || connectionState === 'standby') {
      setUptimeSeconds(0);
      return;
    }
    const tick = () => {
      setUptimeSeconds(Math.max(0, Math.floor((Date.now() - connectedSince) / 1000)));
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [connectedSince, connectionState]);

  const handleQuickSimSms = async () => {
    if (simulatingSms) return;
    setSimulatingSms(true);
    try {
      await onSimulateIncomingSms();
    } finally {
      setSimulatingSms(false);
    }
  };

  const readinessPassedCount = [
    readiness.smsPermissionGranted,
    readiness.batteryOptimizationBypassed,
    readiness.bootAutoStartEnabled,
  ].filter(Boolean).length;

  const activeSimBadge =
    activeEndpoint?.simFilter === 'SIM_1'
      ? 'SIM 1 Only'
      : activeEndpoint?.simFilter === 'SIM_2'
        ? 'SIM 2 Only'
        : 'SIM 1 & 2';

  // Ambient aura and state config for Live Connection Command Card
  const auraConfig = {
    standby: {
      headline: 'Relay Standby',
      subtitle: activeEndpoint
        ? 'Tap Connect to establish live SMS-to-Webhook forwarding.'
        : 'Connect an HTTPS server to begin real-time forwarding.',
      badgeLabel: 'STANDBY',
      badgeClass:
        'border-zinc-300/80 bg-zinc-100 text-zinc-600 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-400',
      glowStyle:
        'bg-[radial-gradient(ellipse_at_top_left,rgba(113,113,122,0.14),transparent_62%)] dark:bg-[radial-gradient(ellipse_at_top_left,rgba(113,113,122,0.18),transparent_62%)]',
      topBorder: 'from-transparent via-zinc-400/40 to-transparent',
      btnClass:
        'border-zinc-300 bg-zinc-100 text-zinc-700 hover:bg-zinc-200 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:bg-zinc-800',
    },
    connecting: {
      headline: 'Establishing Handshake...',
      subtitle: 'Verifying TLS endpoint reachability and arming foreground listener.',
      badgeLabel: 'CONNECTING',
      badgeClass:
        'border-amber-500/30 bg-amber-500/15 text-amber-700 dark:text-amber-300',
      glowStyle:
        'bg-[radial-gradient(ellipse_at_top_left,rgba(245,158,11,0.22),transparent_65%)]',
      topBorder: 'from-transparent via-amber-500/70 to-transparent',
      btnClass:
        'border-amber-500/50 bg-amber-500 text-white shadow-xl shadow-amber-500/30',
    },
    connected: {
      headline: 'Connected & Listening',
      subtitle: 'Zero-loss SMS relay active with automatic offline retry worker.',
      badgeLabel: 'LIVE',
      badgeClass:
        'border-emerald-500/35 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300',
      glowStyle:
        'bg-[radial-gradient(ellipse_at_top_left,rgba(16,185,129,0.20),transparent_55%),radial-gradient(ellipse_at_bottom_right,rgba(124,58,237,0.24),transparent_60%)]',
      topBorder: 'from-emerald-400/60 via-violet-500/80 to-indigo-500/60',
      btnClass:
        'border-violet-400/50 bg-gradient-to-br from-violet-600 to-indigo-600 text-white shadow-xl shadow-violet-600/35 hover:brightness-110',
    },
    degraded: {
      headline: 'Connection Degraded',
      subtitle: 'Upstream webhook reported consecutive errors or probe timeout.',
      badgeLabel: 'DEGRADED',
      badgeClass:
        'border-rose-500/35 bg-rose-500/15 text-rose-700 dark:text-rose-300',
      glowStyle:
        'bg-[radial-gradient(ellipse_at_top_left,rgba(244,63,94,0.24),transparent_65%)]',
      topBorder: 'from-transparent via-rose-500/80 to-transparent',
      btnClass:
        'border-rose-500/50 bg-rose-600 text-white shadow-xl shadow-rose-600/30 hover:bg-rose-700',
    },
  }[connectionState];

  return (
    <div className="space-y-6 pb-8">
      {/* LIVE CONNECTION COMMAND CARD */}
      <section
        data-testid="live-connection-card"
        data-connection-state={connectionState}
        className="relative overflow-hidden rounded-3xl border border-zinc-200/90 bg-white/90 p-5 shadow-sm backdrop-blur-xl sm:p-6 dark:border-zinc-800/90 dark:bg-[#0E0E13]/90 dark:shadow-2xl dark:shadow-black/40"
      >
        {/* Dynamic Ambient Radial Glow */}
        <div
          aria-hidden="true"
          className={`pointer-events-none absolute inset-0 transition-all duration-500 ${auraConfig.glowStyle}`}
        />
        {/* Delicate Gradient Top Highlight */}
        <div
          aria-hidden="true"
          className={`pointer-events-none absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r ${auraConfig.topBorder}`}
        />

        <div className="relative z-10 flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          {/* Left: Big Tactile Power / Connect Button + Live Status */}
          <div className="flex items-start gap-4 sm:gap-5">
            <div className="relative shrink-0">
              {/* Connecting amber radar pulse */}
              {connectionState === 'connecting' && (
                <motion.span
                  aria-hidden="true"
                  animate={{ scale: [1, 1.55], opacity: [0.65, 0] }}
                  transition={{ duration: 1.1, repeat: Infinity, ease: 'easeOut' }}
                  className="pointer-events-none absolute inset-0 rounded-2xl border-2 border-amber-400"
                />
              )}
              {/* Connected emerald+violet gentle pulse ring */}
              {connectionState === 'connected' && (
                <motion.span
                  aria-hidden="true"
                  animate={{ scale: [1, 1.28], opacity: [0.45, 0] }}
                  transition={{ duration: 2.2, repeat: Infinity, ease: 'easeOut' }}
                  className="pointer-events-none absolute inset-0 rounded-2xl border border-violet-400/70"
                />
              )}

              <button
                type="button"
                onClick={onToggleMaster}
                aria-pressed={masterActive}
                aria-label={masterActive ? 'Pause SMS Forwarding' : 'Activate SMS Forwarding'}
                className={`relative flex h-16 w-16 items-center justify-center rounded-2xl border transition-all duration-200 active:scale-[0.96] ${auraConfig.btnClass}`}
              >
                <Power className="h-7 w-7" />
                {connectionState === 'connected' && (
                  <span
                    aria-hidden="true"
                    className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center"
                  >
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                    <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-[#0E0E13]" />
                  </span>
                )}
              </button>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-zinc-950 sm:text-2xl dark:text-zinc-50">
                  {auraConfig.headline}
                </h1>
                <button
                  type="button"
                  onClick={onOpenDiagnostics}
                  className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 font-mono text-[10px] font-bold tracking-wider transition-opacity hover:opacity-85 ${auraConfig.badgeClass}`}
                >
                  <span
                    aria-hidden="true"
                    className={`h-1.5 w-1.5 rounded-full ${
                      connectionState === 'connected'
                        ? 'bg-emerald-500'
                        : connectionState === 'connecting'
                          ? 'animate-pulse bg-amber-500'
                          : connectionState === 'degraded'
                            ? 'bg-rose-500'
                            : 'bg-zinc-400'
                    }`}
                  />
                  {auraConfig.badgeLabel}
                </button>
              </div>

              <p className="mt-1 text-xs leading-relaxed text-zinc-600 sm:text-sm dark:text-zinc-400">
                {auraConfig.subtitle}
              </p>

              {/* Live Telemetry Strip: Uptime + Domain Pill + SIM Badge + Heartbeat Ping */}
              <div className="mt-3 flex flex-wrap items-center gap-2">
                {connectionState === 'connected' && (
                  <span
                    data-testid="live-uptime-timer"
                    className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/25 bg-emerald-500/10 px-2.5 py-1 font-mono text-[11px] font-semibold text-emerald-700 tabular-data dark:text-emerald-300"
                  >
                    <Radio className="h-3 w-3 animate-pulse" aria-hidden="true" />
                    UPTIME {formatUptime(uptimeSeconds)}
                  </span>
                )}

                {activeEndpoint && (
                  <>
                    <span className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-zinc-50/90 px-2.5 py-1 font-mono text-[11px] font-medium text-zinc-700 dark:border-zinc-800 dark:bg-zinc-900/80 dark:text-zinc-300">
                      <Globe className="h-3 w-3 text-violet-500" aria-hidden="true" />
                      {extractEndpointDomain(activeEndpoint.url)}
                    </span>

                    <span className="inline-flex items-center gap-1.5 rounded-lg border border-zinc-200 bg-zinc-50/90 px-2.5 py-1 font-mono text-[11px] font-medium text-zinc-700 dark:border-zinc-800 dark:bg-zinc-900/80 dark:text-zinc-300">
                      <Smartphone className="h-3 w-3 text-indigo-500" aria-hidden="true" />
                      {activeSimBadge}
                    </span>

                    <button
                      type="button"
                      onClick={onCheckHeartbeat}
                      disabled={heartbeat.status === 'checking'}
                      className="inline-flex items-center gap-1 rounded-lg px-2 py-1 font-mono text-[11px] font-medium text-violet-600 transition-colors hover:bg-violet-500/10 disabled:opacity-50 dark:text-violet-400"
                    >
                      <RefreshCw
                        className={`h-3 w-3 ${heartbeat.status === 'checking' ? 'animate-spin' : ''}`}
                      />
                      {heartbeat.latencyMs !== null ? `${heartbeat.latencyMs}ms · Ping` : 'Ping'}
                    </button>
                  </>
                )}

                {connectionState === 'degraded' && (
                  <button
                    type="button"
                    onClick={onOpenDiagnostics}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 px-3 py-1 text-xs font-semibold text-white hover:bg-rose-700"
                  >
                    <Stethoscope className="h-3.5 w-3.5" />
                    Diagnose
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Right: Endpoint Quick-Switcher + Animated Signal Heartbeat / Setup Wizard CTA */}
          <div className="flex flex-col gap-3 lg:min-w-[300px] lg:items-end">
            {endpoints.length > 0 ? (
              <div className="flex w-full items-center gap-2 sm:max-w-xs">
                <label htmlFor="dashboard-endpoint-select" className="sr-only">
                  Active Endpoint Profile
                </label>
                <select
                  id="dashboard-endpoint-select"
                  value={activeEndpoint?.id ?? ''}
                  onChange={(e) => onSelectEndpoint(e.target.value)}
                  className="h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50/90 px-3 text-sm font-medium text-zinc-900 outline-none transition-colors focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950/90 dark:text-zinc-100"
                >
                  {endpoints.map((ep) => (
                    <option key={ep.id} value={ep.id}>
                      {ep.name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => onNavigate('tester')}
                  className="inline-flex h-11 items-center gap-1.5 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white shadow-md shadow-violet-600/20 transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
                >
                  <FlaskConical className="h-3.5 w-3.5" />
                  Test
                </button>
              </div>
            ) : (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={onOpenWizard}
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-4 text-xs font-semibold text-white shadow-lg shadow-violet-600/25 transition-opacity hover:opacity-95 whitespace-nowrap shrink-0"
                >
                  <Sparkles className="h-4 w-4" />
                  + Setup Wizard
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('endpoints')}
                  className="inline-flex h-11 items-center justify-center gap-1.5 rounded-xl border border-zinc-200 bg-white px-3.5 text-xs font-semibold text-zinc-800 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                >
                  <Plus className="h-4 w-4" />
                  Manual
                </button>
              </div>
            )}

            {/* Quick Diagnostics + Animated Signal Wave indicator */}
            <div className="flex w-full items-center justify-between gap-3 sm:max-w-xs">
              <div className="flex items-center gap-1.5 text-[11px] font-mono text-zinc-500 dark:text-zinc-400">
                <Activity
                  className={`h-3.5 w-3.5 ${
                    connectionState === 'connected'
                      ? 'text-emerald-500'
                      : connectionState === 'connecting'
                        ? 'animate-pulse text-amber-500'
                        : 'text-zinc-400'
                  }`}
                  aria-hidden="true"
                />
                <span>
                  {connectionState === 'connected'
                    ? 'Signal Nominal'
                    : connectionState === 'connecting'
                      ? 'Handshaking'
                      : connectionState === 'degraded'
                        ? 'Signal Degraded'
                        : 'Relay Idle'}
                </span>
              </div>
              <button
                type="button"
                onClick={onOpenDiagnostics}
                className="inline-flex items-center gap-1 text-xs font-medium text-violet-600 hover:text-violet-700 dark:text-violet-400 dark:hover:text-violet-300"
              >
                <Stethoscope className="h-3.5 w-3.5" />
                Diagnostics
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4 Layered Glass KPI Cards */}
      <section aria-label="Forwarding Metrics" className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        <div className="relative overflow-hidden rounded-2xl border border-zinc-200/90 bg-white/90 p-4 backdrop-blur-xl sm:p-5 dark:border-zinc-800/90 dark:bg-[#0E0E13]/90">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-500/35 to-transparent"
          />
          <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">Forwarded Today</p>
          <motion.p
            key={kpis.forwardedToday}
            initial={{ scale: 1.08 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.18 }}
            data-testid="kpi-forwarded-today"
            className="mt-2 font-mono text-2xl font-semibold tracking-tight text-zinc-950 tabular-data sm:text-3xl dark:text-zinc-50"
          >
            {kpis.forwardedToday}
          </motion.p>
          <p className="mt-1.5 text-xs text-zinc-500 dark:text-zinc-400">
            {logs.length} total recorded
          </p>
        </div>

        <div className="relative overflow-hidden rounded-2xl border border-zinc-200/90 bg-white/90 p-4 backdrop-blur-xl sm:p-5 dark:border-zinc-800/90 dark:bg-[#0E0E13]/90">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-500/35 to-transparent"
          />
          <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">Success Rate</p>
          <p
            data-testid="kpi-success-rate"
            className={`mt-2 font-mono text-2xl font-semibold tracking-tight tabular-data sm:text-3xl ${
              kpis.successRate === null
                ? 'text-zinc-950 dark:text-zinc-50'
                : kpis.successRate >= 95
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : kpis.successRate >= 75
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {kpis.successRate === null ? '—' : `${kpis.successRate}%`}
          </p>
          <p className="mt-1.5 text-xs text-zinc-500 dark:text-zinc-400">
            HTTP 2xx deliveries
          </p>
        </div>

        <div className="relative overflow-hidden rounded-2xl border border-zinc-200/90 bg-white/90 p-4 backdrop-blur-xl sm:p-5 dark:border-zinc-800/90 dark:bg-[#0E0E13]/90">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-500/35 to-transparent"
          />
          <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">Pending Retry Queue</p>
          <p
            data-testid="kpi-pending-queue"
            className={`mt-2 font-mono text-2xl font-semibold tracking-tight tabular-data sm:text-3xl ${
              kpis.pendingQueueCount > 0
                ? 'text-amber-600 dark:text-amber-400'
                : 'text-zinc-950 dark:text-zinc-50'
            }`}
          >
            {kpis.pendingQueueCount}
          </p>
          <p className="mt-1.5 text-xs text-zinc-500 dark:text-zinc-400">
            Offline & backoff queue
          </p>
        </div>

        <div className="relative overflow-hidden rounded-2xl border border-zinc-200/90 bg-white/90 p-4 backdrop-blur-xl sm:p-5 dark:border-zinc-800/90 dark:bg-[#0E0E13]/90">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-rose-500/35 to-transparent"
          />
          <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">Failed Count</p>
          <p
            data-testid="kpi-failed-count"
            className={`mt-2 font-mono text-2xl font-semibold tracking-tight tabular-data sm:text-3xl ${
              kpis.failedCount > 0
                ? 'text-rose-600 dark:text-rose-400'
                : 'text-zinc-950 dark:text-zinc-50'
            }`}
          >
            {kpis.failedCount}
          </p>
          <p className="mt-1.5 text-xs text-zinc-500 dark:text-zinc-400">
            Requires inspection
          </p>
        </div>
      </section>

      {/* Main 2-column split on desktop: Live Activity Stream + Sparkline & Android Readiness */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Live Activity Stream */}
        <section className="rounded-2xl border border-zinc-200/90 bg-white/90 backdrop-blur-xl lg:col-span-7 dark:border-zinc-800/90 dark:bg-[#0E0E13]/90">
          <div className="flex items-center justify-between border-b border-zinc-200/80 px-5 py-4 dark:border-zinc-800/80">
            <div>
              <h2 className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
                Live Activity Stream
              </h2>
              <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                Real-time forwarded SMS webhook deliveries
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('logs')}
              className="inline-flex h-9 items-center gap-1 rounded-lg px-2.5 text-xs font-medium text-violet-600 transition-colors hover:bg-violet-50 dark:text-violet-400 dark:hover:bg-violet-500/10 whitespace-nowrap shrink-0"
            >
              Inspect All
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {recentLogs.length === 0 ? (
            <div className="flex flex-col items-center justify-center px-6 py-12 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-zinc-200 bg-zinc-50 text-zinc-400 dark:border-zinc-800 dark:bg-zinc-900">
                <Webhook className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-sm font-semibold text-zinc-950 dark:text-zinc-100">
                No forwarded SMS events yet
              </h3>
              <p className="mt-1 max-w-sm text-xs leading-relaxed text-zinc-500 dark:text-zinc-400">
                {endpoints.length === 0
                  ? 'Launch the 3-step Setup Wizard to connect your HTTPS server, or create an endpoint profile manually.'
                  : 'Tap "Simulate Incoming SMS" below or open the Webhook Simulator to watch live events flow in.'}
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5">
                {endpoints.length === 0 ? (
                  <button
                    type="button"
                    onClick={onOpenWizard}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
                  >
                    <Sparkles className="h-3.5 w-3.5" />
                    Launch Setup Wizard
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => onNavigate('tester')}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-violet-600 px-4 text-xs font-semibold text-white transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
                  >
                    <FlaskConical className="h-3.5 w-3.5" />
                    Open Webhook Simulator
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
              {recentLogs.map((entry) => {
                const statusLabel =
                  entry.status === 'success'
                    ? `${entry.response.statusCode ?? 200} OK`
                    : entry.status === 'pending'
                      ? entry.response.statusCode
                        ? `${entry.response.statusCode} Queued`
                        : 'Queued'
                      : entry.response.statusCode
                        ? `${entry.response.statusCode} Failed`
                        : 'Failed';

                const statusTone =
                  entry.status === 'success'
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : entry.status === 'pending'
                      ? 'text-amber-600 dark:text-amber-400'
                      : 'text-rose-600 dark:text-rose-400';

                return (
                  <button
                    key={entry.id}
                    type="button"
                    onClick={() => onOpenLog(entry)}
                    className="flex w-full items-center justify-between gap-4 px-5 py-3.5 text-left transition-colors hover:bg-zinc-50 dark:hover:bg-zinc-900/60"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs">
                        <span className="font-mono font-semibold text-zinc-950 dark:text-zinc-100">
                          {entry.sms.sender}
                        </span>
                        <span aria-hidden="true" className="text-zinc-300 dark:text-zinc-700">
                          ·
                        </span>
                        <span className="font-mono text-zinc-500 dark:text-zinc-400">
                          {entry.sms.simSlot}
                        </span>
                        <span aria-hidden="true" className="text-zinc-300 dark:text-zinc-700">
                          ·
                        </span>
                        <span className="truncate text-zinc-500 dark:text-zinc-400">
                          {entry.endpointName}
                        </span>
                      </div>
                      <p className="mt-1 truncate text-sm text-zinc-700 dark:text-zinc-300">
                        {entry.sms.message}
                      </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-3">
                      <div className="text-right">
                        <p className={`font-mono text-xs font-semibold tabular-data ${statusTone}`}>
                          {statusLabel}
                        </p>
                        <p className="mt-0.5 font-mono text-[11px] text-zinc-400 tabular-data dark:text-zinc-500">
                          {entry.response.latencyMs}ms · {formatRelativeTime(entry.sms.receivedAt)}
                        </p>
                      </div>
                      <ChevronRight className="h-4 w-4 text-zinc-400" aria-hidden="true" />
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </section>

        {/* Right Column: Throughput & Latency Sparkline + Android Background Readiness */}
        <div className="space-y-6 lg:col-span-5">
          <LatencySparklineCard logs={logs} />

          {/* Android Background Readiness Panel */}
          <section className="flex flex-col rounded-2xl border border-zinc-200/90 bg-white/90 backdrop-blur-xl dark:border-zinc-800/90 dark:bg-[#0E0E13]/90">
            <div className="flex items-center justify-between border-b border-zinc-200/80 px-5 py-4 dark:border-zinc-800/80">
              <div>
                <h2 className="text-sm font-semibold text-zinc-950 dark:text-zinc-50">
                  Android Background Readiness
                </h2>
                <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                  {readiness.platform === 'android-capacitor'
                    ? 'Capacitor Android Native'
                    : 'Browser Bridge Simulator'}
                </p>
              </div>
              <span
                className={`font-mono text-xs font-semibold tabular-data ${
                  readinessPassedCount === 3
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-amber-600 dark:text-amber-400'
                }`}
              >
                {readinessPassedCount}/3 Ready
              </span>
            </div>

            <div className="flex-1 divide-y divide-zinc-100 px-5 dark:divide-zinc-800/80">
              <div className="flex items-center justify-between gap-3 py-3.5">
                <div className="flex items-start gap-3">
                  <Smartphone className="mt-0.5 h-4 w-4 shrink-0 text-zinc-400" aria-hidden="true" />
                  <div>
                    <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                      SMS Permission
                    </p>
                    <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                      {readiness.smsPermissionGranted ? 'RECEIVE_SMS granted' : 'Action required'}
                    </p>
                  </div>
                </div>
                {readiness.smsPermissionGranted ? (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                    <ShieldCheck className="h-4 w-4" />
                    Granted
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={onGrantSmsPermissions}
                    className="inline-flex h-9 items-center rounded-lg border border-zinc-200 bg-zinc-50 px-3 text-xs font-medium text-zinc-900 transition-colors hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                  >
                    Grant
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between gap-3 py-3.5">
                <div className="flex items-start gap-3">
                  <BatteryCharging className="mt-0.5 h-4 w-4 shrink-0 text-zinc-400" aria-hidden="true" />
                  <div>
                    <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                      Battery Optimization
                    </p>
                    <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                      {readiness.batteryOptimizationBypassed
                        ? `Unrestricted · ${readiness.batteryLevel}%`
                        : `Restricted by Doze · ${readiness.batteryLevel}%`}
                    </p>
                  </div>
                </div>
                {readiness.batteryOptimizationBypassed ? (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                    <ShieldCheck className="h-4 w-4" />
                    Bypassed
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={onBypassBattery}
                    className="inline-flex h-9 items-center rounded-lg border border-zinc-200 bg-zinc-50 px-3 text-xs font-medium text-zinc-900 transition-colors hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800 whitespace-nowrap shrink-0"
                  >
                    Bypass
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between gap-3 py-3.5">
                <div className="flex items-start gap-3">
                  <Cpu className="mt-0.5 h-4 w-4 shrink-0 text-zinc-400" aria-hidden="true" />
                  <div>
                    <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                      Boot Auto-Start
                    </p>
                    <p className="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">
                      {readiness.bootAutoStartEnabled
                        ? 'Resumes after device reboot'
                        : 'Manual start on reboot'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onToggleBootAutoStart}
                  aria-pressed={readiness.bootAutoStartEnabled}
                  className={`inline-flex h-9 items-center rounded-lg px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    readiness.bootAutoStartEnabled
                      ? 'bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/20 dark:text-emerald-400'
                      : 'border border-zinc-200 bg-zinc-50 text-zinc-700 hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:bg-zinc-800'
                  }`}
                >
                  {readiness.bootAutoStartEnabled ? 'Enabled' : 'Enable'}
                </button>
              </div>
            </div>

            <div className="border-t border-zinc-100 px-5 py-3 dark:border-zinc-800/80">
              <div className="flex items-center justify-between text-xs text-zinc-500 dark:text-zinc-400">
                <span className="inline-flex items-center gap-1.5">
                  {readinessPassedCount === 3 ? (
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                  ) : (
                    <ShieldAlert className="h-3.5 w-3.5 text-amber-500" />
                  )}
                  Foreground service: {readiness.foregroundServiceRunning ? 'Active' : 'Idle'}
                </span>
                {heartbeat.checkedAt && (
                  <span className="font-mono text-[11px] tabular-data">
                    {formatTimestampTime(heartbeat.checkedAt)}
                  </span>
                )}
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Floating "Simulate Incoming SMS" Quick-Trigger Pill (Web Preview mode only) */}
      {readiness.platform === 'browser-simulator' && endpoints.length > 0 && (
        <div className="fixed bottom-[82px] right-4 z-20 lg:bottom-6 lg:right-6">
          <button
            type="button"
            onClick={() => void handleQuickSimSms()}
            disabled={simulatingSms}
            className="inline-flex h-10 items-center gap-2 rounded-full border border-violet-500/40 bg-zinc-950/90 px-3.5 text-xs font-semibold text-white shadow-xl shadow-violet-950/40 backdrop-blur-xl transition-transform hover:scale-[1.02] hover:bg-zinc-900 active:scale-[0.98] disabled:opacity-60 dark:border-violet-400/35 dark:bg-violet-600/95 dark:hover:bg-violet-500 whitespace-nowrap"
          >
            <MessageSquarePlus className={`h-4 w-4 text-violet-300 dark:text-white ${simulatingSms ? 'animate-pulse' : ''}`} />
            {simulatingSms ? 'Simulating SMS...' : 'Simulate Incoming SMS'}
          </button>
        </div>
      )}
    </div>
  );
}
