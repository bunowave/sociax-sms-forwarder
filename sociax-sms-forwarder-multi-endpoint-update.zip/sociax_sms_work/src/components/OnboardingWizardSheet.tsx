import { useState } from 'react';
import { motion } from 'motion/react';
import {
  Activity,
  ArrowRight,
  BatteryCharging,
  CheckCircle2,
  Eye,
  EyeOff,
  QrCode,
  Radio,
  Server,
  ShieldCheck,
  Smartphone,
  Upload,
  X,
  Zap,
} from 'lucide-react';
import type { AndroidReadinessState, EndpointProfile, SimSlotFilter } from '../types/ssf';
import { pingEndpointHeartbeat } from '../services/webhookDispatcher';
import {
  DEFAULT_PAYLOAD_TEMPLATE,
  generateId,
  parseQrConfigPayload,
  validateWebhookUrl,
} from '../utils/webhookEngine';
import { SsfEmblemSvg } from './SplashScreen';

interface OnboardingWizardSheetProps {
  readiness: AndroidReadinessState;
  onClose: () => void;
  onGrantSmsPermissions: () => Promise<void>;
  onBypassBattery: () => Promise<void>;
  onEnableForegroundService: () => Promise<void>;
  onCompleteWizard: (
    profileData: Omit<EndpointProfile, 'id' | 'createdAt' | 'updatedAt'>,
    goLive: boolean
  ) => Promise<void>;
}

export function OnboardingWizardSheet({
  readiness,
  onClose,
  onGrantSmsPermissions,
  onBypassBattery,
  onEnableForegroundService,
  onCompleteWizard,
}: OnboardingWizardSheetProps) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [connectTab, setConnectTab] = useState<'manual' | 'qr'>('manual');

  // Manual connect state
  const [profileName, setProfileName] = useState('Primary Webhook');
  const [webhookUrl, setWebhookUrl] = useState('');
  const [headerKey, setHeaderKey] = useState('X-Sociax-Key');
  const [headerSecret, setHeaderSecret] = useState('');
  const [showSecret, setShowSecret] = useState(false);
  const [senderWhitelist, setSenderWhitelist] = useState('ALL');
  const [simFilter, setSimFilter] = useState<SimSlotFilter>('BOTH');

  // QR paste state
  const [qrInput, setQrInput] = useState('');
  const [importedProfile, setImportedProfile] = useState<Omit<
    EndpointProfile,
    'id' | 'createdAt' | 'updatedAt'
  > | null>(null);

  // Handshake verification state
  const [probing, setProbing] = useState(false);
  const [probeResult, setProbeResult] = useState<{
    reachable: boolean;
    latencyMs: number;
    note: string;
  } | null>(null);
  const [stepError, setStepError] = useState<string | null>(null);
  const [finishing, setFinishing] = useState(false);

  const buildCurrentProfile = ():
    | { ok: true; data: Omit<EndpointProfile, 'id' | 'createdAt' | 'updatedAt'> }
    | { ok: false; error: string } => {
    if (connectTab === 'qr') {
      if (importedProfile) {
        return { ok: true, data: { ...importedProfile, simFilter } };
      }
      const parsed = parseQrConfigPayload(qrInput);
      if (!parsed.ok) {
        return { ok: false, error: parsed.error };
      }
      return { ok: true, data: { ...parsed.profile, simFilter } };
    }

    const urlCheck = validateWebhookUrl(webhookUrl);
    if (!urlCheck.valid) {
      return { ok: false, error: urlCheck.error ?? 'Enter a valid HTTPS Webhook URL.' };
    }

    const senders = senderWhitelist
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const headers = headerKey.trim()
      ? [
          {
            id: generateId('hdr'),
            key: headerKey.trim(),
            value: headerSecret,
            isSecret: true,
          },
        ]
      : [];

    return {
      ok: true,
      data: {
        name: profileName.trim() || 'Primary Webhook',
        colorTag: 'violet',
        url: webhookUrl.trim(),
        headers,
        payloadTemplate: DEFAULT_PAYLOAD_TEMPLATE,
        allowedSenders: senders.length > 0 ? senders : ['ALL'],
        keywordRegex: '',
        simFilter,
        retryPolicy: {
          maxRetries: 5,
          exponentialBackoff: true,
          offlineQueue: true,
        },
      },
    };
  };

  const handleVerifyHandshake = async () => {
    setStepError(null);
    const built = buildCurrentProfile();
    if (!built.ok) {
      setStepError(built.error);
      return;
    }
    setProbing(true);
    try {
      const res = await pingEndpointHeartbeat(built.data.url);
      setProbeResult(res);
    } finally {
      setProbing(false);
    }
  };

  const handleContinueToReadiness = () => {
    setStepError(null);
    const built = buildCurrentProfile();
    if (!built.ok) {
      setStepError(built.error);
      return;
    }
    if (connectTab === 'qr') {
      setImportedProfile(built.data);
    }
    setStep(3);
  };

  const handleQrFileUpload = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setQrInput(reader.result);
        setStepError(null);
        const parsed = parseQrConfigPayload(reader.result);
        if (parsed.ok) {
          setImportedProfile(parsed.profile);
        }
      }
    };
    reader.readAsText(file);
  };

  const handleComplete = async () => {
    const built = buildCurrentProfile();
    if (!built.ok) {
      setStep(2);
      setStepError(built.error);
      return;
    }
    setFinishing(true);
    try {
      await onCompleteWizard(built.data, true);
      onClose();
    } finally {
      setFinishing(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Quick Connection Setup Wizard"
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 backdrop-blur-sm sm:items-center sm:p-4"
    >
      <motion.div
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 40, opacity: 0 }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        className="relative flex max-h-[92vh] w-full max-w-xl flex-col overflow-hidden rounded-t-3xl border border-zinc-200 bg-white shadow-2xl sm:rounded-2xl dark:border-zinc-800 dark:bg-[#0D0D12]"
      >
        {/* Subtle top gradient highlight */}
        <div
          aria-hidden="true"
          className="h-[2px] w-full bg-gradient-to-r from-transparent via-violet-500/80 to-transparent"
        />

        {/* Mobile sheet drag handle */}
        <div className="flex justify-center pt-2.5 sm:hidden" aria-hidden="true">
          <div className="h-1 w-10 rounded-full bg-zinc-300 dark:bg-zinc-700" />
        </div>

        {/* Header with step indicator */}
        <div className="flex items-center justify-between border-b border-zinc-200/80 px-5 py-4 dark:border-zinc-800/80">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              {[1, 2, 3].map((idx) => (
                <span
                  key={idx}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === step
                      ? 'w-6 bg-violet-600 dark:bg-violet-500'
                      : idx < step
                        ? 'w-2.5 bg-emerald-500'
                        : 'w-2.5 bg-zinc-200 dark:bg-zinc-800'
                  }`}
                />
              ))}
            </div>
            <span className="font-mono text-xs font-medium text-zinc-500 dark:text-zinc-400">
              Step {step} of 3
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close setup wizard"
            className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-500 transition-colors hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Scrollable Step Body */}
        <div className="flex-1 overflow-y-auto px-5 py-5 sm:px-6">
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex flex-col items-center text-center">
                <div className="relative mb-4">
                  <div
                    aria-hidden="true"
                    className="absolute inset-0 rounded-2xl bg-violet-600/30 blur-xl"
                  />
                  <SsfEmblemSvg className="relative h-16 w-16" />
                </div>
                <span className="font-mono text-[11px] font-semibold tracking-widest text-violet-600 dark:text-violet-400">
                  A BUNOWAVE PRODUCT
                </span>
                <h2 className="mt-1.5 text-2xl font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
                  Welcome to SOCIAX SMS Forwarder
                </h2>
                <p className="mt-2 max-w-md text-sm leading-relaxed text-zinc-600 dark:text-zinc-400">
                  Zero-loss, real-time SMS-to-Webhook automation engineered for reliable production
                  relays. No hardcoded servers—connect your own HTTPS endpoint in under 30 seconds.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div className="rounded-xl border border-zinc-200 bg-zinc-50/80 p-3.5 dark:border-zinc-800 dark:bg-zinc-900/50">
                  <Zap className="h-4 w-4 text-violet-600 dark:text-violet-400" aria-hidden="true" />
                  <p className="mt-2 text-xs font-semibold text-zinc-950 dark:text-zinc-100">
                    Instant HTTPS Relay
                  </p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-zinc-500 dark:text-zinc-400">
                    Dynamic JSON templates & custom secret headers.
                  </p>
                </div>
                <div className="rounded-xl border border-zinc-200 bg-zinc-50/80 p-3.5 dark:border-zinc-800 dark:bg-zinc-900/50">
                  <ShieldCheck className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                  <p className="mt-2 text-xs font-semibold text-zinc-950 dark:text-zinc-100">
                    Zero-Loss Queue
                  </p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-zinc-500 dark:text-zinc-400">
                    Automatic exponential backoff & offline queue.
                  </p>
                </div>
                <div className="rounded-xl border border-zinc-200 bg-zinc-50/80 p-3.5 dark:border-zinc-800 dark:bg-zinc-900/50">
                  <Smartphone className="h-4 w-4 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
                  <p className="mt-2 text-xs font-semibold text-zinc-950 dark:text-zinc-100">
                    Dual-SIM Ready
                  </p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-zinc-500 dark:text-zinc-400">
                    Filter by SIM slot, Sender ID, or regex pattern.
                  </p>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
                  Connect Your Server
                </h2>
                <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
                  Import a QR config string or enter your custom HTTPS webhook details manually.
                </p>
              </div>

              {/* 2-Tab Switcher */}
              <div className="grid grid-cols-2 rounded-xl bg-zinc-100 p-1 dark:bg-zinc-900">
                <button
                  type="button"
                  onClick={() => {
                    setConnectTab('manual');
                    setStepError(null);
                  }}
                  className={`flex h-9 items-center justify-center gap-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    connectTab === 'manual'
                      ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                      : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                  }`}
                >
                  <Server className="h-3.5 w-3.5" />
                  Quick Manual Connect
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setConnectTab('qr');
                    setStepError(null);
                  }}
                  className={`flex h-9 items-center justify-center gap-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    connectTab === 'qr'
                      ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                      : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                  }`}
                >
                  <QrCode className="h-3.5 w-3.5" />
                  Scan / Paste QR Config
                </button>
              </div>

              {connectTab === 'manual' ? (
                <div className="space-y-3.5">
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="wiz-profile-name"
                        className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                      >
                        Profile Name
                      </label>
                      <input
                        id="wiz-profile-name"
                        type="text"
                        value={profileName}
                        onChange={(e) => setProfileName(e.target.value)}
                        placeholder="Primary Webhook"
                        className="mt-1 h-10 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 text-sm text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="wiz-senders"
                        className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                      >
                        Sender Whitelist
                      </label>
                      <input
                        id="wiz-senders"
                        type="text"
                        value={senderWhitelist}
                        onChange={(e) => setSenderWhitelist(e.target.value)}
                        placeholder="ALL or comma-separated IDs"
                        className="mt-1 h-10 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="wiz-url"
                      className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      Webhook URL (HTTPS)
                    </label>
                    <input
                      id="wiz-url"
                      type="url"
                      value={webhookUrl}
                      onChange={(e) => {
                        setWebhookUrl(e.target.value);
                        setStepError(null);
                        setProbeResult(null);
                      }}
                      placeholder="https://api.yourdomain.com/webhooks/sms"
                      className="mt-1 h-11 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3.5 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="wiz-hdr-key"
                        className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                      >
                        Auth Header Key
                      </label>
                      <input
                        id="wiz-hdr-key"
                        type="text"
                        value={headerKey}
                        onChange={(e) => setHeaderKey(e.target.value)}
                        placeholder="X-Sociax-Key"
                        className="mt-1 h-10 w-full rounded-xl border border-zinc-200 bg-zinc-50 px-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="wiz-hdr-val"
                        className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                      >
                        Secret Value
                      </label>
                      <div className="relative mt-1">
                        <input
                          id="wiz-hdr-val"
                          type={showSecret ? 'text' : 'password'}
                          value={headerSecret}
                          onChange={(e) => setHeaderSecret(e.target.value)}
                          placeholder="Your secret API key"
                          className="h-10 w-full rounded-xl border border-zinc-200 bg-zinc-50 pl-3 pr-9 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                        />
                        <button
                          type="button"
                          onClick={() => setShowSecret((s) => !s)}
                          aria-label={showSecret ? 'Hide secret value' : 'Show secret value'}
                          className="absolute right-1.5 top-1 flex h-8 w-8 items-center justify-center rounded-md text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                        >
                          {showSecret ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-zinc-300 bg-zinc-50 px-4 py-3 text-xs font-medium text-zinc-700 transition-colors hover:border-violet-500 hover:text-violet-600 dark:border-zinc-700 dark:bg-zinc-900/50 dark:text-zinc-300 dark:hover:border-violet-500 dark:hover:text-violet-400">
                    <Upload className="h-4 w-4" />
                    <span>Upload QR Profile JSON</span>
                    <input
                      type="file"
                      accept=".json,application/json"
                      className="sr-only"
                      onChange={(e) => handleQrFileUpload(e.target.files?.[0])}
                    />
                  </label>
                  <div>
                    <label
                      htmlFor="wiz-qr-paste"
                      className="block text-xs font-medium text-zinc-700 dark:text-zinc-300"
                    >
                      Paste Scanned QR Config JSON
                    </label>
                    <textarea
                      id="wiz-qr-paste"
                      rows={5}
                      value={qrInput}
                      onChange={(e) => {
                        setQrInput(e.target.value);
                        setImportedProfile(null);
                        setStepError(null);
                      }}
                      placeholder='{"v":1,"t":"ssf-endpoint","n":"Production Hook","u":"https://api.yourdomain.com/sms",...}'
                      className="mt-1 w-full rounded-xl border border-zinc-200 bg-zinc-50 p-3 font-mono text-xs text-zinc-900 outline-none focus:border-violet-500 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100"
                    />
                  </div>
                </div>
              )}

              {/* Live Verify & Test Handshake */}
              <div className="flex flex-col gap-2.5 rounded-xl border border-zinc-200 bg-zinc-50/80 p-3.5 sm:flex-row sm:items-center sm:justify-between dark:border-zinc-800 dark:bg-zinc-900/50">
                <div className="min-w-0 text-xs">
                  {probeResult ? (
                    <div className="flex items-center gap-2">
                      <span
                        className={`inline-flex h-2 w-2 rounded-full ${
                          probeResult.reachable ? 'bg-emerald-500' : 'bg-amber-500'
                        }`}
                      />
                      <span
                        className={`font-mono font-semibold tabular-data ${
                          probeResult.reachable
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-amber-600 dark:text-amber-400'
                        }`}
                      >
                        {probeResult.reachable
                          ? `Handshake OK · ${probeResult.latencyMs}ms`
                          : `Probe warning (${probeResult.note}) · ${probeResult.latencyMs}ms`}
                      </span>
                    </div>
                  ) : (
                    <span className="text-zinc-500 dark:text-zinc-400">
                      Test server reachability & RTT latency before saving.
                    </span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={handleVerifyHandshake}
                  disabled={probing}
                  className="inline-flex h-9 items-center justify-center gap-1.5 rounded-lg border border-violet-500/30 bg-violet-600/10 px-3 text-xs font-semibold text-violet-700 transition-colors hover:bg-violet-600/20 disabled:opacity-50 dark:text-violet-300 whitespace-nowrap shrink-0"
                >
                  <Activity className={`h-3.5 w-3.5 ${probing ? 'animate-pulse' : ''}`} />
                  {probing ? 'Probing...' : 'Verify & Test Handshake'}
                </button>
              </div>

              {stepError && (
                <p role="alert" className="text-xs font-medium text-rose-600 dark:text-rose-400">
                  {stepError}
                </p>
              )}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-lg font-bold tracking-tight text-zinc-950 dark:text-zinc-50">
                  Device Readiness Checklist
                </h2>
                <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
                  Grant background permissions and choose your active SIM slot before going live.
                </p>
              </div>

              <div className="divide-y divide-zinc-200/80 rounded-2xl border border-zinc-200 bg-zinc-50/70 dark:divide-zinc-800 dark:border-zinc-800 dark:bg-zinc-900/40">
                <div className="flex items-center justify-between gap-3 px-4 py-3.5">
                  <div className="flex items-center gap-3">
                    <Smartphone className="h-4 w-4 text-violet-500" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                        SMS Permission
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        RECEIVE_SMS & READ_SMS access
                      </p>
                    </div>
                  </div>
                  {readiness.smsPermissionGranted ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Granted
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void onGrantSmsPermissions()}
                      className="h-8 rounded-lg bg-violet-600 px-3 text-xs font-semibold text-white hover:bg-violet-700 whitespace-nowrap shrink-0"
                    >
                      Grant
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between gap-3 px-4 py-3.5">
                  <div className="flex items-center gap-3">
                    <Radio className="h-4 w-4 text-violet-500" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                        Background Foreground Service
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        Persistent notification lock for zero-drop forwarding
                      </p>
                    </div>
                  </div>
                  {readiness.foregroundServiceRunning ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Active
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void onEnableForegroundService()}
                      className="h-8 rounded-lg border border-zinc-300 bg-white px-3 text-xs font-semibold text-zinc-800 hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-100 dark:hover:bg-zinc-700 whitespace-nowrap shrink-0"
                    >
                      Enable
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between gap-3 px-4 py-3.5">
                  <div className="flex items-center gap-3">
                    <BatteryCharging className="h-4 w-4 text-violet-500" aria-hidden="true" />
                    <div>
                      <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
                        Battery Optimization Bypass
                      </p>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        Prevent Android Doze mode from suspending SMS relay
                      </p>
                    </div>
                  </div>
                  {readiness.batteryOptimizationBypassed ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Bypassed
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void onBypassBattery()}
                      className="h-8 rounded-lg border border-zinc-300 bg-white px-3 text-xs font-semibold text-zinc-800 hover:bg-zinc-100 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-100 dark:hover:bg-zinc-700 whitespace-nowrap shrink-0"
                    >
                      Bypass
                    </button>
                  )}
                </div>
              </div>

              {/* Active SIM Slot selection */}
              <div>
                <span className="block text-xs font-medium text-zinc-700 dark:text-zinc-300">
                  Listen on SIM Slot
                </span>
                <div className="mt-2 grid grid-cols-3 rounded-xl bg-zinc-100 p-1 dark:bg-zinc-900">
                  {(
                    [
                      { id: 'BOTH', label: 'Both SIMs' },
                      { id: 'SIM_1', label: 'SIM 1 Only' },
                      { id: 'SIM_2', label: 'SIM 2 Only' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSimFilter(opt.id)}
                      className={`h-9 rounded-lg font-mono text-xs font-semibold transition-colors ${
                        simFilter === opt.id
                          ? 'bg-white text-zinc-950 shadow-xs dark:bg-zinc-800 dark:text-zinc-50'
                          : 'text-zinc-600 hover:text-zinc-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Sticky Footer CTA Bar */}
        <div className="flex items-center justify-between gap-3 border-t border-zinc-200/80 bg-zinc-50/80 px-5 py-4 dark:border-zinc-800/80 dark:bg-zinc-950/80">
          {step === 1 ? (
            <>
              <button
                type="button"
                onClick={onClose}
                className="h-11 rounded-xl px-4 text-xs font-medium text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-zinc-100"
              >
                Skip for now
              </button>
              <button
                type="button"
                onClick={() => setStep(2)}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-violet-600 px-5 text-xs font-semibold text-white shadow-lg shadow-violet-600/25 transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
              >
                Get Started
                <ArrowRight className="h-4 w-4" />
              </button>
            </>
          ) : step === 2 ? (
            <>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="h-11 rounded-xl border border-zinc-200 px-4 text-xs font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-900"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleContinueToReadiness}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-violet-600 px-5 text-xs font-semibold text-white shadow-lg shadow-violet-600/25 transition-colors hover:bg-violet-700 whitespace-nowrap shrink-0"
              >
                Continue to Readiness
                <ArrowRight className="h-4 w-4" />
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setStep(2)}
                className="h-11 rounded-xl border border-zinc-200 px-4 text-xs font-medium text-zinc-700 hover:bg-zinc-100 dark:border-zinc-800 dark:text-zinc-300 dark:hover:bg-zinc-900"
              >
                Back
              </button>
              <button
                type="button"
                onClick={handleComplete}
                disabled={finishing}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 px-5 text-xs font-semibold text-white shadow-lg shadow-violet-600/30 transition-opacity hover:opacity-95 disabled:opacity-60 whitespace-nowrap shrink-0"
              >
                <Zap className="h-4 w-4" />
                {finishing ? 'Connecting...' : 'Complete & Go Live'}
              </button>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
