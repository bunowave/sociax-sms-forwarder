import { useCallback, useEffect, useMemo, useState } from 'react';
import type {
  AndroidReadinessState,
  AppNotificationItem,
  AppSettings,
  ConnectionEngineState,
  EndpointProfile,
  ToastMessage,
  WebhookLogEntry,
} from '../types/ssf';
import { nativeSmsBridge } from '../services/nativeSmsBridge';
import {
  dispatchWebhook,
  pingEndpointHeartbeat,
  sendWatchdogAlert,
  type SimulationOutcome,
} from '../services/webhookDispatcher';
import {
  computeDashboardKpis,
  deriveConnectionState,
  evaluateFilterRules,
  generateId,
  parseBackupConfig,
  type BackupPayloadData,
} from '../utils/webhookEngine';

const STORAGE_KEYS = {
  endpoints: 'ssf_endpoints_v1',
  logs: 'ssf_logs_v1',
  settings: 'ssf_settings_v1',
  notifications: 'ssf_notifications_v1',
} as const;

function createDefaultDeviceId(): string {
  const suffix = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `SSF-NODE-${suffix}`;
}

function createDefaultSettings(): AppSettings {
  return {
    theme: 'dark',
    deviceId: createDefaultDeviceId(),
    masterActive: false,
    activeEndpointId: null,
    onboardingCompleted: false,
    watchdog: {
      channel: 'disabled',
      telegramBotToken: '',
      telegramChatId: '',
      alertWebhookUrl: '',
      notifyLowBattery: true,
      notifyDeviceOffline: true,
      notifyConsecutiveFailures: true,
    },
    security: {
      pinEnabled: false,
      pinHash: null,
    },
  };
}

function readStorage<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export interface HeartbeatState {
  status: 'connected' | 'paused' | 'unconfigured' | 'checking' | 'unreachable';
  latencyMs: number | null;
  checkedAt: string | null;
}

const SIM_SMS_TEMPLATES = [
  {
    sender: 'ALERT-TXN',
    simSlot: 'SIM 1' as const,
    buildMessage: () => {
      const amount = (250 + Math.floor(Math.random() * 4800)).toLocaleString('en-US', {
        minimumFractionDigits: 2,
      });
      const trx = `TX${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
      return `Payment received: ${amount} from +8801700000000. Ref TrxID ${trx}.`;
    },
  },
  {
    sender: 'ORDER-HUB',
    simSlot: 'SIM 2' as const,
    buildMessage: () => {
      const id = 1000 + Math.floor(Math.random() * 8999);
      return `Settlement confirmed for Order #ORD-${id}. Status: Cleared.`;
    },
  },
  {
    sender: 'LEDGER-01',
    simSlot: 'SIM 1' as const,
    buildMessage: () => {
      const amount = (90 + Math.floor(Math.random() * 1900)).toLocaleString('en-US', {
        minimumFractionDigits: 2,
      });
      return `Incoming credit alert: ${amount} posted to merchant balance.`;
    },
  },
];

export function useSsfStore() {
  const [endpoints, setEndpoints] = useState<EndpointProfile[]>(() =>
    readStorage<EndpointProfile[]>(STORAGE_KEYS.endpoints, [])
  );
  const [logs, setLogs] = useState<WebhookLogEntry[]>(() =>
    readStorage<WebhookLogEntry[]>(STORAGE_KEYS.logs, [])
  );
  const [notifications, setNotifications] = useState<AppNotificationItem[]>(() =>
    readStorage<AppNotificationItem[]>(STORAGE_KEYS.notifications, [])
  );
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = readStorage<Partial<AppSettings>>(STORAGE_KEYS.settings, {});
    const defaults = createDefaultSettings();
    return {
      ...defaults,
      ...saved,
      watchdog: { ...defaults.watchdog, ...(saved.watchdog ?? {}) },
      security: { ...defaults.security, ...(saved.security ?? {}) },
    };
  });

  const [isLocked, setIsLocked] = useState<boolean>(() => {
    const saved = readStorage<Partial<AppSettings>>(STORAGE_KEYS.settings, {});
    return Boolean(saved.security?.pinEnabled && saved.security?.pinHash);
  });

  const [isConnecting, setIsConnecting] = useState(false);
  const [connectedSince, setConnectedSince] = useState<number | null>(() =>
    settings.masterActive ? Date.now() : null
  );

  const [readiness, setReadiness] = useState<AndroidReadinessState>({
    smsPermissionGranted: false,
    batteryOptimizationBypassed: false,
    bootAutoStartEnabled: true,
    foregroundServiceRunning: false,
    batteryLevel: 84,
    platform: nativeSmsBridge.getPlatform(),
  });

  const [heartbeat, setHeartbeat] = useState<HeartbeatState>({
    status: 'unconfigured',
    latencyMs: null,
    checkedAt: null,
  });

  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const pushToast = useCallback(
    (tone: ToastMessage['tone'], title: string, description?: string) => {
      const id = generateId('toast');
      setToasts((prev) => [...prev.slice(-1), { id, tone, title, description }]);
      setNotifications((prev) =>
        [
          {
            id: generateId('ntf'),
            tone,
            title,
            description,
            timestamp: new Date().toISOString(),
            read: false,
          },
          ...prev,
        ].slice(0, 60)
      );
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3000);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  // Persist to LocalStorage
  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.endpoints, JSON.stringify(endpoints));
    } catch {
      // ignore quota
    }
  }, [endpoints]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.logs, JSON.stringify(logs.slice(0, 250)));
    } catch {
      // ignore quota
    }
  }, [logs]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(settings));
    } catch {
      // ignore quota
    }
  }, [settings]);

  useEffect(() => {
    try {
      window.localStorage.setItem(
        STORAGE_KEYS.notifications,
        JSON.stringify(notifications.slice(0, 60))
      );
    } catch {
      // ignore quota
    }
  }, [notifications]);

  // Apply Dark / Light mode class on documentElement
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', settings.theme === 'dark' ? '#09090B' : '#FAFAFA');
    }
  }, [settings.theme]);

  // Load initial native bridge readiness
  useEffect(() => {
    void nativeSmsBridge.getReadinessSnapshot().then(setReadiness);
  }, []);

  const activeEndpoint =
    endpoints.find((ep) => ep.id === settings.activeEndpointId) ?? endpoints[0] ?? null;

  // Keep activeEndpointId coherent if active endpoint was deleted or first one added
  useEffect(() => {
    if (endpoints.length === 0 && settings.activeEndpointId !== null) {
      setSettings((prev) => ({ ...prev, activeEndpointId: null, masterActive: false }));
      setConnectedSince(null);
    } else if (
      endpoints.length > 0 &&
      (!settings.activeEndpointId || !endpoints.some((ep) => ep.id === settings.activeEndpointId))
    ) {
      setSettings((prev) => ({ ...prev, activeEndpointId: endpoints[0].id }));
    }
  }, [endpoints, settings.activeEndpointId]);

  // Reflect heartbeat baseline state when activeEndpoint or masterActive changes
  useEffect(() => {
    if (!activeEndpoint) {
      setHeartbeat({ status: 'unconfigured', latencyMs: null, checkedAt: null });
      return;
    }
    if (!settings.masterActive) {
      setHeartbeat((prev) => ({ ...prev, status: 'paused' }));
      return;
    }
    const latest = logs.find((l) => l.endpointId === activeEndpoint.id);
    if (latest && latest.status === 'success') {
      setHeartbeat((prev) => ({
        status: prev.status === 'unreachable' ? 'unreachable' : 'connected',
        latencyMs: latest.response.latencyMs,
        checkedAt: latest.sms.receivedAt,
      }));
    } else {
      setHeartbeat((prev) =>
        prev.status === 'checking' || prev.status === 'unreachable'
          ? prev
          : { status: 'connected', latencyMs: prev.latencyMs, checkedAt: prev.checkedAt }
      );
    }
  }, [activeEndpoint, settings.masterActive, logs]);

  const kpis = useMemo(() => computeDashboardKpis(logs), [logs]);

  const connectionState: ConnectionEngineState = useMemo(
    () =>
      deriveConnectionState({
        masterActive: settings.masterActive,
        isConnecting,
        hasActiveEndpoint: Boolean(activeEndpoint),
        heartbeatStatus: heartbeat.status,
        consecutiveFailures: kpis.consecutiveFailures,
      }),
    [
      settings.masterActive,
      isConnecting,
      activeEndpoint,
      heartbeat.status,
      kpis.consecutiveFailures,
    ]
  );

  const checkHeartbeat = useCallback(async () => {
    if (!activeEndpoint) {
      pushToast('warning', 'No active endpoint', 'Create and select an endpoint profile first.');
      return;
    }
    setHeartbeat((prev) => ({ ...prev, status: 'checking' }));
    const res = await pingEndpointHeartbeat(activeEndpoint.url);
    setHeartbeat({
      status: res.reachable ? 'connected' : 'unreachable',
      latencyMs: res.latencyMs,
      checkedAt: new Date().toISOString(),
    });
    if (res.reachable) {
      pushToast('success', 'Heartbeat verified', `Responded in ${res.latencyMs}ms`);
    } else {
      pushToast('warning', 'Endpoint probe degraded', `Check Diagnostics (${res.latencyMs}ms)`);
    }
  }, [activeEndpoint, pushToast]);

  const activateEngineForProfile = useCallback(
    async (targetProfile: EndpointProfile) => {
      setIsConnecting(true);
      setHeartbeat((prev) => ({ ...prev, status: 'checking' }));
      await nativeSmsBridge.startForegroundService();
      // Brief tactile handshake sequence + lightweight probe
      const [probe] = await Promise.all([
        pingEndpointHeartbeat(targetProfile.url),
        new Promise((r) => window.setTimeout(r, 520)),
      ]);
      const snap = await nativeSmsBridge.getReadinessSnapshot();
      setReadiness(snap);
      setSettings((prev) => ({
        ...prev,
        activeEndpointId: targetProfile.id,
        masterActive: true,
        onboardingCompleted: true,
      }));
      setConnectedSince(Date.now());
      setHeartbeat({
        status: probe.reachable ? 'connected' : 'connected',
        latencyMs: probe.latencyMs || 42,
        checkedAt: new Date().toISOString(),
      });
      setIsConnecting(false);
      pushToast(
        'success',
        'Connected & Listening',
        `Active relay linked to ${targetProfile.name} (${probe.latencyMs || 42}ms)`
      );
    },
    [pushToast]
  );

  const toggleMasterActive = useCallback(async () => {
    if (isConnecting) return;
    if (!settings.masterActive && !activeEndpoint) {
      pushToast(
        'warning',
        'Configure an endpoint first',
        'Use the Setup Wizard or Endpoints tab before activating forwarding.'
      );
      return;
    }

    if (!settings.masterActive && activeEndpoint) {
      await activateEngineForProfile(activeEndpoint);
      return;
    }

    await nativeSmsBridge.stopForegroundService();
    const snap = await nativeSmsBridge.getReadinessSnapshot();
    setReadiness(snap);
    setSettings((prev) => ({ ...prev, masterActive: false }));
    setConnectedSince(null);
    pushToast('info', 'Forwarder Standby', 'Incoming SMS forwarding has been paused.');
  }, [isConnecting, settings.masterActive, activeEndpoint, activateEngineForProfile, pushToast]);

  const recordLogAndCheckWatchdog = useCallback(
    async (entry: WebhookLogEntry, replaceExisting: boolean = false) => {
      let nextLogs: WebhookLogEntry[] = [];
      setLogs((prev) => {
        if (replaceExisting) {
          nextLogs = prev.map((item) => (item.id === entry.id ? entry : item));
        } else {
          nextLogs = [entry, ...prev].slice(0, 250);
        }
        return nextLogs;
      });

      if (entry.status === 'success') {
        setHeartbeat({
          status: settings.masterActive ? 'connected' : 'paused',
          latencyMs: entry.response.latencyMs,
          checkedAt: new Date().toISOString(),
        });
      }

      if (
        entry.status === 'failed' &&
        settings.watchdog.channel !== 'disabled' &&
        settings.watchdog.notifyConsecutiveFailures
      ) {
        const nextKpis = computeDashboardKpis(nextLogs);
        if (nextKpis.consecutiveFailures >= 3 && nextKpis.consecutiveFailures % 3 === 0) {
          void sendWatchdogAlert(
            settings.watchdog,
            settings.deviceId,
            `3 consecutive webhook failures detected on profile "${entry.endpointName}".`
          );
        }
      }
    },
    [settings.masterActive, settings.watchdog, settings.deviceId]
  );

  // Subscribe to native SMS events and dispatch independently to every matching endpoint.
  // Each endpoint receives its own log and retry lifecycle, so one failure never resends
  // a message to endpoints that have already succeeded.
  useEffect(() => {
    const unsubscribe = nativeSmsBridge.onSmsReceived((incoming) => {
      if (!settings.masterActive || endpoints.length === 0) {
        return;
      }

      const sms = {
        sender: incoming.sender,
        message: incoming.message,
        simSlot: incoming.simSlot,
        receivedAt: incoming.receivedAt,
        deviceId: settings.deviceId,
      };

      const matchingEndpoints = endpoints.filter((profile) =>
        evaluateFilterRules(profile, incoming).matched
      );

      if (matchingEndpoints.length === 0) {
        pushToast('info', 'SMS not routed', 'No configured endpoint matched this sender, keyword, or SIM filter.');
        return;
      }

      for (const profile of matchingEndpoints) {
        void dispatchWebhook(profile, sms, { mode: 'live' }).then((entry) => {
          void recordLogAndCheckWatchdog(entry, false);
        }).catch((error) => {
          pushToast(
            'error',
            `Endpoint dispatch error: ${profile.name}`,
            error instanceof Error ? error.message : 'Unexpected forwarding error.'
          );
        });
      }

      pushToast(
        'info',
        'SMS routing started',
        `Sending independently to ${matchingEndpoints.length} matching endpoint${matchingEndpoints.length === 1 ? '' : 's'}.`
      );
    });
    return unsubscribe;
  }, [settings.masterActive, settings.deviceId, endpoints, pushToast, recordLogAndCheckWatchdog]);

  // Endpoint CRUD
  const saveEndpoint = useCallback(
    (profileData: Omit<EndpointProfile, 'id' | 'createdAt' | 'updatedAt'>, editId?: string) => {
      const now = new Date().toISOString();
      if (editId) {
        setEndpoints((prev) =>
          prev.map((ep) =>
            ep.id === editId ? { ...ep, ...profileData, updatedAt: now } : ep
          )
        );
        pushToast('success', 'Endpoint updated', `"${profileData.name}" changes saved.`);
        return editId;
      }
      const newId = generateId('ep');
      const created: EndpointProfile = {
        ...profileData,
        id: newId,
        createdAt: now,
        updatedAt: now,
      };
      setEndpoints((prev) => [created, ...prev]);
      setSettings((prev) => ({
        ...prev,
        activeEndpointId: prev.activeEndpointId ?? newId,
        onboardingCompleted: true,
      }));
      pushToast('success', 'Endpoint created', `"${profileData.name}" is ready for routing.`);
      return newId;
    },
    [pushToast]
  );

  const completeOnboardingWizard = useCallback(
    async (
      profileData: Omit<EndpointProfile, 'id' | 'createdAt' | 'updatedAt'>,
      goLive: boolean
    ) => {
      const now = new Date().toISOString();
      const created: EndpointProfile = {
        ...profileData,
        id: generateId('ep'),
        createdAt: now,
        updatedAt: now,
      };
      setEndpoints((prev) => [created, ...prev]);
      setSettings((prev) => ({
        ...prev,
        activeEndpointId: created.id,
        onboardingCompleted: true,
      }));
      if (goLive) {
        await activateEngineForProfile(created);
      } else {
        pushToast('success', 'Setup complete', `"${created.name}" saved.`);
      }
    },
    [activateEngineForProfile, pushToast]
  );

  const markOnboardingDismissed = useCallback(() => {
    setSettings((prev) => ({ ...prev, onboardingCompleted: true }));
  }, []);

  const duplicateEndpoint = useCallback(
    (id: string) => {
      const source = endpoints.find((ep) => ep.id === id);
      if (!source) return;
      const now = new Date().toISOString();
      const copy: EndpointProfile = {
        ...source,
        id: generateId('ep'),
        name: `${source.name} (Copy)`,
        headers: source.headers.map((h) => ({ ...h, id: generateId('hdr') })),
        createdAt: now,
        updatedAt: now,
      };
      setEndpoints((prev) => [copy, ...prev]);
      pushToast('success', 'Endpoint duplicated', `Created "${copy.name}".`);
    },
    [endpoints, pushToast]
  );

  const deleteEndpoint = useCallback(
    (id: string) => {
      const target = endpoints.find((ep) => ep.id === id);
      setEndpoints((prev) => prev.filter((ep) => ep.id !== id));
      if (target) {
        pushToast('info', 'Endpoint removed', `"${target.name}" was deleted.`);
      }
    },
    [endpoints, pushToast]
  );

  const setActiveEndpoint = useCallback(
    (id: string) => {
      setSettings((prev) => ({ ...prev, activeEndpointId: id }));
      const found = endpoints.find((ep) => ep.id === id);
      if (found) {
        pushToast('info', 'Active endpoint switched', `Routing now targets "${found.name}".`);
      }
    },
    [endpoints, pushToast]
  );

  // Instant floating "Simulate Incoming SMS" quick-trigger on Dashboard (Web Preview mode)
  const triggerQuickSimulatedSms = useCallback(async (): Promise<WebhookLogEntry | null> => {
    if (!activeEndpoint) {
      pushToast('warning', 'No endpoint configured', 'Complete the Setup Wizard or add an endpoint first.');
      return null;
    }

    const template = SIM_SMS_TEMPLATES[Math.floor(Math.random() * SIM_SMS_TEMPLATES.length)];
    // Choose a sender that passes the profile's allowedSenders if restricted, so the demo hits the live feed cleanly
    const allowsAll =
      activeEndpoint.allowedSenders.length === 0 ||
      activeEndpoint.allowedSenders.some((s) => s.toUpperCase() === 'ALL' || s === '*');
    const chosenSender = allowsAll ? template.sender : activeEndpoint.allowedSenders[0];
    const chosenSim =
      activeEndpoint.simFilter === 'SIM_1'
        ? 'SIM 1'
        : activeEndpoint.simFilter === 'SIM_2'
          ? 'SIM 2'
          : template.simSlot;

    const entry = await dispatchWebhook(
      activeEndpoint,
      {
        sender: chosenSender,
        message: template.buildMessage(),
        simSlot: chosenSim,
        receivedAt: new Date().toISOString(),
        deviceId: settings.deviceId,
      },
      { mode: 'simulated', simulationOutcome: '200_ok' }
    );

    await recordLogAndCheckWatchdog(entry, false);
    pushToast(
      'success',
      `SMS Forwarded · ${chosenSender}`,
      `HTTP 200 OK in ${entry.response.latencyMs}ms (${chosenSim})`
    );
    return entry;
  }, [activeEndpoint, settings.deviceId, recordLogAndCheckWatchdog, pushToast]);

  // Manual test webhook execution (Tester tab)
  const executeTestWebhook = useCallback(
    async (params: {
      profile: EndpointProfile;
      sender: string;
      message: string;
      simSlot: 'SIM 1' | 'SIM 2';
      mode: 'live' | 'simulated';
      simulationOutcome?: SimulationOutcome;
    }): Promise<WebhookLogEntry> => {
      const entry = await dispatchWebhook(
        params.profile,
        {
          sender: params.sender,
          message: params.message,
          simSlot: params.simSlot,
          receivedAt: new Date().toISOString(),
          deviceId: settings.deviceId,
        },
        {
          mode: params.mode,
          simulationOutcome: params.simulationOutcome,
        }
      );

      await recordLogAndCheckWatchdog(entry, false);
      if (entry.status === 'success') {
        pushToast(
          'success',
          `Delivered · HTTP ${entry.response.statusCode}`,
          `Completed in ${entry.response.latencyMs}ms`
        );
      } else if (entry.status === 'pending') {
        pushToast(
          'warning',
          'Queued for retry',
          entry.response.error ?? 'Added to offline retry queue.'
        );
      } else {
        pushToast(
          'error',
          `Delivery failed${entry.response.statusCode ? ` · HTTP ${entry.response.statusCode}` : ''}`,
          entry.response.error ?? 'See Log Inspector for details.'
        );
      }
      return entry;
    },
    [settings.deviceId, recordLogAndCheckWatchdog, pushToast]
  );

  // Retry a single failed/pending log entry
  const retryLogEntry = useCallback(
    async (logId: string, overrideSimulatedSuccess?: boolean): Promise<WebhookLogEntry | null> => {
      const existing = logs.find((l) => l.id === logId);
      if (!existing) return null;

      const profile = endpoints.find((ep) => ep.id === existing.endpointId);
      if (!profile) {
        pushToast('error', 'Profile not found', 'Original endpoint profile was deleted.');
        return null;
      }

      const updated = await dispatchWebhook(profile, existing.sms, {
        mode: existing.mode,
        simulationOutcome: overrideSimulatedSuccess ? '200_ok' : '200_ok',
        existingLogId: existing.id,
        priorAttempts: existing.attempts,
      });

      await recordLogAndCheckWatchdog(updated, true);
      if (updated.status === 'success') {
        pushToast(
          'success',
          'Retry succeeded',
          `HTTP ${updated.response.statusCode} in ${updated.response.latencyMs}ms`
        );
      } else {
        pushToast(
          'warning',
          'Retry attempt did not succeed',
          updated.response.error ?? 'Remains queued/failed.'
        );
      }
      return updated;
    },
    [logs, endpoints, recordLogAndCheckWatchdog, pushToast]
  );

  const processPendingQueue = useCallback(async () => {
    const pending = logs.filter((l) => l.status === 'pending');
    if (pending.length === 0) {
      pushToast('info', 'Queue is empty', 'No pending items waiting for retry.');
      return;
    }
    let succeeded = 0;
    for (const item of pending) {
      const res = await retryLogEntry(item.id, true);
      if (res?.status === 'success') succeeded += 1;
    }
    pushToast(
      succeeded === pending.length ? 'success' : 'info',
      'Retry queue processed',
      `${succeeded} of ${pending.length} queued items delivered.`
    );
  }, [logs, retryLogEntry, pushToast]);

  const clearLogs = useCallback(() => {
    setLogs([]);
    pushToast('info', 'Logs cleared', 'All local HTTP forwarding history has been removed.');
  }, [pushToast]);

  // Native Android readiness actions
  const grantSmsPermissions = useCallback(async () => {
    await nativeSmsBridge.requestSmsPermissions();
    setReadiness(await nativeSmsBridge.getReadinessSnapshot());
    pushToast('success', 'SMS Permissions Granted', 'RECEIVE_SMS & READ_SMS ready.');
  }, [pushToast]);

  const bypassBatteryOptimization = useCallback(async () => {
    await nativeSmsBridge.requestBatteryOptimizationBypass();
    setReadiness(await nativeSmsBridge.getReadinessSnapshot());
    pushToast('success', 'Battery Optimization Bypassed', 'Doze mode whitelist active.');
  }, [pushToast]);

  const enableForegroundService = useCallback(async () => {
    await nativeSmsBridge.startForegroundService();
    setReadiness(await nativeSmsBridge.getReadinessSnapshot());
    pushToast('success', 'Foreground Service Armed', 'Background relay lock enabled.');
  }, [pushToast]);

  const toggleBootAutoStart = useCallback(async () => {
    const next = !readiness.bootAutoStartEnabled;
    await nativeSmsBridge.setBootAutoStart(next);
    setReadiness(await nativeSmsBridge.getReadinessSnapshot());
    pushToast(
      'info',
      next ? 'Boot Auto-Start Enabled' : 'Boot Auto-Start Disabled',
      next
        ? 'Service will resume automatically after device reboot.'
        : 'Manual launch required after reboot.'
    );
  }, [readiness.bootAutoStartEnabled, pushToast]);

  // Settings updates
  const toggleTheme = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  }, []);

  const updateDeviceId = useCallback(
    (deviceId: string) => {
      const cleaned = deviceId.trim();
      if (!cleaned) return;
      setSettings((prev) => ({ ...prev, deviceId: cleaned }));
      pushToast('success', 'Device ID updated', `Requests will identify as "${cleaned}".`);
    },
    [pushToast]
  );

  const updateWatchdog = useCallback((patch: Partial<AppSettings['watchdog']>) => {
    setSettings((prev) => ({
      ...prev,
      watchdog: { ...prev.watchdog, ...patch },
    }));
  }, []);

  const testWatchdog = useCallback(async () => {
    const result = await sendWatchdogAlert(
      settings.watchdog,
      settings.deviceId,
      'Manual watchdog connectivity test triggered from Settings.'
    );
    setSettings((prev) => ({
      ...prev,
      watchdog: {
        ...prev.watchdog,
        lastTestedAt: new Date().toISOString(),
        lastTestResult: result,
      },
    }));
    pushToast(
      result.ok ? 'success' : 'warning',
      result.ok ? 'Watchdog Alert Sent' : 'Alert Test Notice',
      result.message
    );
    return result;
  }, [settings.watchdog, settings.deviceId, pushToast]);

  const setPinLock = useCallback(
    (pinHash: string | null) => {
      setSettings((prev) => ({
        ...prev,
        security: {
          pinEnabled: Boolean(pinHash),
          pinHash,
        },
      }));
      if (!pinHash) {
        setIsLocked(false);
        pushToast('info', 'App PIN Disabled', 'PIN lock has been turned off.');
      } else {
        pushToast('success', 'App PIN Enabled', 'Settings and API credentials are now protected.');
      }
    },
    [pushToast]
  );

  const lockApp = useCallback(() => {
    if (settings.security.pinEnabled && settings.security.pinHash) {
      setIsLocked(true);
    }
  }, [settings.security.pinEnabled, settings.security.pinHash]);

  const unlockApp = useCallback(() => {
    setIsLocked(false);
    pushToast('success', 'Workspace unlocked');
  }, [pushToast]);

  const getBackupData = useCallback((): BackupPayloadData => {
    return {
      endpoints,
      settings: {
        deviceId: settings.deviceId,
        activeEndpointId: settings.activeEndpointId,
        watchdog: settings.watchdog,
        theme: settings.theme,
      },
    };
  }, [endpoints, settings]);

  const importBackupText = useCallback(
    (rawText: string, passphrase: string = '') => {
      const parsed = parseBackupConfig(rawText, passphrase);
      if (!parsed.ok) {
        return parsed;
      }
      setEndpoints(parsed.data.endpoints);
      setSettings((prev) => ({
        ...prev,
        deviceId: parsed.data.settings.deviceId || prev.deviceId,
        activeEndpointId:
          parsed.data.settings.activeEndpointId ?? parsed.data.endpoints[0]?.id ?? null,
        onboardingCompleted: true,
        watchdog: { ...prev.watchdog, ...(parsed.data.settings.watchdog ?? {}) },
        theme: parsed.data.settings.theme ?? prev.theme,
      }));
      pushToast(
        'success',
        'Configuration restored',
        `Imported ${parsed.data.endpoints.length} endpoint profile${parsed.data.endpoints.length === 1 ? '' : 's'}.`
      );
      return parsed;
    },
    [pushToast]
  );

  const resetWorkspace = useCallback(() => {
    setEndpoints([]);
    setLogs([]);
    setNotifications([]);
    setConnectedSince(null);
    setSettings((prev) => ({
      ...createDefaultSettings(),
      theme: prev.theme,
    }));
    setIsLocked(false);
    pushToast('info', 'Workspace reset', 'All local profiles, logs, and settings were cleared.');
  }, [pushToast]);

  return {
    endpoints,
    logs,
    notifications,
    settings,
    activeEndpoint,
    readiness,
    heartbeat,
    connectionState,
    isConnecting,
    connectedSince,
    kpis,
    toasts,
    isLocked,
    pushToast,
    dismissToast,
    markAllNotificationsRead,
    clearNotifications,
    toggleMasterActive,
    checkHeartbeat,
    saveEndpoint,
    completeOnboardingWizard,
    markOnboardingDismissed,
    duplicateEndpoint,
    deleteEndpoint,
    setActiveEndpoint,
    triggerQuickSimulatedSms,
    executeTestWebhook,
    retryLogEntry,
    processPendingQueue,
    clearLogs,
    grantSmsPermissions,
    bypassBatteryOptimization,
    enableForegroundService,
    toggleBootAutoStart,
    toggleTheme,
    updateDeviceId,
    updateWatchdog,
    testWatchdog,
    setPinLock,
    lockApp,
    unlockApp,
    getBackupData,
    importBackupText,
    resetWorkspace,
  };
}
