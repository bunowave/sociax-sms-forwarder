import type {
  AppSettings,
  EndpointProfile,
  LogStatus,
  SimSlot,
  SmsEnvelope,
  SsfWorkspaceBackup,
  WebhookLogEntry,
} from '../types/ssf';

export const DEFAULT_PAYLOAD_TEMPLATE = `{
  "sender": "{{sender}}",
  "message": "{{message}}",
  "sim_slot": "{{sim_slot}}",
  "timestamp": "{{timestamp}}",
  "device_id": "{{device_id}}"
}`;

export const TEMPLATE_VARIABLES = [
  { token: '{{sender}}', label: 'sender', description: 'SMS Sender ID or phone number' },
  { token: '{{message}}', label: 'message', description: 'Full SMS body content' },
  { token: '{{sim_slot}}', label: 'sim_slot', description: 'SIM 1 or SIM 2 slot label' },
  { token: '{{timestamp}}', label: 'timestamp', description: 'ISO-8601 receipt timestamp' },
  { token: '{{device_id}}', label: 'device_id', description: 'Configured SSF device identifier' },
] as const;

export interface TemplateVariables {
  sender: string;
  message: string;
  sim_slot: string;
  timestamp: string;
  device_id: string;
}

export function validateWebhookUrl(rawUrl: string): { valid: boolean; error?: string } {
  const trimmed = rawUrl.trim();
  if (!trimmed) {
    return { valid: false, error: 'Webhook URL is required.' };
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== 'https:') {
      return {
        valid: false,
        error: 'Webhook URL must use HTTPS (https://...) for secure transmission.',
      };
    }
    if (!parsed.hostname || !parsed.hostname.includes('.')) {
      return { valid: false, error: 'Enter a valid domain name (e.g. https://api.yourdomain.com/webhook).' };
    }
    return { valid: true };
  } catch {
    return { valid: false, error: 'Enter a valid HTTPS URL (e.g. https://api.yourdomain.com/webhook).' };
  }
}

export function validateRegexPattern(pattern: string): { valid: boolean; error?: string } {
  const trimmed = pattern.trim();
  if (!trimmed) {
    return { valid: true };
  }
  try {
    new RegExp(trimmed, 'i');
    return { valid: true };
  } catch (err) {
    return {
      valid: false,
      error: err instanceof Error ? err.message : 'Invalid regular expression syntax.',
    };
  }
}

function escapeJsonStringValue(value: string): string {
  // JSON.stringify wraps in quotes; slice off surrounding quotes so it drops cleanly inside "{{var}}"
  return JSON.stringify(value).slice(1, -1);
}

export function renderPayloadTemplate(
  template: string,
  variables: TemplateVariables
): { rendered: string; validJson: boolean; error?: string } {
  const map: Record<string, string> = {
    '{{sender}}': escapeJsonStringValue(variables.sender),
    '{{message}}': escapeJsonStringValue(variables.message),
    '{{sim_slot}}': escapeJsonStringValue(variables.sim_slot),
    '{{timestamp}}': escapeJsonStringValue(variables.timestamp),
    '{{device_id}}': escapeJsonStringValue(variables.device_id),
  };

  const rendered = template.replace(
    /\{\{(sender|message|sim_slot|timestamp|device_id)\}\}/g,
    (match) => map[match] ?? match
  );

  try {
    const parsed = JSON.parse(rendered);
    return {
      rendered: JSON.stringify(parsed, null, 2),
      validJson: true,
    };
  } catch (err) {
    return {
      rendered,
      validJson: false,
      error: err instanceof Error ? err.message : 'Invalid JSON template.',
    };
  }
}

export function evaluateFilterRules(
  profile: Pick<EndpointProfile, 'allowedSenders' | 'keywordRegex' | 'simFilter'>,
  sms: Pick<SmsEnvelope, 'sender' | 'message' | 'simSlot'>
): { matched: boolean; reason?: string } {
  // 1. SIM slot filter
  if (profile.simFilter === 'SIM_1' && sms.simSlot !== 'SIM 1') {
    return { matched: false, reason: 'Blocked by SIM Slot rule (profile accepts SIM 1 Only).' };
  }
  if (profile.simFilter === 'SIM_2' && sms.simSlot !== 'SIM 2') {
    return { matched: false, reason: 'Blocked by SIM Slot rule (profile accepts SIM 2 Only).' };
  }

  // 2. Allowed Sender IDs filter
  const normalizedSenders = profile.allowedSenders
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);

  const allowsAll =
    normalizedSenders.length === 0 ||
    normalizedSenders.includes('all') ||
    normalizedSenders.includes('*');

  if (!allowsAll) {
    const incomingSender = sms.sender.trim().toLowerCase();
    const senderMatches = normalizedSenders.some(
      (allowed) => incomingSender === allowed || incomingSender.includes(allowed)
    );
    if (!senderMatches) {
      return {
        matched: false,
        reason: `Sender "${sms.sender}" is not in allowed sender list (${profile.allowedSenders.join(', ')}).`,
      };
    }
  }

  // 3. Optional Keyword / Regex filter
  const pattern = profile.keywordRegex.trim();
  if (pattern) {
    const check = validateRegexPattern(pattern);
    if (!check.valid) {
      return { matched: false, reason: `Invalid filter regex: ${check.error}` };
    }
    const regex = new RegExp(pattern, 'i');
    if (!regex.test(sms.message)) {
      return {
        matched: false,
        reason: `Message did not match required keyword/regex pattern /${pattern}/i.`,
      };
    }
  }

  return { matched: true };
}

export function computeNextRetryDelayMs(attempt: number, exponentialBackoff: boolean): number {
  const safeAttempt = Math.max(1, attempt);
  if (!exponentialBackoff) {
    return 15_000; // Fixed 15s interval
  }
  // 5s, 10s, 20s, 40s, 80s... capped at 5 minutes
  return Math.min(300_000, 5_000 * Math.pow(2, safeAttempt - 1));
}

export interface DashboardKpis {
  forwardedToday: number;
  successRate: number | null;
  pendingQueueCount: number;
  failedCount: number;
  consecutiveFailures: number;
}

export function computeDashboardKpis(
  logs: WebhookLogEntry[],
  referenceDate: Date = new Date()
): DashboardKpis {
  const startOfDay = new Date(
    referenceDate.getFullYear(),
    referenceDate.getMonth(),
    referenceDate.getDate()
  ).getTime();

  let forwardedToday = 0;
  let successCount = 0;
  let pendingQueueCount = 0;
  let failedCount = 0;

  for (const log of logs) {
    const ts = new Date(log.sms.receivedAt).getTime();
    if (!Number.isNaN(ts) && ts >= startOfDay) {
      forwardedToday += 1;
    }
    if (log.status === 'success') {
      successCount += 1;
    } else if (log.status === 'pending') {
      pendingQueueCount += 1;
    } else if (log.status === 'failed') {
      failedCount += 1;
    }
  }

  const completed = successCount + failedCount;
  const successRate = completed > 0 ? Math.round((successCount / completed) * 1000) / 10 : null;

  // Count consecutive non-success failures from most recent logs
  let consecutiveFailures = 0;
  for (const log of logs) {
    if (log.status === 'failed') {
      consecutiveFailures += 1;
    } else if (log.status === 'success') {
      break;
    }
  }

  return {
    forwardedToday,
    successRate,
    pendingQueueCount,
    failedCount,
    consecutiveFailures,
  };
}

export function filterWebhookLogs(
  logs: WebhookLogEntry[],
  statusFilter: 'all' | LogStatus,
  searchQuery: string
): WebhookLogEntry[] {
  const q = searchQuery.trim().toLowerCase();
  return logs.filter((log) => {
    if (statusFilter !== 'all' && log.status !== statusFilter) {
      return false;
    }
    if (!q) {
      return true;
    }
    const haystack = [
      log.sms.sender,
      log.sms.message,
      log.sms.simSlot,
      log.endpointName,
      log.endpointUrl,
      log.response.statusCode ? String(log.response.statusCode) : '',
      log.response.body,
      log.response.error ?? '',
    ]
      .join(' ')
      .toLowerCase();
    return haystack.includes(q);
  });
}

// Fast deterministic FNV-1a 32-bit hash for local PIN verification & backup integrity checksum
function fnv1aHex(input: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

export function hashPin(pin: string): string {
  const normalized = pin.trim();
  const round1 = fnv1aHex(`ssf::pin::v1::${normalized}`);
  const round2 = fnv1aHex(`${round1}::sociax::${normalized.split('').reverse().join('')}`);
  return `ssf_pin_${round1}_${round2}`;
}

export function verifyPin(pin: string, storedHash: string | null): boolean {
  if (!storedHash) return false;
  return hashPin(pin) === storedHash;
}

function xorCipher(text: string, secret: string): string {
  const key = secret || 'ssf-default-envelope-key';
  let result = '';
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i) ^ key.charCodeAt(i % key.length);
    result += String.fromCharCode(code);
  }
  return result;
}

function encodeBase64Utf8(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (const byte of bytes) {
    binary += String.fromCharCode(byte);
  }
  return btoa(binary);
}

function decodeBase64Utf8(b64: string): string {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

export interface BackupPayloadData {
  endpoints: EndpointProfile[];
  settings: Pick<AppSettings, 'deviceId' | 'activeEndpointId' | 'watchdog' | 'theme'>;
}

export function serializeBackupConfig(
  data: BackupPayloadData,
  passphrase: string = ''
): SsfWorkspaceBackup {
  const rawJson = JSON.stringify(data);
  const trimmedKey = passphrase.trim();
  const transformed = trimmedKey ? xorCipher(rawJson, trimmedKey) : rawJson;
  const payload = encodeBase64Utf8(transformed);
  const checksum = fnv1aHex(`${rawJson}::${trimmedKey ? 'enc' : 'plain'}`);

  return {
    format: 'ssf-config-v1',
    exportedAt: new Date().toISOString(),
    encrypted: Boolean(trimmedKey),
    checksum,
    payload,
  };
}

export function parseBackupConfig(
  rawText: string,
  passphrase: string = ''
): { ok: true; data: BackupPayloadData } | { ok: false; error: string; needsPassphrase?: boolean } {
  let parsed: unknown;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    return { ok: false, error: 'Invalid JSON file. Expected a valid .ssf.json backup.' };
  }

  if (!parsed || typeof parsed !== 'object') {
    return { ok: false, error: 'Backup file structure is unrecognized.' };
  }

  const record = parsed as Partial<SsfWorkspaceBackup>;
  if (record.format !== 'ssf-config-v1' || typeof record.payload !== 'string') {
    return { ok: false, error: 'Unsupported backup format. Expected ssf-config-v1.' };
  }

  const trimmedKey = passphrase.trim();
  if (record.encrypted && !trimmedKey) {
    return {
      ok: false,
      error: 'This backup is passphrase-protected. Enter the passphrase to decrypt.',
      needsPassphrase: true,
    };
  }

  try {
    const decoded = decodeBase64Utf8(record.payload);
    const jsonText = record.encrypted ? xorCipher(decoded, trimmedKey) : decoded;
    const expectedChecksum = fnv1aHex(`${jsonText}::${record.encrypted ? 'enc' : 'plain'}`);
    if (record.checksum && expectedChecksum !== record.checksum) {
      return {
        ok: false,
        error: record.encrypted
          ? 'Incorrect passphrase or corrupted backup checksum.'
          : 'Backup integrity check failed (file may be modified or corrupted).',
      };
    }

    const inner = JSON.parse(jsonText) as Partial<BackupPayloadData>;
    if (!Array.isArray(inner.endpoints)) {
      return { ok: false, error: 'Backup payload is missing endpoint profiles array.' };
    }

    return {
      ok: true,
      data: {
        endpoints: inner.endpoints,
        settings: inner.settings ?? {
          deviceId: `ssf-device-${Math.random().toString(36).slice(2, 8)}`,
          activeEndpointId: inner.endpoints[0]?.id ?? null,
          theme: 'dark',
          watchdog: {
            channel: 'disabled',
            telegramBotToken: '',
            telegramChatId: '',
            alertWebhookUrl: '',
            notifyLowBattery: true,
            notifyDeviceOffline: true,
            notifyConsecutiveFailures: true,
          },
        },
      },
    };
  } catch {
    return {
      ok: false,
      error: record.encrypted
        ? 'Decryption failed. Verify your backup passphrase.'
        : 'Could not decode backup payload.',
    };
  }
}

export function encodeEndpointQrPayload(profile: EndpointProfile): string {
  const compact = {
    v: 1,
    t: 'ssf-endpoint',
    n: profile.name,
    c: profile.colorTag,
    u: profile.url,
    h: profile.headers.map((h) => ({ k: h.key, v: h.value, s: h.isSecret ? 1 : 0 })),
    p: profile.payloadTemplate,
    a: profile.allowedSenders,
    r: profile.keywordRegex,
    sim: profile.simFilter,
    rp: profile.retryPolicy,
  };
  return JSON.stringify(compact);
}

export function parseQrConfigPayload(
  rawText: string
): { ok: true; profile: Omit<EndpointProfile, 'id' | 'createdAt' | 'updatedAt'> } | { ok: false; error: string } {
  let obj: unknown;
  try {
    obj = JSON.parse(rawText.trim());
  } catch {
    return { ok: false, error: 'QR content is not valid JSON.' };
  }

  if (!obj || typeof obj !== 'object') {
    return { ok: false, error: 'Invalid QR configuration payload.' };
  }

  const data = obj as Record<string, unknown>;

  // Support compact QR format (v: 1, t: 'ssf-endpoint') AND full EndpointProfile JSON
  if (data.t === 'ssf-endpoint' && typeof data.u === 'string') {
    const urlCheck = validateWebhookUrl(data.u);
    if (!urlCheck.valid) {
      return { ok: false, error: urlCheck.error ?? 'Invalid HTTPS URL in QR config.' };
    }
    const headersRaw = Array.isArray(data.h) ? data.h : [];
    const headers = headersRaw
      .filter((item): item is { k: string; v: string; s?: number } => Boolean(item && typeof item === 'object'))
      .map((item, idx) => ({
        id: `hdr_qr_${Date.now()}_${idx}`,
        key: String(item.k ?? ''),
        value: String(item.v ?? ''),
        isSecret: Boolean(item.s),
      }));

    return {
      ok: true,
      profile: {
        name: typeof data.n === 'string' && data.n.trim() ? data.n.trim() : 'Imported Profile',
        colorTag: (['violet', 'indigo', 'emerald', 'amber', 'rose', 'sky'].includes(String(data.c))
          ? data.c
          : 'violet') as EndpointProfile['colorTag'],
        url: data.u.trim(),
        headers,
        payloadTemplate: typeof data.p === 'string' ? data.p : DEFAULT_PAYLOAD_TEMPLATE,
        allowedSenders: Array.isArray(data.a) ? data.a.map(String) : ['ALL'],
        keywordRegex: typeof data.r === 'string' ? data.r : '',
        simFilter: (['BOTH', 'SIM_1', 'SIM_2'].includes(String(data.sim))
          ? data.sim
          : 'BOTH') as EndpointProfile['simFilter'],
        retryPolicy:
          data.rp && typeof data.rp === 'object'
            ? {
                maxRetries: Number((data.rp as { maxRetries?: number }).maxRetries ?? 5),
                exponentialBackoff: Boolean(
                  (data.rp as { exponentialBackoff?: boolean }).exponentialBackoff ?? true
                ),
                offlineQueue: Boolean((data.rp as { offlineQueue?: boolean }).offlineQueue ?? true),
              }
            : { maxRetries: 5, exponentialBackoff: true, offlineQueue: true },
      },
    };
  }

  // Fallback: full profile JSON object
  if (typeof data.url === 'string') {
    const urlCheck = validateWebhookUrl(data.url);
    if (!urlCheck.valid) {
      return { ok: false, error: urlCheck.error ?? 'Invalid HTTPS URL.' };
    }
    const rawHeaders = Array.isArray(data.headers) ? data.headers : [];
    return {
      ok: true,
      profile: {
        name: typeof data.name === 'string' && data.name.trim() ? data.name.trim() : 'Imported Profile',
        colorTag: (['violet', 'indigo', 'emerald', 'amber', 'rose', 'sky'].includes(String(data.colorTag))
          ? data.colorTag
          : 'violet') as EndpointProfile['colorTag'],
        url: data.url.trim(),
        headers: rawHeaders.map((h: Record<string, unknown>, idx: number) => ({
          id: `hdr_imp_${Date.now()}_${idx}`,
          key: String(h.key ?? ''),
          value: String(h.value ?? ''),
          isSecret: Boolean(h.isSecret),
        })),
        payloadTemplate:
          typeof data.payloadTemplate === 'string' ? data.payloadTemplate : DEFAULT_PAYLOAD_TEMPLATE,
        allowedSenders: Array.isArray(data.allowedSenders)
          ? data.allowedSenders.map(String)
          : ['ALL'],
        keywordRegex: typeof data.keywordRegex === 'string' ? data.keywordRegex : '',
        simFilter: (['BOTH', 'SIM_1', 'SIM_2'].includes(String(data.simFilter))
          ? data.simFilter
          : 'BOTH') as EndpointProfile['simFilter'],
        retryPolicy:
          data.retryPolicy && typeof data.retryPolicy === 'object'
            ? {
                maxRetries: Number((data.retryPolicy as { maxRetries?: number }).maxRetries ?? 5),
                exponentialBackoff: Boolean(
                  (data.retryPolicy as { exponentialBackoff?: boolean }).exponentialBackoff ?? true
                ),
                offlineQueue: Boolean(
                  (data.retryPolicy as { offlineQueue?: boolean }).offlineQueue ?? true
                ),
              }
            : { maxRetries: 5, exponentialBackoff: true, offlineQueue: true },
      },
    };
  }

  return { ok: false, error: 'Unrecognized QR config schema. Missing webhook URL.' };
}

export function maskSecretValue(value: string): string {
  if (!value) return '••••••••';
  if (value.length <= 6) return '•'.repeat(Math.max(4, value.length));
  return `${value.slice(0, 3)}${'•'.repeat(Math.min(12, value.length - 5))}${value.slice(-2)}`;
}

export function generateId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 9);
  return `${prefix}_${Date.now().toString(36)}_${rand}`;
}

export function formatRelativeTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const diffSec = Math.floor((Date.now() - date.getTime()) / 1000);
  if (diffSec < 5) return 'Just now';
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function formatTimestampTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return date.toLocaleTimeString(undefined, {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function normalizeSimSlot(sim: SimSlot): SimSlot {
  return sim === 'SIM 2' ? 'SIM 2' : 'SIM 1';
}

export function formatUptime(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  return [hrs, mins, secs].map((n) => String(n).padStart(2, '0')).join(':');
}

export function extractEndpointDomain(rawUrl: string): string {
  try {
    const parsed = new URL(rawUrl.trim());
    return parsed.hostname;
  } catch {
    return rawUrl.trim() || 'unconfigured';
  }
}

export interface SparklinePoint {
  id: string;
  latencyMs: number;
  status: LogStatus;
  timeLabel: string;
}

export interface SparklineSummary {
  points: SparklinePoint[];
  avgLatencyMs: number | null;
  minLatencyMs: number | null;
  maxLatencyMs: number | null;
  throughputLastHour: number;
}

export function buildSparklineSeries(
  logs: WebhookLogEntry[],
  maxPoints: number = 16,
  nowMs: number = Date.now()
): SparklineSummary {
  const recent = logs.slice(0, maxPoints).reverse();
  const points: SparklinePoint[] = recent.map((l) => ({
    id: l.id,
    latencyMs: Math.max(1, l.response.latencyMs),
    status: l.status,
    timeLabel: formatTimestampTime(l.sms.receivedAt),
  }));

  const oneHourAgo = nowMs - 3_600_000;
  let throughputLastHour = 0;
  for (const l of logs) {
    const t = new Date(l.sms.receivedAt).getTime();
    if (!Number.isNaN(t) && t >= oneHourAgo) {
      throughputLastHour += 1;
    }
  }

  if (points.length === 0) {
    return {
      points: [],
      avgLatencyMs: null,
      minLatencyMs: null,
      maxLatencyMs: null,
      throughputLastHour,
    };
  }

  let sum = 0;
  let min = Infinity;
  let max = -Infinity;
  for (const p of points) {
    sum += p.latencyMs;
    if (p.latencyMs < min) min = p.latencyMs;
    if (p.latencyMs > max) max = p.latencyMs;
  }

  return {
    points,
    avgLatencyMs: Math.round(sum / points.length),
    minLatencyMs: min,
    maxLatencyMs: max,
    throughputLastHour,
  };
}

export function deriveConnectionState(params: {
  masterActive: boolean;
  isConnecting: boolean;
  hasActiveEndpoint: boolean;
  heartbeatStatus: 'connected' | 'paused' | 'unconfigured' | 'checking' | 'unreachable';
  consecutiveFailures: number;
}): 'standby' | 'connecting' | 'connected' | 'degraded' {
  if (params.isConnecting || params.heartbeatStatus === 'checking') {
    return 'connecting';
  }
  if (!params.masterActive || !params.hasActiveEndpoint) {
    return 'standby';
  }
  if (params.heartbeatStatus === 'unreachable' || params.consecutiveFailures >= 2) {
    return 'degraded';
  }
  return 'connected';
}

