import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_PAYLOAD_TEMPLATE,
  computeDashboardKpis,
  computeNextRetryDelayMs,
  encodeEndpointQrPayload,
  evaluateFilterRules,
  filterWebhookLogs,
  hashPin,
  parseBackupConfig,
  parseQrConfigPayload,
  renderPayloadTemplate,
  serializeBackupConfig,
  validateWebhookUrl,
  verifyPin,
} from './webhookEngine';
import type { EndpointProfile, WebhookLogEntry } from '../types/ssf';

test('validateWebhookUrl enforces strict HTTPS and domain presence', () => {
  assert.equal(validateWebhookUrl('').valid, false);
  assert.equal(validateWebhookUrl('http://api.example.com/hook').valid, false);
  assert.equal(validateWebhookUrl('https://localhost').valid, false);
  assert.equal(validateWebhookUrl('not-a-url').valid, false);
  assert.equal(validateWebhookUrl('https://hooks.example.com/v1/sms').valid, true);
});

test('renderPayloadTemplate safely escapes quotes and newlines inside SMS messages', () => {
  const result = renderPayloadTemplate(DEFAULT_PAYLOAD_TEMPLATE, {
    sender: 'ALERT-01',
    message: 'Line 1 "quoted"\nLine 2 \\ path',
    sim_slot: 'SIM 1',
    timestamp: '2026-11-25T10:00:00.000Z',
    device_id: 'ssf-node-01',
  });

  assert.equal(result.validJson, true);
  const parsed = JSON.parse(result.rendered);
  assert.equal(parsed.sender, 'ALERT-01');
  assert.equal(parsed.message, 'Line 1 "quoted"\nLine 2 \\ path');
  assert.equal(parsed.sim_slot, 'SIM 1');
  assert.equal(parsed.device_id, 'ssf-node-01');
});

test('evaluateFilterRules checks SIM slot, allowed senders, and regex filters accurately', () => {
  const profile = {
    allowedSenders: ['ALERT-01', '16216'],
    keywordRegex: 'TrxID\\s+[A-Z0-9]+',
    simFilter: 'SIM_1' as const,
  };

  // Exact match
  const ok = evaluateFilterRules(profile, {
    sender: 'ALERT-01',
    message: 'Payment received TrxID AB12CD34',
    simSlot: 'SIM 1',
  });
  assert.equal(ok.matched, true);

  // Wrong SIM slot
  const wrongSim = evaluateFilterRules(profile, {
    sender: 'ALERT-01',
    message: 'Payment received TrxID AB12CD34',
    simSlot: 'SIM 2',
  });
  assert.equal(wrongSim.matched, false);

  // Unlisted sender
  const wrongSender = evaluateFilterRules(profile, {
    sender: 'PERSONAL',
    message: 'Payment received TrxID AB12CD34',
    simSlot: 'SIM 1',
  });
  assert.equal(wrongSender.matched, false);

  // Regex mismatch (prevents leaking personal OTP)
  const wrongBody = evaluateFilterRules(profile, {
    sender: 'ALERT-01',
    message: 'Your personal login code is 991234',
    simSlot: 'SIM 1',
  });
  assert.equal(wrongBody.matched, false);

  // ALL senders wildcard
  const allMatch = evaluateFilterRules(
    { allowedSenders: ['ALL'], keywordRegex: '', simFilter: 'BOTH' },
    { sender: 'ANYBODY', message: 'Hello', simSlot: 'SIM 2' }
  );
  assert.equal(allMatch.matched, true);
});

test('computeNextRetryDelayMs supports fixed and exponential backoff', () => {
  assert.equal(computeNextRetryDelayMs(1, false), 15_000);
  assert.equal(computeNextRetryDelayMs(4, false), 15_000);
  assert.equal(computeNextRetryDelayMs(1, true), 5_000);
  assert.equal(computeNextRetryDelayMs(2, true), 10_000);
  assert.equal(computeNextRetryDelayMs(3, true), 20_000);
  assert.equal(computeNextRetryDelayMs(12, true), 300_000);
});

test('computeDashboardKpis and filterWebhookLogs compute counts and consecutive failures', () => {
  const now = new Date('2026-11-25T12:00:00.000Z');
  const makeLog = (
    id: string,
    status: WebhookLogEntry['status'],
    receivedAt: string,
    sender: string
  ): WebhookLogEntry => ({
    id,
    endpointId: 'ep_1',
    endpointName: 'Primary Hook',
    endpointUrl: 'https://hooks.example.com/sms',
    status,
    sms: {
      sender,
      message: 'Test body',
      simSlot: 'SIM 1',
      receivedAt,
      deviceId: 'ssf-test',
    },
    request: {
      url: 'https://hooks.example.com/sms',
      method: 'POST',
      headers: [],
      body: '{}',
    },
    response: {
      statusCode: status === 'success' ? 200 : status === 'failed' ? 500 : null,
      statusText: status === 'success' ? 'OK' : 'Error',
      latencyMs: 42,
      body: '',
    },
    attempts: 1,
    maxRetries: 5,
    mode: 'simulated',
  });

  const logs: WebhookLogEntry[] = [
    makeLog('1', 'failed', '2026-11-25T11:55:00.000Z', 'SENDER-A'),
    makeLog('2', 'failed', '2026-11-25T11:50:00.000Z', 'SENDER-B'),
    makeLog('3', 'pending', '2026-11-25T11:45:00.000Z', 'SENDER-C'),
    makeLog('4', 'success', '2026-11-25T11:00:00.000Z', 'SENDER-D'),
    makeLog('5', 'success', '2026-11-24T09:00:00.000Z', 'SENDER-OLD'),
  ];

  const kpis = computeDashboardKpis(logs, now);
  assert.equal(kpis.forwardedToday, 4);
  assert.equal(kpis.successRate, 50);
  assert.equal(kpis.pendingQueueCount, 1);
  assert.equal(kpis.failedCount, 2);
  assert.equal(kpis.consecutiveFailures, 2);

  const filteredPending = filterWebhookLogs(logs, 'pending', '');
  assert.equal(filteredPending.length, 1);
  assert.equal(filteredPending[0].id, '3');

  const filteredSearch = filterWebhookLogs(logs, 'all', 'SENDER-D');
  assert.equal(filteredSearch.length, 1);
  assert.equal(filteredSearch[0].id, '4');
});

test('hashPin and verifyPin authenticate 4-digit PINs cleanly', () => {
  const hashed = hashPin('4829');
  assert.notEqual(hashed, '4829');
  assert.equal(verifyPin('4829', hashed), true);
  assert.equal(verifyPin('0000', hashed), false);
});

test('QR config encode/decode round-trip preserves endpoint profile fields', () => {
  const sampleProfile: EndpointProfile = {
    id: 'ep_test',
    name: 'Production Ledger',
    colorTag: 'emerald',
    url: 'https://api.example.com/ingest',
    headers: [{ id: 'h1', key: 'X-Custom-Token', value: 'sec_12345', isSecret: true }],
    payloadTemplate: DEFAULT_PAYLOAD_TEMPLATE,
    allowedSenders: ['BANK-01', '16216'],
    keywordRegex: 'credited',
    simFilter: 'SIM_1',
    retryPolicy: { maxRetries: 5, exponentialBackoff: true, offlineQueue: true },
    createdAt: '2026-11-25T10:00:00.000Z',
    updatedAt: '2026-11-25T10:00:00.000Z',
  };

  const encoded = encodeEndpointQrPayload(sampleProfile);
  const decoded = parseQrConfigPayload(encoded);
  assert.equal(decoded.ok, true);
  if (decoded.ok) {
    assert.equal(decoded.profile.name, 'Production Ledger');
    assert.equal(decoded.profile.url, 'https://api.example.com/ingest');
    assert.equal(decoded.profile.headers.length, 1);
    assert.equal(decoded.profile.headers[0].isSecret, true);
    assert.deepEqual(decoded.profile.allowedSenders, ['BANK-01', '16216']);
    assert.equal(decoded.profile.simFilter, 'SIM_1');
  }
});

test('serializeBackupConfig and parseBackupConfig support plain and passphrase-protected backups', () => {
  const sampleData = {
    endpoints: [
      {
        id: 'ep_1',
        name: 'Store Hook',
        colorTag: 'violet' as const,
        url: 'https://hooks.example.com/store',
        headers: [],
        payloadTemplate: DEFAULT_PAYLOAD_TEMPLATE,
        allowedSenders: ['ALL'],
        keywordRegex: '',
        simFilter: 'BOTH' as const,
        retryPolicy: { maxRetries: 3, exponentialBackoff: true, offlineQueue: true },
        createdAt: '2026-11-25T10:00:00.000Z',
        updatedAt: '2026-11-25T10:00:00.000Z',
      },
    ],
    settings: {
      deviceId: 'ssf-unit-01',
      activeEndpointId: 'ep_1',
      theme: 'dark' as const,
      watchdog: {
        channel: 'disabled' as const,
        telegramBotToken: '',
        telegramChatId: '',
        alertWebhookUrl: '',
        notifyLowBattery: true,
        notifyDeviceOffline: true,
        notifyConsecutiveFailures: true,
      },
    },
  };

  // Unencrypted round-trip
  const plainBackup = serializeBackupConfig(sampleData);
  const parsedPlain = parseBackupConfig(JSON.stringify(plainBackup));
  assert.equal(parsedPlain.ok, true);
  if (parsedPlain.ok) {
    assert.equal(parsedPlain.data.endpoints.length, 1);
    assert.equal(parsedPlain.data.settings.deviceId, 'ssf-unit-01');
  }

  // Passphrase-protected round-trip
  const encBackup = serializeBackupConfig(sampleData, 'my-secret-pass');
  assert.equal(encBackup.encrypted, true);

  const wrongPass = parseBackupConfig(JSON.stringify(encBackup), 'wrong-pass');
  assert.equal(wrongPass.ok, false);

  const rightPass = parseBackupConfig(JSON.stringify(encBackup), 'my-secret-pass');
  assert.equal(rightPass.ok, true);
  if (rightPass.ok) {
    assert.equal(rightPass.data.endpoints[0].url, 'https://hooks.example.com/store');
  }
});

import {
  buildSparklineSeries,
  deriveConnectionState,
  extractEndpointDomain,
  formatUptime,
} from './webhookEngine';

test('formatUptime formats seconds into HH:MM:SS cleanly', () => {
  assert.equal(formatUptime(0), '00:00:00');
  assert.equal(formatUptime(65), '00:01:05');
  assert.equal(formatUptime(3661), '01:01:01');
  assert.equal(formatUptime(-10), '00:00:00');
});

test('extractEndpointDomain extracts hostname safely', () => {
  assert.equal(extractEndpointDomain('https://hooks.example.com/v1/ingest'), 'hooks.example.com');
  assert.equal(extractEndpointDomain('not-valid'), 'not-valid');
});

test('deriveConnectionState transitions accurately across standby, connecting, connected, degraded', () => {
  assert.equal(
    deriveConnectionState({
      masterActive: false,
      isConnecting: false,
      hasActiveEndpoint: true,
      heartbeatStatus: 'paused',
      consecutiveFailures: 0,
    }),
    'standby'
  );
  assert.equal(
    deriveConnectionState({
      masterActive: true,
      isConnecting: true,
      hasActiveEndpoint: true,
      heartbeatStatus: 'checking',
      consecutiveFailures: 0,
    }),
    'connecting'
  );
  assert.equal(
    deriveConnectionState({
      masterActive: true,
      isConnecting: false,
      hasActiveEndpoint: true,
      heartbeatStatus: 'connected',
      consecutiveFailures: 0,
    }),
    'connected'
  );
  assert.equal(
    deriveConnectionState({
      masterActive: true,
      isConnecting: false,
      hasActiveEndpoint: true,
      heartbeatStatus: 'connected',
      consecutiveFailures: 2,
    }),
    'degraded'
  );
});

test('buildSparklineSeries aggregates chronological latency stats and hourly throughput', () => {
  const now = Date.now();
  const sampleLogs: WebhookLogEntry[] = [
    {
      id: 'l2',
      endpointId: 'ep1',
      endpointName: 'Main',
      endpointUrl: 'https://api.example.com',
      status: 'success',
      sms: { sender: 'A', message: 'm', simSlot: 'SIM 1', receivedAt: new Date(now - 10_000).toISOString(), deviceId: 'd1' },
      request: { url: 'https://api.example.com', method: 'POST', headers: [], body: '{}' },
      response: { statusCode: 200, statusText: 'OK', latencyMs: 80, body: '' },
      attempts: 1,
      maxRetries: 5,
      mode: 'simulated',
    },
    {
      id: 'l1',
      endpointId: 'ep1',
      endpointName: 'Main',
      endpointUrl: 'https://api.example.com',
      status: 'success',
      sms: { sender: 'B', message: 'm', simSlot: 'SIM 1', receivedAt: new Date(now - 4_000_000).toISOString(), deviceId: 'd1' },
      request: { url: 'https://api.example.com', method: 'POST', headers: [], body: '{}' },
      response: { statusCode: 200, statusText: 'OK', latencyMs: 40, body: '' },
      attempts: 1,
      maxRetries: 5,
      mode: 'simulated',
    },
  ];
  const summary = buildSparklineSeries(sampleLogs, 10, now);
  assert.equal(summary.points.length, 2);
  assert.equal(summary.points[0].id, 'l1');
  assert.equal(summary.avgLatencyMs, 60);
  assert.equal(summary.minLatencyMs, 40);
  assert.equal(summary.maxLatencyMs, 80);
  assert.equal(summary.throughputLastHour, 1);
});

