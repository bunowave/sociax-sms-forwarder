import type { AndroidReadinessState, SimSlot } from '../types/ssf';

export interface IncomingSmsPayload {
  sender: string;
  message: string;
  simSlot: SimSlot;
  receivedAt: string;
  subscriptionId?: number;
}

export interface SimCardInfo {
  slotIndex: 0 | 1;
  slotLabel: SimSlot;
  carrierName: string;
  isoCountryCode: string;
  active: boolean;
}

export interface PermissionResult {
  receiveSms: boolean;
  readSms: boolean;
  readPhoneState: boolean;
}

export interface BatteryOptimizationResult {
  ignoringBatteryOptimizations: boolean;
  batteryLevel: number;
}

export interface ForegroundServiceResult {
  running: boolean;
  channelId: string;
}

export type SmsListener = (sms: IncomingSmsPayload) => void;

export interface NativeSmsBridge {
  getPlatform(): 'android-capacitor' | 'browser-simulator';
  onSmsReceived(listener: SmsListener): () => void;
  getSimCards(): Promise<SimCardInfo[]>;
  requestSmsPermissions(): Promise<PermissionResult>;
  checkBatteryOptimization(): Promise<BatteryOptimizationResult>;
  requestBatteryOptimizationBypass(): Promise<BatteryOptimizationResult>;
  checkBootAutoStart(): Promise<boolean>;
  setBootAutoStart(enabled: boolean): Promise<boolean>;
  startForegroundService(): Promise<ForegroundServiceResult>;
  stopForegroundService(): Promise<ForegroundServiceResult>;
  getReadinessSnapshot(): Promise<AndroidReadinessState>;
  simulateIncomingSms(sms: Omit<IncomingSmsPayload, 'receivedAt'> & { receivedAt?: string }): void;
}

interface CapacitorPluginContract {
  addListener?: (eventName: 'smsReceived', cb: (data: IncomingSmsPayload) => void) => Promise<{ remove: () => void }>;
  getSimCards?: () => Promise<{ sims: SimCardInfo[] }>;
  requestSmsPermissions?: () => Promise<PermissionResult>;
  checkBatteryOptimization?: () => Promise<BatteryOptimizationResult>;
  requestBatteryOptimizationBypass?: () => Promise<BatteryOptimizationResult>;
  checkBootAutoStart?: () => Promise<{ enabled: boolean }>;
  setBootAutoStart?: (opts: { enabled: boolean }) => Promise<{ enabled: boolean }>;
  startForegroundService?: () => Promise<ForegroundServiceResult>;
  stopForegroundService?: () => Promise<ForegroundServiceResult>;
}

interface CapacitorGlobal {
  isNativePlatform?: () => boolean;
  Plugins?: {
    SociaxSmsBridge?: CapacitorPluginContract;
  };
}

const READINESS_STORAGE_KEY = 'ssf_native_sim_readiness_v1';

interface StoredSimReadiness {
  smsPermissionGranted: boolean;
  batteryOptimizationBypassed: boolean;
  bootAutoStartEnabled: boolean;
  foregroundServiceRunning: boolean;
  batteryLevel: number;
}

const DEFAULT_SIM_READINESS: StoredSimReadiness = {
  smsPermissionGranted: false,
  batteryOptimizationBypassed: false,
  bootAutoStartEnabled: true,
  foregroundServiceRunning: false,
  batteryLevel: 84,
};

function getCapacitorGlobal(): CapacitorGlobal | undefined {
  if (typeof window === 'undefined') return undefined;
  return (window as unknown as { Capacitor?: CapacitorGlobal }).Capacitor;
}

function loadSimReadiness(): StoredSimReadiness {
  if (typeof window === 'undefined') return { ...DEFAULT_SIM_READINESS };
  try {
    const raw = window.localStorage.getItem(READINESS_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_SIM_READINESS };
    const parsed = JSON.parse(raw) as Partial<StoredSimReadiness>;
    return { ...DEFAULT_SIM_READINESS, ...parsed };
  } catch {
    return { ...DEFAULT_SIM_READINESS };
  }
}

function saveSimReadiness(next: StoredSimReadiness): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(READINESS_STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage quota errors
  }
}

class SociaxNativeSmsBridge implements NativeSmsBridge {
  private listeners = new Set<SmsListener>();
  private simState: StoredSimReadiness = loadSimReadiness();

  private getNativePlugin(): CapacitorPluginContract | undefined {
    const cap = getCapacitorGlobal();
    if (cap?.isNativePlatform?.()) {
      return cap.Plugins?.SociaxSmsBridge;
    }
    return undefined;
  }

  getPlatform(): 'android-capacitor' | 'browser-simulator' {
    return this.getNativePlugin() ? 'android-capacitor' : 'browser-simulator';
  }

  onSmsReceived(listener: SmsListener): () => void {
    this.listeners.add(listener);

    const native = this.getNativePlugin();
    let nativeHandle: { remove: () => void } | null = null;
    if (native?.addListener) {
      void native.addListener('smsReceived', listener).then((handle) => {
        nativeHandle = handle;
      });
    }

    return () => {
      this.listeners.delete(listener);
      nativeHandle?.remove();
    };
  }

  async getSimCards(): Promise<SimCardInfo[]> {
    const native = this.getNativePlugin();
    if (native?.getSimCards) {
      const res = await native.getSimCards();
      return res.sims;
    }
    // Generic simulated Dual-SIM hardware abstraction for browser preview
    return [
      { slotIndex: 0, slotLabel: 'SIM 1', carrierName: 'Primary SIM Slot', isoCountryCode: 'INTL', active: true },
      { slotIndex: 1, slotLabel: 'SIM 2', carrierName: 'Secondary SIM Slot', isoCountryCode: 'INTL', active: true },
    ];
  }

  async requestSmsPermissions(): Promise<PermissionResult> {
    const native = this.getNativePlugin();
    if (native?.requestSmsPermissions) {
      return native.requestSmsPermissions();
    }
    this.simState = { ...this.simState, smsPermissionGranted: true };
    saveSimReadiness(this.simState);
    return { receiveSms: true, readSms: true, readPhoneState: true };
  }

  async checkBatteryOptimization(): Promise<BatteryOptimizationResult> {
    const native = this.getNativePlugin();
    if (native?.checkBatteryOptimization) {
      return native.checkBatteryOptimization();
    }
    return {
      ignoringBatteryOptimizations: this.simState.batteryOptimizationBypassed,
      batteryLevel: this.simState.batteryLevel,
    };
  }

  async requestBatteryOptimizationBypass(): Promise<BatteryOptimizationResult> {
    const native = this.getNativePlugin();
    if (native?.requestBatteryOptimizationBypass) {
      return native.requestBatteryOptimizationBypass();
    }
    this.simState = { ...this.simState, batteryOptimizationBypassed: true };
    saveSimReadiness(this.simState);
    return {
      ignoringBatteryOptimizations: true,
      batteryLevel: this.simState.batteryLevel,
    };
  }

  async checkBootAutoStart(): Promise<boolean> {
    const native = this.getNativePlugin();
    if (native?.checkBootAutoStart) {
      const res = await native.checkBootAutoStart();
      return res.enabled;
    }
    return this.simState.bootAutoStartEnabled;
  }

  async setBootAutoStart(enabled: boolean): Promise<boolean> {
    const native = this.getNativePlugin();
    if (native?.setBootAutoStart) {
      const res = await native.setBootAutoStart({ enabled });
      return res.enabled;
    }
    this.simState = { ...this.simState, bootAutoStartEnabled: enabled };
    saveSimReadiness(this.simState);
    return enabled;
  }

  async startForegroundService(): Promise<ForegroundServiceResult> {
    const native = this.getNativePlugin();
    if (native?.startForegroundService) {
      return native.startForegroundService();
    }
    this.simState = { ...this.simState, foregroundServiceRunning: true };
    saveSimReadiness(this.simState);
    return { running: true, channelId: 'ssf_foreground_relay' };
  }

  async stopForegroundService(): Promise<ForegroundServiceResult> {
    const native = this.getNativePlugin();
    if (native?.stopForegroundService) {
      return native.stopForegroundService();
    }
    this.simState = { ...this.simState, foregroundServiceRunning: false };
    saveSimReadiness(this.simState);
    return { running: false, channelId: 'ssf_foreground_relay' };
  }

  async getReadinessSnapshot(): Promise<AndroidReadinessState> {
    const battery = await this.checkBatteryOptimization();
    const bootAutoStartEnabled = await this.checkBootAutoStart();
    return {
      smsPermissionGranted: this.simState.smsPermissionGranted,
      batteryOptimizationBypassed: battery.ignoringBatteryOptimizations,
      bootAutoStartEnabled,
      foregroundServiceRunning: this.simState.foregroundServiceRunning,
      batteryLevel: battery.batteryLevel,
      platform: this.getPlatform(),
    };
  }

  simulateIncomingSms(
    sms: Omit<IncomingSmsPayload, 'receivedAt'> & { receivedAt?: string }
  ): void {
    const payload: IncomingSmsPayload = {
      ...sms,
      receivedAt: sms.receivedAt ?? new Date().toISOString(),
    };
    this.listeners.forEach((listener) => listener(payload));
  }
}

export const nativeSmsBridge: NativeSmsBridge = new SociaxNativeSmsBridge();
