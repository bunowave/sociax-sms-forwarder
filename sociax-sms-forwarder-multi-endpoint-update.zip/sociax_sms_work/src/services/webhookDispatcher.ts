import type {
  EndpointProfile,
  LogStatus,
  SmsEnvelope,
  WatchdogConfig,
  WebhookLogEntry,
} from '../types/ssf';
import {
  computeNextRetryDelayMs,
  generateId,
  renderPayloadTemplate,
  validateWebhookUrl,
} from '../utils/webhookEngine';

export type SimulationOutcome = '200_ok' | '401_unauthorized' | '500_server_error' | 'offline_queue';

export interface DispatchOptions {
  mode: 'live' | 'simulated';
  simulationOutcome?: SimulationOutcome;
  existingLogId?: string;
  priorAttempts?: number;
}

export async function dispatchWebhook(
  profile: EndpointProfile,
  sms: SmsEnvelope,
  options: DispatchOptions
): Promise<WebhookLogEntry> {
  const rendered = renderPayloadTemplate(profile.payloadTemplate, {
    sender: sms.sender,
    message: sms.message,
    sim_slot: sms.simSlot,
    timestamp: sms.receivedAt,
    device_id: sms.deviceId,
  });

  const bodyToSend = rendered.rendered;
  const attempts = (options.priorAttempts ?? 0) + 1;

  const requestHeaders = [
    { key: 'Content-Type', value: 'application/json', isSecret: false },
    ...profile.headers
      .filter((h) => h.key.trim().length > 0)
      .map((h) => ({ key: h.key.trim(), value: h.value, isSecret: h.isSecret })),
  ];

  // Simulated dry-run path for testing filters, retry queues, and status codes without an external server
  if (options.mode === 'simulated') {
    const simulatedLatency = Math.floor(32 + Math.random() * 58);
    await new Promise((resolve) => setTimeout(resolve, 220));

    const outcome = options.simulationOutcome ?? '200_ok';
    let status: LogStatus = 'success';
    let statusCode: number | null = 200;
    let statusText = 'OK';
    let responseBody = JSON.stringify(
      {
        received: true,
        relay: 'simulated-dry-run',
        echoed_sender: sms.sender,
        processed_at: new Date().toISOString(),
      },
      null,
      2
    );
    let error: string | undefined;
    let nextRetryAt: string | undefined;

    if (outcome === '401_unauthorized') {
      status = 'failed';
      statusCode = 401;
      statusText = 'Unauthorized';
      responseBody = JSON.stringify(
        { error: 'Unauthorized', detail: 'Check custom auth header key/value in endpoint profile.' },
        null,
        2
      );
      error = 'HTTP 401 Unauthorized';
    } else if (outcome === '500_server_error') {
      const canQueue = profile.retryPolicy.offlineQueue && attempts <= profile.retryPolicy.maxRetries;
      status = canQueue ? 'pending' : 'failed';
      statusCode = 500;
      statusText = 'Internal Server Error';
      responseBody = JSON.stringify(
        { error: 'Upstream Error', detail: 'Simulated 500 server response.' },
        null,
        2
      );
      error = 'HTTP 500 Internal Server Error';
      if (canQueue) {
        nextRetryAt = new Date(
          Date.now() + computeNextRetryDelayMs(attempts, profile.retryPolicy.exponentialBackoff)
        ).toISOString();
      }
    } else if (outcome === 'offline_queue') {
      const canQueue = profile.retryPolicy.offlineQueue && attempts <= profile.retryPolicy.maxRetries;
      status = canQueue ? 'pending' : 'failed';
      statusCode = null;
      statusText = 'Network Offline';
      responseBody = '';
      error = canQueue
        ? 'Device offline — queued for automatic retry.'
        : 'Device offline — max retry limit reached.';
      if (canQueue) {
        nextRetryAt = new Date(
          Date.now() + computeNextRetryDelayMs(attempts, profile.retryPolicy.exponentialBackoff)
        ).toISOString();
      }
    }

    return {
      id: options.existingLogId ?? generateId('log'),
      endpointId: profile.id,
      endpointName: profile.name,
      endpointUrl: profile.url,
      status,
      sms,
      request: {
        url: profile.url,
        method: 'POST',
        headers: requestHeaders,
        body: bodyToSend,
      },
      response: {
        statusCode,
        statusText,
        latencyMs: simulatedLatency,
        body: responseBody,
        error,
      },
      attempts,
      maxRetries: profile.retryPolicy.maxRetries,
      nextRetryAt,
      mode: 'simulated',
    };
  }

  // Live HTTP POST path using browser fetch()
  const fetchHeaders: Record<string, string> = {};
  for (const hdr of requestHeaders) {
    fetchHeaders[hdr.key] = hdr.value;
  }

  const startedAt = performance.now();
  try {
    const res = await fetch(profile.url, {
      method: 'POST',
      headers: fetchHeaders,
      body: bodyToSend,
    });
    const latencyMs = Math.max(1, Math.round(performance.now() - startedAt));
    const responseText = await res.text();
    const isOk = res.ok;
    const isRetryable = !isOk && res.status >= 500 && profile.retryPolicy.offlineQueue && attempts <= profile.retryPolicy.maxRetries;

    return {
      id: options.existingLogId ?? generateId('log'),
      endpointId: profile.id,
      endpointName: profile.name,
      endpointUrl: profile.url,
      status: isOk ? 'success' : isRetryable ? 'pending' : 'failed',
      sms,
      request: {
        url: profile.url,
        method: 'POST',
        headers: requestHeaders,
        body: bodyToSend,
      },
      response: {
        statusCode: res.status,
        statusText: res.statusText || (isOk ? 'OK' : 'HTTP Error'),
        latencyMs,
        body: responseText.slice(0, 8000),
        error: isOk ? undefined : `HTTP ${res.status} ${res.statusText || 'Error'}`,
      },
      attempts,
      maxRetries: profile.retryPolicy.maxRetries,
      nextRetryAt: isRetryable
        ? new Date(
            Date.now() + computeNextRetryDelayMs(attempts, profile.retryPolicy.exponentialBackoff)
          ).toISOString()
        : undefined,
      mode: 'live',
    };
  } catch (err) {
    const latencyMs = Math.max(1, Math.round(performance.now() - startedAt));
    const message = err instanceof Error ? err.message : 'Network request failed';
    const isLikelyCors =
      message.toLowerCase().includes('fetch') ||
      message.toLowerCase().includes('network') ||
      message.toLowerCase().includes('cors');

    const canQueue = profile.retryPolicy.offlineQueue && attempts <= profile.retryPolicy.maxRetries;

    return {
      id: options.existingLogId ?? generateId('log'),
      endpointId: profile.id,
      endpointName: profile.name,
      endpointUrl: profile.url,
      status: canQueue ? 'pending' : 'failed',
      sms,
      request: {
        url: profile.url,
        method: 'POST',
        headers: requestHeaders,
        body: bodyToSend,
      },
      response: {
        statusCode: null,
        statusText: 'Network / CORS Error',
        latencyMs,
        body: '',
        error: message,
        isCorsHint: isLikelyCors,
      },
      attempts,
      maxRetries: profile.retryPolicy.maxRetries,
      nextRetryAt: canQueue
        ? new Date(
            Date.now() + computeNextRetryDelayMs(attempts, profile.retryPolicy.exponentialBackoff)
          ).toISOString()
        : undefined,
      mode: 'live',
    };
  }
}

export async function pingEndpointHeartbeat(
  url: string
): Promise<{ reachable: boolean; latencyMs: number; note: string }> {
  const check = validateWebhookUrl(url);
  if (!check.valid) {
    return { reachable: false, latencyMs: 0, note: check.error ?? 'Invalid URL' };
  }
  const start = performance.now();
  try {
    // Use no-cors HEAD/GET probe strictly for latency RTT timing in browser preview
    await fetch(url, { method: 'HEAD', mode: 'no-cors', cache: 'no-store' });
    const latencyMs = Math.max(1, Math.round(performance.now() - start));
    return { reachable: true, latencyMs, note: 'Connected' };
  } catch {
    const latencyMs = Math.max(1, Math.round(performance.now() - start));
    return { reachable: false, latencyMs, note: 'Unreachable' };
  }
}

export async function sendWatchdogAlert(
  config: WatchdogConfig,
  deviceId: string,
  reason: string
): Promise<{ ok: boolean; message: string }> {
  if (config.channel === 'disabled') {
    return { ok: false, message: 'Watchdog alert channel is currently disabled.' };
  }

  const text = `[SOCIAX SMS FORWARDER] Watchdog Alert\nDevice: ${deviceId}\nEvent: ${reason}\nTime: ${new Date().toISOString()}`;

  if (config.channel === 'telegram') {
    const token = config.telegramBotToken.trim();
    const chatId = config.telegramChatId.trim();
    if (!token || !chatId) {
      return { ok: false, message: 'Enter both Telegram Bot Token and Chat ID before testing.' };
    }
    try {
      const endpoint = `https://api.telegram.org/bot${encodeURIComponent(token)}/sendMessage`;
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text }),
      });
      if (res.ok) {
        return { ok: true, message: 'Telegram watchdog alert delivered successfully.' };
      }
      const errBody = await res.text();
      return {
        ok: false,
        message: `Telegram API returned HTTP ${res.status}: ${errBody.slice(0, 140)}`,
      };
    } catch (err) {
      return {
        ok: false,
        message:
          err instanceof Error
            ? `Network/CORS error calling Telegram API (${err.message}). In Capacitor Android APK, native HTTP bypasses browser CORS.`
            : 'Network error calling Telegram API.',
      };
    }
  }

  // Custom Alert Webhook
  const urlCheck = validateWebhookUrl(config.alertWebhookUrl);
  if (!urlCheck.valid) {
    return { ok: false, message: urlCheck.error ?? 'Enter a valid HTTPS Alert Webhook URL.' };
  }

  try {
    const res = await fetch(config.alertWebhookUrl.trim(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: 'SOCIAX_SMS_FORWARDER',
        device_id: deviceId,
        event: reason,
        timestamp: new Date().toISOString(),
      }),
    });
    if (res.ok) {
      return { ok: true, message: `Alert webhook responded HTTP ${res.status}.` };
    }
    return { ok: false, message: `Alert webhook returned HTTP ${res.status} ${res.statusText}.` };
  } catch (err) {
    return {
      ok: false,
      message:
        err instanceof Error
          ? `Request blocked or unreachable (${err.message}). In native Android APK, Capacitor HTTP bypasses browser CORS.`
          : 'Failed to deliver alert webhook.',
    };
  }
}
